from __future__ import annotations
import hashlib, importlib.util, sys, tempfile, zipfile
from contextlib import contextmanager
from pathlib import Path
P20A_SHA256='38e8fda72f99bdd43e99b6191a3381f789ed29e0b95cd45d140ce9d1bc17c3e2'
P20A_ROOT='S2_COMP_02C20A_YR_INCIDENCE_COLLISION_CENSUS_FREEZE_CANDIDATE_20260901'
P19_SHA256='47a3cabdeb2300de96906415c7cee21b8a731da3d3cdb7bf7fee78e38804f20b'
P18_SHA256='623b1a639b4549001c9b0091b5d3cb0dee4401d2b3afa54706f307c0508c521b'
P9_SHA256='4ce99f3bb724b5da3b2731d3c60c82d8103713768e715e855585ea5d7c2f7a19'
P20A_CENSUS_SHA256='dce05bc7825eeba5b705ccb83b5f1f473646fa005d7824d15a827acc8069260e'
P20A_FIXTURE_SHA256='ea8d24d71b9d65251a41b623de3cbd219c2d3bf18318f952775e12f69c856683'
def sha256(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
def checked(p,h,label):
 p=Path(p).expanduser().resolve()
 if not p.is_file(): raise FileNotFoundError(f'{label} not found: {p}')
 g=sha256(p)
 if g!=h: raise AssertionError(f'{label} hash mismatch: expected {h}, got {g}')
 return p
@contextmanager
def env02c20b(p20a,p19,p18,p9):
 p20a=checked(p20a,P20A_SHA256,'02C20A'); p19=checked(p19,P19_SHA256,'02C19'); p18=checked(p18,P18_SHA256,'02C18'); p9=checked(p9,P9_SHA256,'02C9')
 old=sys.dont_write_bytecode; sys.dont_write_bytecode=True
 with tempfile.TemporaryDirectory(prefix='s2comp02c20b_') as td:
  td=Path(td)
  with zipfile.ZipFile(p20a) as z: z.extractall(td/'p20a')
  root=td/'p20a'/P20A_ROOT
  if not root.is_dir(): raise RuntimeError('02C20A extraction root missing')
  if sha256(root/'02C20A_YR_INCIDENCE_COLLISION_CENSUS.json')!=P20A_CENSUS_SHA256: raise AssertionError('02C20A census hash mismatch')
  if sha256(root/'WITNESS_FIXTURES_SOURCE1.json')!=P20A_FIXTURE_SHA256: raise AssertionError('02C20A witness fixture hash mismatch')
  spec=importlib.util.spec_from_file_location('_s2comp02c20a_env_20b',root/'s2comp02c20a_env.py')
  mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
  yield {'p20a_root':root,'parent_env':mod,'p19':p19,'p18':p18,'p9':p9}
 sys.dont_write_bytecode=old
