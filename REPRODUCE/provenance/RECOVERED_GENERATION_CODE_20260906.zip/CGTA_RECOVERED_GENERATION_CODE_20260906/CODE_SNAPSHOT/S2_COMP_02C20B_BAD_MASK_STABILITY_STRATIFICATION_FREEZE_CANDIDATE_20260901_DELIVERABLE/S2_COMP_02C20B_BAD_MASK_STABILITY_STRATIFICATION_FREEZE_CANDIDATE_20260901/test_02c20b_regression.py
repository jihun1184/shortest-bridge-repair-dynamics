from __future__ import annotations
import sys; sys.dont_write_bytecode=True
import hashlib, json, subprocess, tempfile
from pathlib import Path
import orjson
HERE=Path(__file__).resolve().parent
IDS=[1,2,4,7,40,41,112,113,114,115]
EXPECTED_TOTALS={'incompatible_badset_variable_classes':0,'incompatible_collision_classes_examined':39561,'incompatible_multi_incidence_classes':37058,'literal_badset_stable_classes':37058,'max_distinct_badsets_within_yr':1}
EXPECTED_PER_SOURCE={1:18,2:3,4:67,7:3,40:492,41:1899,112:1665,113:6890,114:15157,115:10864}
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 agg=orjson.loads((HERE/'02C20B_BAD_MASK_STABILITY_STRATIFICATION.json').read_bytes())
 assert agg['totals']==EXPECTED_TOTALS, (agg['totals'],EXPECTED_TOTALS)
 assert agg['distinct_badset_count_histogram']=={'1':37058}
 assert sum(EXPECTED_PER_SOURCE.values())==37058
 for sid in IDS:
  d=orjson.loads((HERE/f'02C20B_SOURCE_{sid}.json').read_bytes()); t=d['totals']
  assert t['incompatible_multi_incidence_classes']==EXPECTED_PER_SOURCE[sid]
  assert t['literal_badset_stable_classes']==EXPECTED_PER_SOURCE[sid]
  assert t['incompatible_badset_variable_classes']==0
  assert d['distinct_badset_count_histogram']=={'1':EXPECTED_PER_SOURCE[sid]}
 with tempfile.TemporaryDirectory(prefix='02c20b_merge_') as td:
  out=Path(td)/'aggregate.json'
  subprocess.run([sys.executable,str(HERE/'merge_02c20b_stratification.py'),'--inputs',*[str(HERE/f'02C20B_SOURCE_{sid}.json') for sid in IDS],'--output',str(out)],check=True,stdout=subprocess.DEVNULL)
  assert out.read_bytes()==(HERE/'02C20B_BAD_MASK_STABILITY_STRATIFICATION.json').read_bytes()
 print('PASS: 37,058/37,058 incompatible multi-incidence classes have one literal bad-mask set; variable=0; deterministic merge byte-identical')
if __name__=='__main__': main()
