# S2-COMP-02C20B — Bad-mask stability stratification (freeze candidate)

This checkpoint follows canonical 02C20A and asks a stronger question than compatibility-bit stability.
For a fixed `(Y,R)` class, let `F=Y∪R` and

`B_g(Δ) = Bad(F) ∩ I(Δ)`.

02C20A established that compatibility emptiness is invariant within every frozen D1 `(Y,R)` class. 02C20B compares **the literal mask-key set** `B_g(Δ)` across distinct exact incidence signatures; no cardinality-only or emptiness-only surrogate is used.

## Full frozen-D1 result

The nontrivial domain is the 37,058 **incompatible multi-incidence** `(Y,R)` classes from 02C20A.

- incompatible multi-incidence classes: **37,058**
- literal bad-set stable classes: **37,058**
- incompatible bad-set variable classes: **0**
- `distinct_badset_count` histogram: **{1: 37,058}**
- maximum distinct literal bad sets in one `(Y,R)` class: **1**

Thus, within this bounded frozen D1 scope, provenance can change `Δ` and the exact incidence set `I(Δ)`, but for incompatible classes the compatibility-critical literal mask set `Bad(F)∩I(Δ)` remains unchanged once `(Y,R)` is fixed.

This is a bounded exhaustive census result, not a D2/general-state theorem and not a minimal-sufficient-statistic claim.

## Rebuild

`run_full_rebuild.sh 02C20A.zip 02C19.zip 02C18.zip 02C9.zip OUTDIR`

The dependencies are exact-hash checked. The script rebuilds all ten source shards from the canonical 02C19 oracle, merges them deterministically, and byte-compares each result with the frozen files.

`test_02c20b_source1_witness_live.py` recomputes the known nontrivial source-1 witness where the two exact incidence sets differ but both literal bad sets are exactly `{Q2(-2,1,0,'y'), Q3(-2,1,0)}`.
