from __future__ import annotations
import sys
sys.dont_write_bytecode=True
from collections import Counter, defaultdict

def ser_points(s): return [list(p) for p in sorted(s)]
def ser_masks(s): return [[k[0],list(k[1])] for k in sorted(s,key=str)]

def mask_occupancy(F,m,fw):
    tag,key=m
    cands=fw.edge_cands(key) if tag=='Q2' else fw.vertex_cands(key)
    return {'candidates':ser_points(frozenset(cands)), 'occupancy':[tuple(p) in F for p in cands]}

def analyze_source_data(src,decider,fw,max_witness=3):
    sid=int(src['source_state_index']); pts=set()
    for h in src['histories']:
        pts.update(map(tuple,h['node']))
        for a in h['actions']: pts.update(map(tuple,a))
    ordered=sorted(pts); idx={p:i for i,p in enumerate(ordered)}
    def bm(seq):
        x=0
        for p in seq: x |= 1<<idx[tuple(p)]
        return x
    def points(x):
        out=[]
        while x:
            low=x&-x; i=low.bit_length()-1; out.append(ordered[i]); x^=low
        return frozenset(out)

    prepared=[]; groups={}
    for h in src['histories']:
        n=bm(h['node']); aa=[bm(a) for a in h['actions']]; yy=[n|a for a in aa]
        prepared.append((h,n,aa,yy))
        for ai,ti,code in h['directions']:
            r=aa[ti]&~aa[ai]
            if not r: continue
            k=(yy[ai],r); v=groups.get(k,0); occ=min(2,(v&3)+1); v=(v&~3)|occ
            v |= 1<<(2+((code>>2)&1))   # oracle compatible bit-set
            groups[k]=v

    collisions={k for k,v in groups.items() if (v&3)>1}
    incompatible_collisions={k for k in collisions if (groups[k]&12)==4}
    delta_map={}; delta_points={}
    for h,n,aa,yy in prepared:
        for ai,ti,code in h['directions']:
            r=aa[ti]&~aa[ai]; k=(yy[ai],r)
            if not r or k not in incompatible_collisions: continue
            d=aa[ai]&~(n|aa[ti])
            delta_map.setdefault(k,set()).add(d); delta_points.setdefault(d,points(d))

    # Exact incidence equivalence: literal frozenset of mask keys, never cardinality.
    incidence={d:frozenset(decider.incident_mask_keys(ds,fw)) for d,ds in delta_points.items()}
    st=Counter(); hist=Counter(); witnesses=[]
    for k,dset in delta_map.items():
        inc_to_d=defaultdict(list)
        for d in dset: inc_to_d[incidence[d]].append(d)
        if len(inc_to_d)<=1: continue
        st['incompatible_multi_incidence_classes']+=1
        F=points(k[0]|k[1])
        badsets={}
        for inc in inc_to_d:
            # Primary 02C20B object: literal B_g(delta)=Bad(F) intersection I(delta).
            bad=frozenset(m for m in inc if decider.mask_bad(F,m[0],m[1],fw))
            if not bad: raise AssertionError(f'incompatible class has empty bad-set: source={sid}')
            badsets[inc]=bad
        distinct_badsets=set(badsets.values())
        n=len(distinct_badsets); hist[n]+=1
        st['literal_badset_stable_classes']+=(n==1)
        st['incompatible_badset_variable_classes']+=(n>1)
        st['max_distinct_badsets_within_yr']=max(st['max_distinct_badsets_within_yr'],n)

        if n==1 and sum(w['kind']=='literal_badset_stable' for w in witnesses)<max_witness:
            incs=list(inc_to_d); d1=inc_to_d[incs[0]][0]; d2=inc_to_d[incs[1]][0]; b=badsets[incs[0]]
            witnesses.append({'kind':'literal_badset_stable','source_state_index':sid,
                'Y':ser_points(points(k[0])),'R':ser_points(points(k[1])),'F':ser_points(F),
                'delta_1':ser_points(delta_points[d1]),'delta_2':ser_points(delta_points[d2]),
                'incidence_1':ser_masks(incs[0]),'incidence_2':ser_masks(incs[1]),
                'bad_set_1':ser_masks(b),'bad_set_2':ser_masks(b),
                'bad_set_added':[],'bad_set_removed':[],'changed_mask_details':[]})
        if n>1 and sum(w['kind']=='literal_badset_variable' for w in witnesses)<max_witness:
            bybad={}
            for inc,b in badsets.items(): bybad.setdefault(b,inc)
            b1,b2=list(bybad)[:2]; i1=bybad[b1]; i2=bybad[b2]
            d1=inc_to_d[i1][0]; d2=inc_to_d[i2][0]
            added=b2-b1; removed=b1-b2; details=[]
            for status,ms in [('added',added),('removed',removed)]:
                for m in sorted(ms,key=str):
                    details.append({'status':status,'mask':[m[0],list(m[1])],**mask_occupancy(F,m,fw)})
            witnesses.append({'kind':'literal_badset_variable','source_state_index':sid,
                'Y':ser_points(points(k[0])),'R':ser_points(points(k[1])),'F':ser_points(F),
                'delta_1':ser_points(delta_points[d1]),'delta_2':ser_points(delta_points[d2]),
                'incidence_1':ser_masks(i1),'incidence_2':ser_masks(i2),
                'bad_set_1':ser_masks(b1),'bad_set_2':ser_masks(b2),
                'bad_set_added':ser_masks(added),'bad_set_removed':ser_masks(removed),
                'changed_mask_details':details})
    st['incompatible_collision_classes_examined']=len(incompatible_collisions)
    return {'source_state_index':sid,'totals':dict(st),
            'distinct_badset_count_histogram':{str(k):hist[k] for k in sorted(hist)},'witnesses':witnesses}
