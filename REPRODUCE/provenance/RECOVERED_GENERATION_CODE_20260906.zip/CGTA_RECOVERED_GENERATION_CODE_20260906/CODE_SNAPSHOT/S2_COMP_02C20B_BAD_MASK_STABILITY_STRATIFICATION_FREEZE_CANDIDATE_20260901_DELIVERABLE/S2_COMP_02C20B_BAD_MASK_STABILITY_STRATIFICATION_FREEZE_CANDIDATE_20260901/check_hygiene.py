from pathlib import Path
ROOT=Path(__file__).resolve().parent
bad=[]
for p in ROOT.rglob('*'):
 if not p.is_file(): continue
 if '__pycache__' in p.parts or p.suffix=='.pyc': bad.append(str(p.relative_to(ROOT))); continue
 if p.name=='SHA256SUMS.txt' or p.suffix.lower() not in {'.py','.md','.sh','.json','.txt'}: continue
 s=p.read_text(errors='ignore')
 for needle in ('/'+'mnt/data/','/'+'home/'):
  if needle in s: bad.append(f'{p.relative_to(ROOT)} contains machine-specific path')
if bad: raise SystemExit('HYGIENE FAIL:\n'+'\n'.join(bad))
print('PASS: no pycache/pyc or machine-specific absolute-path leaks')
