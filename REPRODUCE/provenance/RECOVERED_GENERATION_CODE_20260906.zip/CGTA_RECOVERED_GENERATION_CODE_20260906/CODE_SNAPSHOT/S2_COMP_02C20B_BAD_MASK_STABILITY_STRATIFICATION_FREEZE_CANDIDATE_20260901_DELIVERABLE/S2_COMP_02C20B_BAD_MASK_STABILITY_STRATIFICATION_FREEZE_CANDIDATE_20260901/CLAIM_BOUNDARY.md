# Claim boundary

Scientific status of this package: **BOUNDED_EXHAUSTIVE_CLOSED — freeze candidate pending independent validation.**

The claim is restricted to the frozen ten-source depth-1 natural-closure domain inherited from canonical 02C19-D1/02C20A.

For each incompatible multi-incidence `(Y,R)` equivalence class `g`, with fixed `F=Y∪R`, every realized last-step provenance `Δ` has the same literal set

`B_g(Δ) = Bad(F) ∩ I(Δ)`.

All 37,058 such classes were exhausted; 37,058 are literal-bad-set stable and 0 are variable.

This package does **not** claim:
- a D2 or arbitrary-history result;
- a theorem for arbitrary source states;
- that `(Y,R)` is globally or minimally sufficient;
- that the same result follows merely from the small number of BAD_Q2/BAD_Q3 pattern types;
- a proof independent of the frozen action semantics.
