from __future__ import annotations
import argparse,json
from pathlib import Path
from collections import Counter
import orjson

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--inputs',nargs='+',required=True); ap.add_argument('--output',required=True); a=ap.parse_args()
 rows=[orjson.loads(Path(p).read_bytes()) for p in a.inputs]; rows.sort(key=lambda r:int(r['source_state_index']))
 T=Counter(); H=Counter(); W=[]
 for r in rows:
  T.update(r['totals'])
  for k,v in r['distinct_badset_count_histogram'].items(): H[int(k)]+=v
  W.extend(r.get('witnesses',[]))
 T['max_distinct_badsets_within_yr']=max((r['totals'].get('max_distinct_badsets_within_yr',0) for r in rows),default=0)
 out={'checkpoint':'S2-COMP-02C20B bad-mask stability stratification','scope':'frozen 02C19-D1 incompatible multi-incidence (Y,R) classes',
      'definition':'B_g(delta)=Bad(F) intersection I(delta); exact literal frozenset equality, not cardinality/emptiness',
      'totals':dict(T),'distinct_badset_count_histogram':{str(k):H[k] for k in sorted(H)},
      'sources':[{'source_state_index':r['source_state_index'],'totals':r['totals'],'histogram':r['distinct_badset_count_histogram']} for r in rows],
      'witnesses':W[:20]}
 Path(a.output).write_bytes(orjson.dumps(out,option=orjson.OPT_SORT_KEYS|orjson.OPT_INDENT_2)+b'\n'); print(json.dumps({'output':a.output,'totals':out['totals'],'histogram':out['distinct_badset_count_histogram']},indent=2,sort_keys=True))
if __name__=='__main__': main()
