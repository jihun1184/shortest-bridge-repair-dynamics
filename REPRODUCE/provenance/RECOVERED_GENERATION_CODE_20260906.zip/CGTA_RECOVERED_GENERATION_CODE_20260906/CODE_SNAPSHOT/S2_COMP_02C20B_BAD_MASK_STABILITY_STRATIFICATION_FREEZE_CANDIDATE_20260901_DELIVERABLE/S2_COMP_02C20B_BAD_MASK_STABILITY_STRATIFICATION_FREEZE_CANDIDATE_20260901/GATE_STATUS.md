# Gate status

- full ten-source raw analysis used to generate the frozen shards from exact canonical dependencies: PASS
- source 1 through source 115 all produced `max_distinct_badsets_within_yr = 1`: PASS
- aggregate `incompatible_multi_incidence_classes = 37,058`: PASS
- aggregate `literal_badset_stable_classes = 37,058`: PASS
- aggregate `incompatible_badset_variable_classes = 0`: PASS
- deterministic frozen merge: PASS
- packaged production source-1 raw rebuild: byte-identical PASS
- source-1 nontrivial literal-bad-set witness live recomputation: PASS
- hygiene: PASS
- packaged full ten-source `run_full_rebuild.sh`: included; independent user-side validation pending
