#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
if [ "$#" -ne 5 ]; then echo "usage: $0 02C20A.zip 02C19.zip 02C18.zip 02C9.zip OUTDIR" >&2; exit 2; fi
P20A="$1"; P19="$2"; P18="$3"; P9="$4"; OUT="$5"; HERE="$(cd "$(dirname "$0")" && pwd)"
rm -rf "$OUT"; mkdir -p "$OUT"
python "$HERE/run_02c20b_full_stratification.py" --02c20a "$P20A" --02c19 "$P19" --02c18 "$P18" --02c9 "$P9" --out-dir "$OUT"
python "$HERE/merge_02c20b_stratification.py" --inputs "$OUT"/02C20B_SOURCE_1.json "$OUT"/02C20B_SOURCE_2.json "$OUT"/02C20B_SOURCE_4.json "$OUT"/02C20B_SOURCE_7.json "$OUT"/02C20B_SOURCE_40.json "$OUT"/02C20B_SOURCE_41.json "$OUT"/02C20B_SOURCE_112.json "$OUT"/02C20B_SOURCE_113.json "$OUT"/02C20B_SOURCE_114.json "$OUT"/02C20B_SOURCE_115.json --output "$OUT/02C20B_BAD_MASK_STABILITY_STRATIFICATION.json"
for s in 1 2 4 7 40 41 112 113 114 115; do cmp "$OUT/02C20B_SOURCE_${s}.json" "$HERE/02C20B_SOURCE_${s}.json"; done
cmp "$OUT/02C20B_BAD_MASK_STABILITY_STRATIFICATION.json" "$HERE/02C20B_BAD_MASK_STABILITY_STRATIFICATION.json"
echo 'PASS: full 02C20B raw bad-mask stability rebuild byte-identical to frozen source shards and aggregate'
