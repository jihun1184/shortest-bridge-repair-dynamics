from __future__ import annotations
import sys; sys.dont_write_bytecode=True
import argparse
from pathlib import Path
import orjson
from s2comp02c20b_env import env02c20b

def deser_masks(xs): return frozenset((x[0],tuple(x[1])) for x in xs)
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--02c20a',required=True); ap.add_argument('--02c19',required=True); ap.add_argument('--02c18',required=True); ap.add_argument('--02c9',required=True); a=ap.parse_args()
 w=orjson.loads((Path(__file__).resolve().parent/'02C20B_SOURCE_1.json').read_bytes())['witnesses'][0]
 assert w['kind']=='literal_badset_stable'
 F=frozenset(map(tuple,w['F'])); d1=frozenset(map(tuple,w['delta_1'])); d2=frozenset(map(tuple,w['delta_2']))
 with env02c20b(a.__dict__['02c20a'],a.__dict__['02c19'],a.__dict__['02c18'],a.__dict__['02c9']) as B:
  with B['parent_env'].env02c20a(B['p19'],B['p18'],B['p9']) as E:
   with E['parent_env'].env02c19_d1(E['p18'],E['p9']) as pe:
    with pe['env02c12']() as (frozen_env,_,_):
     with frozen_env() as outer:
      with outer.frozen.frozen_env() as env:
       import finite_window_classification as fw
       i1=frozenset(pe['decider'].incident_mask_keys(d1,fw)); i2=frozenset(pe['decider'].incident_mask_keys(d2,fw))
       assert i1!=i2
       b1=frozenset(m for m in i1 if pe['decider'].mask_bad(F,m[0],m[1],fw)); b2=frozenset(m for m in i2 if pe['decider'].mask_bad(F,m[0],m[1],fw))
 assert i1==deser_masks(w['incidence_1']); assert i2==deser_masks(w['incidence_2'])
 assert b1==deser_masks(w['bad_set_1']); assert b2==deser_masks(w['bad_set_2']); assert b1==b2 and b1
 expected=frozenset({('Q2',(-2,1,0,'y')),('Q3',(-2,1,0))}); assert b1==expected
 print('PASS: source-1 nontrivial witness recomputed live: distinct incidence, identical literal bad set {Q2(-2,1,0,y), Q3(-2,1,0)}')
if __name__=='__main__': main()
