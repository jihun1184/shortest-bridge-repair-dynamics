from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--decisions", nargs="+", required=True)
    ap.add_argument("--oracle", nargs="+", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()
    totals = Counter()
    source_rows = []
    for p in args.decisions:
        x = json.loads(Path(p).read_text())
        totals.update(x["totals"])
        source_rows.extend(x["sources"])

    # Mechanism-oriented state/residual consistency census from oracle metadata plus post-decider labels.
    # The decisive zero-conflict gate is tested separately in the regression runner; here we report scope-level structure.
    oracle_sources = []
    for p in args.oracle:
        oracle_sources.extend(json.loads(Path(p).read_text())["sources"])
    state_history = defaultdict(set)
    state_residuals = defaultdict(set)
    for src in oracle_sources:
        for h in src["histories"]:
            actions = [frozenset(tuple(q) for q in a) for a in h["actions"]]
            node = frozenset(tuple(q) for q in h["node"])
            for ai, ti, code in h["directions"]:
                actor, target = actions[ai], actions[ti]
                child = tuple(sorted(node | actor))
                residual = tuple(sorted(target - actor))
                state_history[child].add(h["history_key"])
                state_residuals[child].add(residual)
    merged_child_states = sum(1 for v in state_history.values() if len(v) > 1)
    merged_with_multiple_residuals = sum(1 for k, v in state_history.items() if len(v) > 1 and len(state_residuals[k]) > 1)

    result = {
        "checkpoint": "S2-COMP-02C19-D1 deep-history analysis",
        "totals": dict(totals),
        "quadrants": {
            "geometry_yes_compat_yes": totals["supported_residual"],
            "geometry_yes_compat_no": totals["local_incompatible"],
            "geometry_no_compat_yes": totals["no_geometry"],
            "geometry_no_compat_no": totals["no_geometry_and_local_incompatible"],
        },
        "negative_controls": {
            "geometry_only_false_positives": totals["geometry_positive"] - totals["supported_residual"],
            "compatibility_only_false_positives": totals["local_compatible"] - totals["supported_residual"],
        },
        "merge_mechanism_scope": {
            "child_states_seen_in_directions": len(state_history),
            "child_states_with_multiple_histories": merged_child_states,
            "merged_child_states_with_multiple_residuals": merged_with_multiple_residuals,
        },
        "source_summaries": sorted(source_rows, key=lambda r: r["source_state_index"]),
    }
    Path(args.output).write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
