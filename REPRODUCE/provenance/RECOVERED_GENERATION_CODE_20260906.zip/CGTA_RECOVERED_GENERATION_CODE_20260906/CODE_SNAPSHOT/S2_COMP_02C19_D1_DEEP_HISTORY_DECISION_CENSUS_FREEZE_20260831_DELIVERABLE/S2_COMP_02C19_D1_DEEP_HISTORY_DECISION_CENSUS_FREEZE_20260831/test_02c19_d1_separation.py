from __future__ import annotations

import argparse
import hashlib
import os
import subprocess
import sys
import tempfile
from pathlib import Path

from oracle_label_guard import GuardedOracleLabel

HERE = Path(__file__).resolve().parent
ORACLE_REF = HERE / 'oracle_source1.json'
CENSUS_REF = HERE / 'census_source1_v2.json'
ORACLE_REF_SHA256 = '6e51ac07c30cf552b96de02ae5d81669d09556db69b448e7b484ed60dd647d0a'
CENSUS_REF_SHA256 = '64fcadba71ebd8fc8b3b2479b2b5cfb5d71d3bebfc19d84e1dab273edfe62b02'


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--02c18', required=True)
    ap.add_argument('--02c9', required=True)
    args = ap.parse_args()

    # Unit-level order guard: labels cannot be read before decision completion.
    g = GuardedOracleLabel(7)
    try:
        g.read_for_comparison()
    except AssertionError:
        pass
    else:
        raise AssertionError('negative control failed: pre-decision oracle-label read was allowed')
    g.mark_decision_complete()
    labels = g.read_for_comparison()
    assert labels == {'partial': True, 'supported': True, 'compatible': True}

    assert sha256(ORACLE_REF) == ORACLE_REF_SHA256
    assert sha256(CENSUS_REF) == CENSUS_REF_SHA256

    with tempfile.TemporaryDirectory(prefix='s2comp02c19d1_sep_') as td_raw:
        td = Path(td_raw)
        oracle = td / 'oracle1.json'
        census = td / 'census1.json'
        subprocess.run([
            sys.executable, str(HERE / 'build_02c19_d1_oracle_shard.py'),
            '--02c18', args.__dict__['02c18'], '--02c9', args.__dict__['02c9'],
            '--sources', '1', '--output', str(oracle)
        ], check=True)
        env = os.environ.copy()
        env['S2COMP_02C19_D1_FORBIDDEN_CALL_TRAPS'] = '1'
        subprocess.run([
            sys.executable, str(HERE / 'run_02c19_d1_decider_shard.py'),
            '--02c18', args.__dict__['02c18'], '--02c9', args.__dict__['02c9'],
            '--oracle', str(oracle), '--output', str(census)
        ], check=True, env=env)
        if oracle.read_bytes() != ORACLE_REF.read_bytes():
            raise AssertionError('fresh source-1 oracle is not byte-identical to frozen reference')
        if census.read_bytes() != CENSUS_REF.read_bytes():
            raise AssertionError('fresh source-1 census is not byte-identical to frozen reference')

    print('PASS: pre-decision oracle-label read rejected; live source-1 forbidden-call traps survive; fresh oracle/census byte-identical')


if __name__ == '__main__':
    main()
