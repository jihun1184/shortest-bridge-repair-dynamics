# S2-COMP-02C19-D1 — Deep-History Decision Census

This package freezes the first deeper natural-closure history extension of the 02C18 residual decision law.

## External canonical dependencies

The package is portable and does not embed the large predecessors. Exact hashes are enforced by `s2comp02c19_base_env.py`:

- canonical 02C18 ZIP: `623b1a639b4549001c9b0091b5d3cb0dee4401d2b3afa54706f307c0508c521b`
- canonical 02C9 ZIP: `4ce99f3bb724b5da3b2731d3c60c82d8103713768e715e855585ea5d7c2f7a19`

Supply them with `--02c18` / `--02c9` or the corresponding environment variables.

## Frozen scope

Foundation registry:

- depth-1 histories: **1,988**
- immutable lineage transitions: **57,152**
- physical depth-2 states: **38,365**
- history transitions merged only at generator-cache level: **18,787**

Decision census:

- ordered overlap directions: **3,971,598**
- fully supplied: **55,041**
- partial residual: **3,916,557**

Partial-direction quadrants:

| geometry | local compatibility | count |
|---|---|---:|
| yes | yes | **50,091** |
| yes | no | **1,531** |
| no | yes | **3,126,558** |
| no | no | **738,377** |

Therefore:

- geometry-only false positives: **1,531**
- compatibility-only false positives: **3,126,558**
- generator mismatch: **0**
- local/global compatibility mismatch: **0**
- post-decision oracle-label reads: **3,971,598 / 3,971,598**

## Oracle/decider separation

`build_02c19_d1_oracle_shard.py` is allowed to call canonical generation and global compatibility because it builds the comparison oracle.

`run_02c19_d1_decider_shard.py` is not. In the theorem path:

- `canonical_actions` is runtime-trapped;
- global `has_fail` is runtime-trapped;
- `GuardedOracleLabel` rejects any label read before `mark_decision_complete()`;
- oracle `supported` / `compatible` bits are read only after the independent geometry + local-compatibility decision has been formed.

## Reproduction gates

Fast frozen regression:

```bash
PYTHONDONTWRITEBYTECODE=1 python test_02c19_d1_full_regression.py
```

Live source-1 separation + byte-identity gate:

```bash
PYTHONDONTWRITEBYTECODE=1 python test_02c19_d1_full_regression.py \
  --02c18 /path/to/canonical_02C18.zip \
  --02c9 /path/to/canonical_02C9.zip \
  --live-source1
```

Full raw rebuild of all oracle and decider shards:

```bash
./run_full_rebuild.sh /path/to/canonical_02C18.zip /path/to/canonical_02C9.zip
```

The full rebuild script compares every rebuilt oracle shard, decider shard, combined census, and analysis file byte-for-byte against the frozen files.

## Mechanism observations — not theorem claims

Across partial child states in the frozen full decider census:

- partial child states seen: **37,384**
- with multiple histories: **14,949**
- with multiple residuals: **37,048**
- geometry varies across residual lineages: **16,568**
- compatibility varies: **29,170**
- support varies: **16,548**
- joint geometry/compatibility outcome varies: **32,611**

These support a later mechanism investigation but are deliberately not promoted to a general theorem here.
