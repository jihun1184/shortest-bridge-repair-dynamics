from __future__ import annotations

import hashlib
import importlib
import os
import sys
import tempfile
import zipfile
from contextlib import contextmanager
from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parent

P18_NAME = "S2_COMP_02C18_FULL_TARGET_SCOPE_EXTENSION_20260831.zip"
P18_ROOT = "S2_COMP_02C18_FULL_TARGET_SCOPE_EXTENSION_20260831"
P18_SHA256 = "623b1a639b4549001c9b0091b5d3cb0dee4401d2b3afa54706f307c0508c521b"

P9_NAME = "S2_COMP_02C9_SOURCE24_SOURCE21_RANK26_30_EXHAUSTION_20260830.zip"
P9_SHA256 = "4ce99f3bb724b5da3b2731d3c60c82d8103713768e715e855585ea5d7c2f7a19"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _implicit_candidates(name: str):
    yield PACKAGE_ROOT / "source" / name
    yield PACKAGE_ROOT / name
    yield Path.cwd() / name


def _resolve_one(*, explicit: str | os.PathLike | None, env_name: str, name: str, expected_sha256: str) -> Path:
    # Explicit argument and environment variable are contracts: if supplied,
    # a missing file or wrong hash must fail rather than silently fall through.
    if explicit is not None:
        candidate = Path(explicit).expanduser().resolve()
        if not candidate.is_file():
            raise FileNotFoundError(f"{env_name} explicit dependency not found: {candidate}")
        actual = sha256(candidate)
        if actual != expected_sha256:
            raise AssertionError(
                f"{env_name} dependency hash mismatch: expected {expected_sha256}, got {actual} at {candidate}"
            )
        return candidate

    env_value = os.environ.get(env_name)
    if env_value:
        candidate = Path(env_value).expanduser().resolve()
        if not candidate.is_file():
            raise FileNotFoundError(f"{env_name} dependency not found: {candidate}")
        actual = sha256(candidate)
        if actual != expected_sha256:
            raise AssertionError(
                f"{env_name} dependency hash mismatch: expected {expected_sha256}, got {actual} at {candidate}"
            )
        return candidate

    for candidate in _implicit_candidates(name):
        if candidate.is_file():
            actual = sha256(candidate)
            if actual != expected_sha256:
                raise AssertionError(
                    f"implicit dependency hash mismatch for {candidate}: expected {expected_sha256}, got {actual}"
                )
            return candidate.resolve()

    raise FileNotFoundError(
        f"Missing canonical dependency {name}. Set ${env_name} or place it next to this package / in ./source/."
    )


def resolve_dependencies(p18: str | os.PathLike | None = None, p9: str | os.PathLike | None = None):
    return {
        "02C18": _resolve_one(
            explicit=p18,
            env_name="S2COMP_02C18_ZIP",
            name=P18_NAME,
            expected_sha256=P18_SHA256,
        ),
        "02C9": _resolve_one(
            explicit=p9,
            env_name="S2COMP_02C9_ZIP",
            name=P9_NAME,
            expected_sha256=P9_SHA256,
        ),
    }


def _purge_modules_under(prefixes: tuple[str, ...]):
    for name, mod in list(sys.modules.items()):
        modfile = getattr(mod, "__file__", None)
        if modfile and any(str(modfile).startswith(prefix) for prefix in prefixes):
            sys.modules.pop(name, None)
    for spath in list(sys.path):
        if any(str(spath).startswith(prefix) for prefix in prefixes):
            try:
                sys.path.remove(spath)
            except ValueError:
                pass


@contextmanager
def env02c19(p18: str | os.PathLike | None = None, p9: str | os.PathLike | None = None):
    deps = resolve_dependencies(p18=p18, p9=p9)
    old_p9 = os.environ.get("S2COMP_02C9_ZIP")
    old_dwb = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    os.environ["S2COMP_02C9_ZIP"] = str(deps["02C9"])

    with tempfile.TemporaryDirectory(prefix="s2comp02c19_") as td:
        temp_root = Path(td)
        with zipfile.ZipFile(deps["02C18"]) as archive:
            archive.extractall(temp_root / "p18")
        p18_root = temp_root / "p18" / P18_ROOT
        if not p18_root.is_dir():
            raise RuntimeError(f"02C18 extraction failed: expected {P18_ROOT}")

        sys.path.insert(0, str(p18_root))
        module = None
        try:
            module = importlib.import_module("s2comp02c18_env")
            yield {
                "dependencies": deps,
                "p18_root": p18_root,
                "env02c12": module.env02c12,
            }
        finally:
            if module is not None:
                temp_obj = getattr(module, "_TEMP", None)
                if temp_obj is not None:
                    try:
                        temp_obj.cleanup()
                    except Exception:
                        pass
            prefixes = (str(temp_root), "/tmp/s2comp02c18_", "/tmp/s2comp02c17_", "/tmp/s2comp02c12_", "/tmp/s2comp02c5_", "/tmp/s2comp02c4_")
            _purge_modules_under(prefixes)
            sys.modules.pop("s2comp02c18_env", None)
            if old_p9 is None:
                os.environ.pop("S2COMP_02C9_ZIP", None)
            else:
                os.environ["S2COMP_02C9_ZIP"] = old_p9
            sys.dont_write_bytecode = old_dwb
