from __future__ import annotations

import argparse
import json
import os
from collections import Counter
from pathlib import Path

from oracle_label_guard import GuardedOracleLabel
from lineage_identity import physical_state_key
from s2comp02c19_d1_env import env02c19_d1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--02c18", dest="p18")
    ap.add_argument("--02c9", dest="p9")
    ap.add_argument("--oracle", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()
    fixture = json.loads(Path(args.oracle).read_text())
    result = {
        "checkpoint": "S2-COMP-02C19-D1 deep-history theorem-decider shard",
        "oracle_use_contract": "oracle supported/compatible labels sealed until theorem decision is complete; post-decision comparison only",
        "forbidden_decision_calls": {"canonical_actions": False, "global_has_fail": False},
        "sources": [],
        "first_mismatches": [],
    }
    totals = Counter()
    child_mechanism = {}

    with env02c19_d1(args.p18, args.p9) as e:
        decider = e["decider"]
        with e["env02c12"]() as (frozen_env, _, _):
            with frozen_env() as outer:
                with outer.frozen.frozen_env() as env:
                    import finite_window_classification as fw
                    import c07d3e_component_viability as cv
                    if os.environ.get("S2COMP_02C19_D1_FORBIDDEN_CALL_TRAPS", "1") == "1":
                        def forbidden(*_a, **_kw):
                            raise AssertionError("forbidden generator/global compatibility call in 02C19-D1 theorem path")
                        env.pred["canonical_actions"] = forbidden
                        fw.has_fail = forbidden

                    endpoint_cache = {}
                    geometry_cache_global = {}
                    local_compat_cache = {}
                    for src in fixture["sources"]:
                        sid = int(src["source_state_index"])
                        st = Counter()
                        for h in src["histories"]:
                            node = frozenset(tuple(p) for p in h["node"])
                            actions = tuple(frozenset(tuple(p) for p in a) for a in h["actions"])
                            by_actor = {}
                            for ai, ti, code in h["directions"]:
                                by_actor.setdefault(ai, []).append((ti, code))
                            for ai, actor_rows in by_actor.items():
                                actor = actions[ai]
                                child = frozenset(node | actor)
                                child_key = physical_state_key(child)
                                if child_key not in endpoint_cache:
                                    certs = tuple(c for c in env.pred["extract_certificates"](child, env.api) if c.predicate == "N2_facet_connectivity")
                                    endpoint_cache[child_key] = decider.compile_child_geometry(certs, cv)
                                    st["endpoint_cache_misses"] += 1
                                else:
                                    st["endpoint_cache_hits"] += 1
                                endpoint_records = endpoint_cache[child_key]
                                for ti, raw_code in actor_rows:
                                    target = actions[ti]
                                    sealed = GuardedOracleLabel(raw_code)
                                    st["directions"] += 1
                                    residual = frozenset(target - actor)
                                    if not residual:
                                        got = {"decision": "fully_supplied", "geometry": None, "local_compatible": None, "supported_action": True}
                                        sealed.mark_decision_complete()
                                        oracle = sealed.read_for_comparison()
                                        if oracle["partial"]:
                                            raise AssertionError("oracle partial bit conflicts with independently derived empty residual")
                                        st["fully_supplied"] += 1
                                        st["support_or_fulfilled"] += 1
                                        st["oracle_label_reads_post_decision"] += sealed.read_count
                                        continue

                                    residual_key = tuple(sorted(residual))
                                    geometry_key = (child_key, residual_key)
                                    if geometry_key not in geometry_cache_global:
                                        geometry, witness = decider.chain_gap_exists_compiled(child, residual, endpoint_records)
                                        geometry_cache_global[geometry_key] = (geometry, witness)
                                        st["geometry_cache_misses"] += 1
                                    else:
                                        geometry, witness = geometry_cache_global[geometry_key]
                                        st["geometry_cache_hits"] += 1

                                    final = frozenset(node | actor | target)
                                    final_key = physical_state_key(final)
                                    delta_key = tuple(sorted(actor - frozenset(node | target)))
                                    local_key = (final_key, delta_key)
                                    if local_key not in local_compat_cache:
                                        compatible, delta, bad = decider.local_final_compatible(node, actor, target, fw)
                                        local_compat_cache[local_key] = (compatible, delta, bad)
                                        st["local_compat_cache_misses"] += 1
                                    else:
                                        compatible, delta, bad = local_compat_cache[local_key]
                                        st["local_compat_cache_hits"] += 1
                                    supported = geometry and compatible
                                    if supported:
                                        decision = "supported_residual"
                                    elif not geometry and compatible:
                                        decision = "no_geometry"
                                    elif geometry and not compatible:
                                        decision = "local_incompatible"
                                    else:
                                        decision = "no_geometry_and_local_incompatible"
                                    got = {
                                        "decision": decision,
                                        "geometry": geometry,
                                        "local_compatible": compatible,
                                        "supported_action": supported,
                                        "residual": residual_key,
                                        "delta": tuple(sorted(delta)),
                                        "local_bad_masks": bad,
                                        "geometry_witness": witness,
                                    }

                                    # Only now may comparison code see oracle supported/compatible labels.
                                    sealed.mark_decision_complete()
                                    oracle = sealed.read_for_comparison()
                                    if not oracle["partial"]:
                                        raise AssertionError("oracle partial bit conflicts with independently derived non-empty residual")

                                    st["partial"] += 1
                                    st[got["decision"]] += 1
                                    st["geometry_positive"] += int(got["geometry"])
                                    st["local_compatible"] += int(got["local_compatible"])
                                    st["support_or_fulfilled"] += int(got["supported_action"])
                                    gm = int(got["supported_action"] != oracle["supported"])
                                    cm = int(got["local_compatible"] != oracle["compatible"])
                                    st["generator_mismatch"] += gm
                                    st["compatibility_mismatch"] += cm
                                    st["oracle_label_reads_post_decision"] += sealed.read_count

                                    mech = child_mechanism.setdefault(child_key, {
                                        "histories": set(),
                                        "first_residual": residual_key,
                                        "multiple_residuals": False,
                                        "outcomes": set(),
                                        "geometries": set(),
                                        "compatibilities": set(),
                                        "supports": set(),
                                    })
                                    mech["histories"].add(h["history_key"])
                                    if residual_key != mech["first_residual"]:
                                        mech["multiple_residuals"] = True
                                    mech["outcomes"].add((bool(got["geometry"]), bool(got["local_compatible"])))
                                    mech["geometries"].add(bool(got["geometry"]))
                                    mech["compatibilities"].add(bool(got["local_compatible"]))
                                    mech["supports"].add(bool(got["supported_action"]))

                                    if (gm or cm) and len(result["first_mismatches"]) < 10:
                                        result["first_mismatches"].append({
                                            "source_state_index": sid,
                                            "history_key": h["history_key"],
                                            "actor_index": ai,
                                            "target_index": ti,
                                            "oracle": oracle,
                                            "got": got,
                                        })
                        result["sources"].append({"source_state_index": sid, "totals": dict(st)})
                        totals.update(st)
                        print(json.dumps({"source": sid, "totals": dict(st)}, sort_keys=True), flush=True)
    result["totals"] = dict(totals)
    result["merge_mechanism"] = {
        "partial_child_states_seen": len(child_mechanism),
        "child_states_with_multiple_histories": sum(len(v["histories"]) > 1 for v in child_mechanism.values()),
        "child_states_with_multiple_residuals": sum(v["multiple_residuals"] for v in child_mechanism.values()),
        "child_states_with_geometry_variation": sum(len(v["geometries"]) > 1 for v in child_mechanism.values()),
        "child_states_with_compatibility_variation": sum(len(v["compatibilities"]) > 1 for v in child_mechanism.values()),
        "child_states_with_support_variation": sum(len(v["supports"]) > 1 for v in child_mechanism.values()),
        "child_states_with_joint_outcome_variation": sum(len(v["outcomes"]) > 1 for v in child_mechanism.values()),
    }
    result["mismatch_count"] = totals["generator_mismatch"]
    result["compatibility_mismatch_count"] = totals["compatibility_mismatch"]
    Path(args.output).write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"output": args.output, "totals": result["totals"], "mismatches": len(result["first_mismatches"])}, indent=2, sort_keys=True))
    if totals["generator_mismatch"] or totals["compatibility_mismatch"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
