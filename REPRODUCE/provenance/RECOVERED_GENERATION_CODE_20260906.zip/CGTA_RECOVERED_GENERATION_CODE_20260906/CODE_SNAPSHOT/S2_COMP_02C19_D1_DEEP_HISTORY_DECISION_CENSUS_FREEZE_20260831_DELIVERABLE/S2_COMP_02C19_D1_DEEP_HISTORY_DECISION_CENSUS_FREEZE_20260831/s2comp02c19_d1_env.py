from __future__ import annotations

import hashlib
import importlib
import os
import sys
import tempfile
import zipfile
from contextlib import contextmanager
from pathlib import Path

HERE = Path(__file__).resolve().parent

P18_NAME = "S2_COMP_02C18_FULL_TARGET_SCOPE_EXTENSION_20260831.zip"
P18_ROOT = "S2_COMP_02C18_FULL_TARGET_SCOPE_EXTENSION_20260831"
P18_SHA256 = "623b1a639b4549001c9b0091b5d3cb0dee4401d2b3afa54706f307c0508c521b"
P9_NAME = "S2_COMP_02C9_SOURCE24_SOURCE21_RANK26_30_EXHAUSTION_20260830.zip"
P9_SHA256 = "4ce99f3bb724b5da3b2731d3c60c82d8103713768e715e855585ea5d7c2f7a19"
FOUNDATION_ZIP_SHA256 = "eb4c1ad519eeddbbce351898194f1dcd0d7e673fbd14d35c4ff06fa51a3d52a0"
REGISTRY_NAME = "02C19_D1_SCOPE_REGISTRY.json"
REGISTRY_SHA256 = "ef3a60d9f1cce0d5bddcaa6fe8c74e84bb5347c0edfd9c28afb3d51d429f4b92"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def assert_registry() -> Path:
    path = HERE / REGISTRY_NAME
    actual = sha256(path)
    if actual != REGISTRY_SHA256:
        raise AssertionError(f"registry hash mismatch: expected {REGISTRY_SHA256}, got {actual}")
    return path


def _resolve(explicit, env_name: str, filename: str, expected: str) -> Path:
    candidates = []
    if explicit:
        candidates = [Path(explicit).expanduser()]
    elif os.environ.get(env_name):
        candidates = [Path(os.environ[env_name]).expanduser()]
    else:
        candidates = [HERE / "source" / filename, HERE / filename, Path.cwd() / filename]
    for path in candidates:
        path = path.resolve()
        if not path.is_file():
            if explicit or os.environ.get(env_name):
                raise FileNotFoundError(f"{env_name} dependency not found: {path}")
            continue
        actual = sha256(path)
        if actual != expected:
            raise AssertionError(f"{env_name} hash mismatch: expected {expected}, got {actual} at {path}")
        return path
    raise FileNotFoundError(f"Missing canonical {filename}; set {env_name} or pass explicit path")


def resolve_dependencies(p18=None, p9=None):
    assert_registry()
    return {
        "02C18": _resolve(p18, "S2COMP_02C18_ZIP", P18_NAME, P18_SHA256),
        "02C9": _resolve(p9, "S2COMP_02C9_ZIP", P9_NAME, P9_SHA256),
    }


def _purge(prefixes):
    for name, mod in list(sys.modules.items()):
        f = getattr(mod, "__file__", None)
        if f and any(str(f).startswith(p) for p in prefixes):
            sys.modules.pop(name, None)
    for p in list(sys.path):
        if any(str(p).startswith(x) for x in prefixes):
            try:
                sys.path.remove(p)
            except ValueError:
                pass


@contextmanager
def env02c19_d1(p18=None, p9=None):
    deps = resolve_dependencies(p18, p9)
    old_p9 = os.environ.get("S2COMP_02C9_ZIP")
    old_dwb = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    os.environ["S2COMP_02C9_ZIP"] = str(deps["02C9"])
    with tempfile.TemporaryDirectory(prefix="s2comp02c19d1_") as td:
        root = Path(td)
        with zipfile.ZipFile(deps["02C18"]) as zf:
            zf.extractall(root / "p18")
        p18_root = root / "p18" / P18_ROOT
        if not p18_root.is_dir():
            raise RuntimeError(f"02C18 extraction missing {P18_ROOT}")
        sys.path.insert(0, str(p18_root))
        try:
            envmod = importlib.import_module("s2comp02c18_env")
            decider = importlib.import_module("full_scope_decider")
            yield {
                "dependencies": deps,
                "p18_root": p18_root,
                "env02c12": envmod.env02c12,
                "decider": decider,
            }
        finally:
            prefixes = (str(root), "/tmp/s2comp02c18_", "/tmp/s2comp02c17_", "/tmp/s2comp02c12_", "/tmp/s2comp02c5_", "/tmp/s2comp02c4_")
            _purge(prefixes)
            for name in ("full_scope_decider", "s2comp02c18_env"):
                sys.modules.pop(name, None)
            if old_p9 is None:
                os.environ.pop("S2COMP_02C9_ZIP", None)
            else:
                os.environ["S2COMP_02C9_ZIP"] = old_p9
            sys.dont_write_bytecode = old_dwb
