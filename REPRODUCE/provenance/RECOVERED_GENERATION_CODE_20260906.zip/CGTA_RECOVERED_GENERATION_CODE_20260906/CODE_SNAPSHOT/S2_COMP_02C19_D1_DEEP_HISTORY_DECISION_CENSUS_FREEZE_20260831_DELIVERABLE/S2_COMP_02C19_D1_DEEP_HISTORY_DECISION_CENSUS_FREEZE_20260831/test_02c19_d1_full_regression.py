from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent

EXPECTED_HASHES = {
    '02C19_D1_SCOPE_REGISTRY.json': 'ef3a60d9f1cce0d5bddcaa6fe8c74e84bb5347c0edfd9c28afb3d51d429f4b92',
    '02C19_D1_ORACLE_1_113.json': '5e5d7c5b8bbf80dd57907ed6acaa50bff89b0f64ea7f11e8b7d4cf35a1d10012',
    '02C19_D1_ORACLE_114.json': 'c6c4a765c77e2019a4fb1fa933e7ce975b703219f8c4628f1962b7baef203dfa',
    '02C19_D1_ORACLE_115.json': 'a4b3cd59c5e2712ca7eeaf8e49205e3021892851fd9ff8ae6a2ffbe8e873598c',
    'oracle_all.json': '740c00611ba1b408f8c9e97fc90264961b5381c357139c9b7b66e2d55be6d9ca',
    'census_1_113.json': '4d429a7db0490cecf44b514d42ab266b6451a728d0593a1632b28066c9485d7c',
    'census_114.json': '35e29dd6519b09c3b0b32bb0a607ee353302527982fdc929f6bd8037c236109b',
    'census_115.json': 'f979d32b78409ebaf88e5f919bb1778b2644adbaaf0769da9e600219ea5d8bdb',
    '02C19_D1_FULL_DECISION_CENSUS.json': '6961e9782a0db3bf76e80242ecde2b173e0fcda0a40712eba6e40191360c1d09',
    '02C19_D1_ANALYSIS.json': '604452780be4eb8312b98da88c28ebd09abe79b1f1837652495d070c16407300',
    'oracle_source1.json': '6e51ac07c30cf552b96de02ae5d81669d09556db69b448e7b484ed60dd647d0a',
    'census_source1_v2.json': '64fcadba71ebd8fc8b3b2479b2b5cfb5d71d3bebfc19d84e1dab273edfe62b02',
}

EXPECTED_ORACLE_TOTALS = {
    'directions': 3971598,
    'fully_supplied': 55041,
    'partial': 3916557,
    'oracle_supported': 50091,
    'oracle_compatible': 3176649,
    'child_generator_cache_misses': 38365,
    'child_generator_cache_hits': 18787,
    'global_compatibility_cache_misses': 1170410,
    'global_compatibility_cache_hits': 2746147,
}

EXPECTED_DECISION_TOTALS = {
    'directions': 3971598,
    'fully_supplied': 55041,
    'partial': 3916557,
    'supported_residual': 50091,
    'geometry_positive': 51622,
    'local_compatible': 3176649,
    'local_incompatible': 1531,
    'no_geometry': 3126558,
    'no_geometry_and_local_incompatible': 738377,
    'generator_mismatch': 0,
    'compatibility_mismatch': 0,
    'oracle_label_reads_post_decision': 3971598,
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def run(*args: str) -> None:
    subprocess.run([sys.executable, *args], cwd=HERE, check=True)


def assert_file_hashes() -> None:
    for name, expected in EXPECTED_HASHES.items():
        actual = sha256(HERE / name)
        if actual != expected:
            raise AssertionError(f'{name} hash mismatch: expected {expected}, got {actual}')


def assert_numeric_gates() -> None:
    oracle = json.loads((HERE / 'oracle_all.json').read_text())
    decision = json.loads((HERE / '02C19_D1_FULL_DECISION_CENSUS.json').read_text())
    analysis = json.loads((HERE / '02C19_D1_ANALYSIS.json').read_text())
    for k, v in EXPECTED_ORACLE_TOTALS.items():
        assert oracle['totals'].get(k) == v, (k, oracle['totals'].get(k), v)
    for k, v in EXPECTED_DECISION_TOTALS.items():
        assert decision['totals'].get(k) == v, (k, decision['totals'].get(k), v)
    assert decision['mismatch_count'] == 0
    assert decision['compatibility_mismatch_count'] == 0
    assert decision['totals']['oracle_label_reads_post_decision'] == decision['totals']['directions']
    q = analysis['quadrants']
    assert q == {
        'geometry_yes_compat_yes': 50091,
        'geometry_yes_compat_no': 1531,
        'geometry_no_compat_yes': 3126558,
        'geometry_no_compat_no': 738377,
    }
    assert sum(q.values()) == EXPECTED_ORACLE_TOTALS['partial']
    assert analysis['negative_controls'] == {
        'geometry_only_false_positives': 1531,
        'compatibility_only_false_positives': 3126558,
    }


def assert_deterministic_merges() -> None:
    with tempfile.TemporaryDirectory(prefix='s2comp02c19d1_reg_') as td_raw:
        td = Path(td_raw)
        oracle = td / 'oracle.json'
        census = td / 'census.json'
        analysis = td / 'analysis.json'
        run('merge_02c19_d1_oracles.py', '--inputs',
            '02C19_D1_ORACLE_1_113.json', '02C19_D1_ORACLE_114.json', '02C19_D1_ORACLE_115.json',
            '--output', str(oracle))
        run('merge_02c19_d1_decisions.py', '--inputs',
            'census_1_113.json', 'census_114.json', 'census_115.json', '--output', str(census))
        run('analyze_02c19_d1_census.py', '--decisions',
            'census_1_113.json', 'census_114.json', 'census_115.json', '--oracle',
            '02C19_D1_ORACLE_1_113.json', '02C19_D1_ORACLE_114.json', '02C19_D1_ORACLE_115.json',
            '--output', str(analysis))
        assert oracle.read_bytes() == (HERE / 'oracle_all.json').read_bytes()
        assert census.read_bytes() == (HERE / '02C19_D1_FULL_DECISION_CENSUS.json').read_bytes()
        assert analysis.read_bytes() == (HERE / '02C19_D1_ANALYSIS.json').read_bytes()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--02c18')
    ap.add_argument('--02c9')
    ap.add_argument('--live-source1', action='store_true')
    args = ap.parse_args()

    assert_file_hashes()
    assert_numeric_gates()
    assert_deterministic_merges()
    subprocess.run([sys.executable, str(HERE / 'check_hygiene.py'), str(HERE)], check=True)

    if args.live_source1:
        if not args.__dict__['02c18'] or not args.__dict__['02c9']:
            raise SystemExit('--live-source1 requires --02c18 and --02c9')
        subprocess.run([
            sys.executable, str(HERE / 'test_02c19_d1_separation.py'),
            '--02c18', args.__dict__['02c18'], '--02c9', args.__dict__['02c9'],
        ], cwd=HERE, check=True)

    print('PASS: frozen hashes, numeric theorem gates, deterministic oracle/census/analysis merges, and hygiene')


if __name__ == '__main__':
    main()
