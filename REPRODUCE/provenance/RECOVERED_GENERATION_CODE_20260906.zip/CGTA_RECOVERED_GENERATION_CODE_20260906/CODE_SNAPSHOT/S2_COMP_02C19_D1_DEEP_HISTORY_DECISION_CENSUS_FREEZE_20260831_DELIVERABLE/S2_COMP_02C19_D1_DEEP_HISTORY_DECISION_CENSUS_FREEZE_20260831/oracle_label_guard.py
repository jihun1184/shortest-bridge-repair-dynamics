from __future__ import annotations

from dataclasses import dataclass


@dataclass
class GuardedOracleLabel:
    """Oracle labels are sealed until theorem decision is complete.

    The raw compact code belongs to the comparison harness, not the theorem path.
    supported/compatible may only be opened after mark_decision_complete().
    """
    _code: int
    _decision_complete: bool = False
    _read_count: int = 0

    def mark_decision_complete(self) -> None:
        self._decision_complete = True

    def read_for_comparison(self) -> dict:
        if not self._decision_complete:
            raise AssertionError("oracle label read before theorem decision completed")
        self._read_count += 1
        return {
            "partial": bool(self._code & 1),
            "supported": bool(self._code & 2),
            "compatible": bool(self._code & 4),
        }

    @property
    def read_count(self) -> int:
        return self._read_count
