from __future__ import annotations
import argparse,json
from collections import Counter
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--inputs',nargs='+',required=True); ap.add_argument('--output',required=True); args=ap.parse_args()
    xs=[json.loads(Path(p).read_text()) for p in args.inputs]
    totals=Counter(); sources=[]; mism=[]; mech=Counter()
    for x in xs:
        totals.update(x['totals']); sources.extend(x['sources']); mism.extend(x.get('first_mismatches',[]))
        for k,v in x.get('merge_mechanism',{}).items(): mech[k]+=v
    sources.sort(key=lambda r:int(r['source_state_index']))
    y={
        'checkpoint':'S2-COMP-02C19-D1 deep-history combined decision census',
        'oracle_use_contract':'theorem decision is oracle-label blind; supported/compatible labels opened only after decision for comparison',
        'sources':sources,
        'totals':dict(totals),
        'merge_mechanism':dict(mech),
        'first_mismatches':mism[:10],
        'mismatch_count':totals['generator_mismatch'],
        'compatibility_mismatch_count':totals['compatibility_mismatch'],
    }
    Path(args.output).write_text(json.dumps(y,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'output':args.output,'totals':y['totals'],'merge_mechanism':y['merge_mechanism']},indent=2,sort_keys=True))
    if y['mismatch_count'] or y['compatibility_mismatch_count']: raise SystemExit(1)
if __name__=='__main__': main()
