# 02C19-D1 Claim Boundary

Status: **BOUNDED_EXHAUSTIVE_CLOSED** for the frozen 02C19-D1 domain only.

Let `Y_H` be one of the frozen depth-1 natural-closure history nodes in `02C19_D1_SCOPE_REGISTRY.json`. For an ordered pair of parent-supported N2 additions `(a,b)`, define

- `X_H = Y_H ∪ a`,
- `R = b \ a`,
- `F = Y_H ∪ a ∪ b`,
- `Δ = a \ (Y_H ∪ b)`.

For every registered **partial** direction (`R != ∅`) in the frozen 10-source 02C19-D1 census,

`canonical N2 support of R at X_H`

is equivalent to

`ChainGap_X_H(R;s,t) AND Bad_{I(Δ)}(F) = ∅`.

This was exhaustively compared on 3,916,557 partial directions, with generator mismatch 0 and local/global compatibility mismatch 0. A further 55,041 ordered directions were fully supplied (`R = ∅`) and are reported separately, for a total scope of 3,971,598 directions.

The theorem decider is oracle-label blind during decision formation. Precomputed oracle labels are sealed until the independent decision is complete; they are opened only for post-decision comparison. Canonical action generation and the global compatibility oracle are runtime-trapped in the theorem path.

This checkpoint does **not** claim:

- a result for deeper history depth beyond this frozen D1 scope;
- a theorem for arbitrary source states outside the frozen 10-source lineage;
- a new general mechanism theorem from the state/residual variation census;
- that history identity may be quotiented by physical state identity.

The mechanism counts in the analysis are bounded observations only.
