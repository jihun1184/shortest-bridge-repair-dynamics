from __future__ import annotations
import argparse, json
from collections import Counter
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--inputs', nargs='+', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()
    xs = [json.loads(Path(p).read_text()) for p in args.inputs]
    if not xs:
        raise SystemExit('no inputs')
    scope_hash = xs[0]['scope_registry_sha256']
    boundary = xs[0]['oracle_boundary']
    totals = Counter()
    sources = []
    for x in xs:
        assert x['checkpoint'] == xs[0]['checkpoint']
        assert x['scope_registry_sha256'] == scope_hash
        assert x['oracle_boundary'] == boundary
        totals.update(x['totals'])
        sources.extend(x['sources'])
    sources.sort(key=lambda r: int(r['source_state_index']))
    out = {
        'checkpoint': xs[0]['checkpoint'],
        'scope_registry_sha256': scope_hash,
        'oracle_boundary': boundary,
        'sources': sources,
        'totals': dict(totals),
    }
    Path(args.output).write_text(json.dumps(out, separators=(',', ':')) + '\n')
    print(json.dumps({'output': args.output, 'totals': out['totals']}, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
