from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

from s2comp02c19_d1_env import REGISTRY_SHA256, env02c19_d1

HERE = Path(__file__).resolve().parent


def canon(points):
    return tuple(sorted(tuple(p) for p in points))


def load_registry():
    return json.loads((HERE / "02C19_D1_SCOPE_REGISTRY.json").read_text())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--02c18", dest="p18")
    ap.add_argument("--02c9", dest="p9")
    ap.add_argument("--sources", required=True, help="comma-separated source ids")
    ap.add_argument("--output", required=True)
    args = ap.parse_args()
    wanted = {int(x) for x in args.sources.split(",") if x.strip()}
    registry = load_registry()

    result = {
        "checkpoint": "S2-COMP-02C19-D1 deep-history oracle shard",
        "scope_registry_sha256": REGISTRY_SHA256,
        "oracle_boundary": "canonical child generator and global has_fail are oracle-builder-only; theorem decider never calls them",
        "sources": [],
    }
    totals = Counter()

    with env02c19_d1(args.p18, args.p9) as e:
        with e["env02c12"]() as (frozen_env, _, _):
            with frozen_env() as outer:
                with outer.frozen.frozen_env() as env:
                    import finite_window_classification as fw
                    generator_cache = {}
                    compatibility_cache = {}
                    for src in registry["sources"]:
                        sid = int(src["source_state_index"])
                        if sid not in wanted:
                            continue
                        parent = frozenset(tuple(p) for p in src["parent"])
                        source_totals = Counter()
                        histories_out = []
                        for h in src["histories"]:
                            root_actor = frozenset(tuple(p) for p in h["actor_sequence"][0])
                            node = frozenset(parent | root_actor)
                            actions = tuple(frozenset(tuple(p) for p in t["additions"]) for t in h["targets"])
                            lineage_ids = tuple(t["lineage_id"] for t in h["targets"])
                            rows = []
                            for actor_index, actor in enumerate(actions):
                                child = frozenset(node | actor)
                                child_key = canon(child)
                                if child_key not in generator_cache:
                                    certs = tuple(c for c in env.pred["extract_certificates"](child, env.api) if c.predicate == "N2_facet_connectivity")
                                    child_actions = tuple(a for a in env.pred["canonical_actions"](child, env.api, certs) if "N2" in a.roles)
                                    generator_cache[child_key] = {canon(a.additions) for a in child_actions}
                                    source_totals["child_generator_cache_misses"] += 1
                                else:
                                    source_totals["child_generator_cache_hits"] += 1
                                supported_lookup = generator_cache[child_key]
                                for target_index, target in enumerate(actions):
                                    if actor_index == target_index or not (actor & target):
                                        continue
                                    residual = frozenset(target - actor)
                                    source_totals["directions"] += 1
                                    if not residual:
                                        rows.append([actor_index, target_index, 0])
                                        source_totals["fully_supplied"] += 1
                                        continue
                                    final_key = canon(node | actor | target)
                                    if final_key not in compatibility_cache:
                                        compatibility_cache[final_key] = not fw.has_fail(frozenset(node | actor | target))
                                        source_totals["global_compatibility_cache_misses"] += 1
                                    else:
                                        source_totals["global_compatibility_cache_hits"] += 1
                                    compatible = compatibility_cache[final_key]
                                    supported = canon(residual) in supported_lookup
                                    code = 1 | (int(supported) << 1) | (int(compatible) << 2)
                                    rows.append([actor_index, target_index, code])
                                    source_totals["partial"] += 1
                                    source_totals["oracle_supported"] += int(supported)
                                    source_totals["oracle_compatible"] += int(compatible)
                            histories_out.append({
                                "history_key": h["history_key"],
                                "node": canon(node),
                                "physical_state_key": h["physical_state_key"],
                                "actions": [canon(a) for a in actions],
                                "lineage_ids": list(lineage_ids),
                                "directions": rows,
                            })
                        result["sources"].append({"source_state_index": sid, "totals": dict(source_totals), "histories": histories_out})
                        totals.update(source_totals)
                        print(json.dumps({"source": sid, "totals": dict(source_totals)}, sort_keys=True), flush=True)
    result["totals"] = dict(totals)
    Path(args.output).write_text(json.dumps(result, separators=(",", ":")) + "\n")
    print(json.dumps({"output": args.output, "totals": result["totals"]}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
