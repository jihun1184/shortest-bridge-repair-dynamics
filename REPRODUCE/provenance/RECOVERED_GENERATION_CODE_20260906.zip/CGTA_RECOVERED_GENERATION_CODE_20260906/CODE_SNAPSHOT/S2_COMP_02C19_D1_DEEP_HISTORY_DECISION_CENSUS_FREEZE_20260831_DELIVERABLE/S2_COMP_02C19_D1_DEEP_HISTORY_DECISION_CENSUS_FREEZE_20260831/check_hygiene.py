from __future__ import annotations
from pathlib import Path

ROOT = Path(__file__).resolve().parent
bad = []
needles = ('/mnt' + '/data/', '/ho' + 'me/')
for p in ROOT.rglob('*'):
    if '__pycache__' in p.parts or p.suffix == '.pyc':
        bad.append(str(p.relative_to(ROOT)))
for p in ROOT.rglob('*'):
    if p.is_file() and p.suffix in {'.py', '.md', '.sh', '.json', '.txt'} and p.name != 'SHA256SUMS.txt':
        try:
            text = p.read_text()
        except UnicodeDecodeError:
            continue
        for needle in needles:
            if needle in text:
                bad.append(f'{p.relative_to(ROOT)}: machine-specific absolute path')
if bad:
    print('\n'.join(bad))
    raise SystemExit(1)
print('PASS: no pycache/pyc or machine-specific absolute-path leaks')
