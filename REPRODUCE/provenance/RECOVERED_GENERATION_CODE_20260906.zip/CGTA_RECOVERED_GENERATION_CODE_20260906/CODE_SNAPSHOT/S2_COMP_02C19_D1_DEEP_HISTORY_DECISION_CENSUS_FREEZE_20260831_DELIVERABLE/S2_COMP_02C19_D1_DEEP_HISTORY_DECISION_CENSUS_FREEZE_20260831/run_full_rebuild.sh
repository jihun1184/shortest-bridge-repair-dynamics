#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 2 || $# -gt 3 ]]; then
  echo "usage: $0 /path/to/canonical_02C18.zip /path/to/canonical_02C9.zip [output_dir]" >&2
  exit 2
fi

P18="$1"
P9="$2"
OUT="${3:-02c19_d1_full_rebuild}"
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$OUT"
export PYTHONDONTWRITEBYTECODE=1

python "$HERE/build_02c19_d1_oracle_shard.py" --02c18 "$P18" --02c9 "$P9" --sources 1,2,4,7,40,41,112,113 --output "$OUT/oracle_1_113.json"
python "$HERE/build_02c19_d1_oracle_shard.py" --02c18 "$P18" --02c9 "$P9" --sources 114 --output "$OUT/oracle_114.json"
python "$HERE/build_02c19_d1_oracle_shard.py" --02c18 "$P18" --02c9 "$P9" --sources 115 --output "$OUT/oracle_115.json"
python "$HERE/merge_02c19_d1_oracles.py" --inputs "$OUT/oracle_1_113.json" "$OUT/oracle_114.json" "$OUT/oracle_115.json" --output "$OUT/oracle_all.json"

S2COMP_02C19_D1_FORBIDDEN_CALL_TRAPS=1 python "$HERE/run_02c19_d1_decider_shard.py" --02c18 "$P18" --02c9 "$P9" --oracle "$OUT/oracle_1_113.json" --output "$OUT/census_1_113.json"
S2COMP_02C19_D1_FORBIDDEN_CALL_TRAPS=1 python "$HERE/run_02c19_d1_decider_shard.py" --02c18 "$P18" --02c9 "$P9" --oracle "$OUT/oracle_114.json" --output "$OUT/census_114.json"
S2COMP_02C19_D1_FORBIDDEN_CALL_TRAPS=1 python "$HERE/run_02c19_d1_decider_shard.py" --02c18 "$P18" --02c9 "$P9" --oracle "$OUT/oracle_115.json" --output "$OUT/census_115.json"
python "$HERE/merge_02c19_d1_decisions.py" --inputs "$OUT/census_1_113.json" "$OUT/census_114.json" "$OUT/census_115.json" --output "$OUT/full_decision_census.json"
python "$HERE/analyze_02c19_d1_census.py" --decisions "$OUT/census_1_113.json" "$OUT/census_114.json" "$OUT/census_115.json" --oracle "$OUT/oracle_1_113.json" "$OUT/oracle_114.json" "$OUT/oracle_115.json" --output "$OUT/analysis.json"

cmp "$OUT/oracle_1_113.json" "$HERE/02C19_D1_ORACLE_1_113.json"
cmp "$OUT/oracle_114.json" "$HERE/02C19_D1_ORACLE_114.json"
cmp "$OUT/oracle_115.json" "$HERE/02C19_D1_ORACLE_115.json"
cmp "$OUT/oracle_all.json" "$HERE/oracle_all.json"
cmp "$OUT/census_1_113.json" "$HERE/census_1_113.json"
cmp "$OUT/census_114.json" "$HERE/census_114.json"
cmp "$OUT/census_115.json" "$HERE/census_115.json"
cmp "$OUT/full_decision_census.json" "$HERE/02C19_D1_FULL_DECISION_CENSUS.json"
cmp "$OUT/analysis.json" "$HERE/02C19_D1_ANALYSIS.json"

echo "PASS: full raw oracle + forbidden-call decider rebuild is byte-identical to frozen artifacts"
