from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Iterable, Sequence

Point = tuple[int, int, int]
AdditionSet = tuple[Point, ...]


def canonical_additions(points: Iterable[Sequence[int]]) -> AdditionSet:
    return tuple(sorted({tuple(map(int, p)) for p in points}))


def _digest(payload) -> str:
    raw = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()
    return hashlib.sha256(raw).hexdigest()


def physical_state_key(state: Iterable[Sequence[int]]) -> str:
    return _digest([list(p) for p in canonical_additions(state)])


def history_key(source_state_index: int, actor_sequence: Iterable[Iterable[Sequence[int]]]) -> str:
    seq = [[list(p) for p in canonical_additions(actor)] for actor in actor_sequence]
    return _digest({"source_state_index": int(source_state_index), "actor_sequence": seq})


@dataclass(frozen=True)
class ResidualLineage:
    """Stable target identity across state changes.

    The root target and origin history remain immutable. `residual` changes as
    actors supply literals. Therefore two distinct root targets can reach the
    same current residual without being incorrectly merged.
    """

    source_state_index: int
    origin_history_key: str
    root_target: AdditionSet
    residual: AdditionSet

    @classmethod
    def root(cls, source_state_index: int, origin_history_key: str, target) -> "ResidualLineage":
        target_key = canonical_additions(target)
        return cls(int(source_state_index), origin_history_key, target_key, target_key)

    def transport(self, actor) -> "ResidualLineage":
        actor_set = set(canonical_additions(actor))
        return ResidualLineage(
            self.source_state_index,
            self.origin_history_key,
            self.root_target,
            canonical_additions(p for p in self.residual if p not in actor_set),
        )

    @property
    def supplied(self) -> bool:
        return not self.residual

    @property
    def lineage_id(self) -> str:
        """Immutable identity of the transported target lineage."""
        return _digest(
            {
                "source_state_index": self.source_state_index,
                "origin_history_key": self.origin_history_key,
                "root_target": [list(p) for p in self.root_target],
            }
        )

    @property
    def lineage_state_key(self) -> str:
        """State-specific snapshot key; changes when the residual changes."""
        return _digest(
            {
                "lineage_id": self.lineage_id,
                "residual": [list(p) for p in self.residual],
            }
        )
