from __future__ import annotations

import argparse
import json
from pathlib import Path

from s2comp02c9_inputs import (
    PACKAGE_ROOT,
    assert_execution_dependencies,
    load_frozen_selection,
    load_prior_registry,
)


RANKS = [26, 27, 28, 29, 30]
EXPECTED = {
    26: (24, 2920, 52, [1, 19, 33], [19, 20, 0]),
    27: (24, 2914, 52, [1, 19, 33], [19, 20, 0]),
    28: (24, 2861, 52, [1, 19, 33], [19, 20, 0]),
    29: (21, 6929, 76, [1, 26, 50], [26, 35, 0]),
    30: (24, 2776, 52, [1, 19, 33], [19, 20, 0]),
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", default=str(PACKAGE_ROOT))
    parser.add_argument("--out", default=str(PACKAGE_ROOT / "s2comp02c9_audit_results.json"))
    args = parser.parse_args()
    root = Path(args.package_root)
    failures = []
    assert_execution_dependencies()
    prior = load_prior_registry()
    selection = load_frozen_selection()
    census = json.loads((root / "s2comp02c9_signature_census.json").read_text())
    registry = json.loads((root / "cell_status_registry.json").read_text())

    if census["failure_count"] or census["target_count"] != 5:
        failures.append(["signature_census_failure"])
    if census["source_actor_counts"] != {"21": 409, "24": 355}:
        failures.append(["source_actor_count_regression", census["source_actor_counts"]])
    if census["outcome_signature_class_count"] != 5:
        failures.append(["full_outcome_signature_class_regression"])
    if census["survivor_actor_set_class_count"] != 2:
        failures.append(["survivor_actor_set_class_regression"])
    if census["selected_ranks"] != RANKS:
        failures.append(["selected_rank_rule_mismatch", census["selected_ranks"]])

    rows = {row["structural_rank"]: row for row in census["rows"]}
    source24_survivor_hashes = {
        rows[rank]["survivor_actor_set_sha256"] for rank in (26, 27, 28, 30)
    }
    source24_outcome_hashes = {
        rows[rank]["outcome_signature_sha256"] for rank in (26, 27, 28, 30)
    }
    if len(source24_survivor_hashes) != 1 or len(source24_outcome_hashes) != 4:
        failures.append(["source24_signature_control_regression"])

    summaries = {}
    closures = {}
    for rank in RANKS:
        closure = json.loads(
            (root / "results" / f"s2comp02c9_rank{rank}_closure.json").read_text()
        )
        exact = json.loads(
            (root / "results" / f"s2comp02c9_rank{rank}_exact.json").read_text()
        )
        expected_source, transitions, survivors, active, unique = EXPECTED[rank]
        expected_target = selection["structural_priority_top"][rank - 1]["target_literal"]
        totals = closure["totals"]
        if closure["source_state_index"] != expected_source or closure["target"] != expected_target:
            failures.append(["domain_mismatch", rank])
        if closure["failure_count"] or not totals["closure_exhausted"]:
            failures.append(["closure_failure", rank])
        observed_active = [row["active_parent_paths"] for row in closure["depth_rows"]]
        observed_unique = [
            row["unique_continuous_b_survivor_states"] for row in closure["depth_rows"]
        ]
        if (
            totals["target_disjoint_n2_transitions"] != transitions
            or totals["continuous_b_survivor_transitions"] != survivors
            or observed_active != active
            or observed_unique != unique
        ):
            failures.append(["closure_regression", rank])
        for key in (
            "anchor_extinction_hit_count",
            "local_converse_hit_count",
            "independent_r2_survivor_transition_count",
            "unstable_target_r1_survivor_transition_count",
        ):
            if totals[key] != 0:
                failures.append(["unexpected_open_hit", rank, key, totals[key]])
        if exact["failure_count"] or exact["verified_count"] != 0:
            failures.append(["exact_regression", rank])
        closures[rank] = closure
        summaries[f"rank{rank}"] = {
            "source_state_index": expected_source,
            "transitions": transitions,
            "survivors": survivors,
            "active_parent_paths": active,
            "unique_survivor_states": unique,
        }

    source24_transition_counts = [EXPECTED[rank][1] for rank in (26, 27, 28, 30)]
    if len(set(source24_transition_counts)) != 4:
        failures.append(["equal_survivor_set_control_not_load_bearing"])
    for rank in RANKS:
        row = closures[rank]["depth_rows"][1]
        if row["continuing_stable_anchor_paths"] <= row["unique_continuous_b_survivor_states"]:
            failures.append(["path_vs_state_control_not_load_bearing", rank])

    if registry["cells"] != prior["cells"]:
        failures.append(["registry_cells_or_history_mutated"])
    if registry["lineage_searches"][: len(prior["lineage_searches"])] != prior["lineage_searches"]:
        failures.append(["registry_prior_search_history_mutated"])
    if registry["lineage_open_patterns"][: len(prior["lineage_open_patterns"])] != prior["lineage_open_patterns"]:
        failures.append(["registry_prior_open_history_mutated"])
    c9_searches = [
        entry for entry in registry["lineage_searches"] if entry["checkpoint"] == "S2-COMP-02C9"
    ]
    c9_open = [
        entry
        for entry in registry["lineage_open_patterns"]
        if entry["checkpoint"] == "S2-COMP-02C9"
    ]
    if len(c9_searches) != 5:
        failures.append(["registry_search_count", len(c9_searches)])
    if (
        len(c9_open) != 2
        or any(
            entry["status"] != "NOT_YET_OBSERVED" or entry["bounded_count"] != 0
            for entry in c9_open
        )
    ):
        failures.append(["registry_open_boundary"])

    result = {
        "checkpoint": "S2-COMP-02C9",
        "kind": "source24_source21_rank26_30_exhaustion_audit",
        "status": "BOUNDED_EXHAUSTIVE_CLOSED" if not failures else "FAILED",
        "signature_census": {
            "structural_rank_range": [26, 30],
            "targets": 5,
            "source_actor_counts": census["source_actor_counts"],
            "outcome_signature_classes": 5,
            "survivor_actor_set_classes": 2,
            "selected_ranks": RANKS,
        },
        "closure_summaries": summaries,
        "source24_equal_survivor_set_control": {
            "ranks": [26, 27, 28, 30],
            "same_survivor_actor_set": len(source24_survivor_hashes) == 1,
            "same_active_parent_paths": True,
            "active_parent_paths": [1, 19, 33],
            "transition_counts": source24_transition_counts,
            "all_transition_counts_distinct": len(set(source24_transition_counts)) == 4,
        },
        "path_vs_state_controls": {
            f"rank{rank}": {
                "depth": 2,
                "continuing_lineage_paths": closures[rank]["depth_rows"][1][
                    "continuing_stable_anchor_paths"
                ],
                "unique_survivor_states": closures[rank]["depth_rows"][1][
                    "unique_continuous_b_survivor_states"
                ],
            }
            for rank in RANKS
        },
        "totals": {
            "target_specific_transition_sum": sum(value[1] for value in EXPECTED.values()),
            "continuous_survivor_transition_sum": sum(value[2] for value in EXPECTED.values()),
            "anchor_extinction_hits": 0,
            "local_converse_hits": 0,
            "independent_r2_hits": 0,
            "unstable_target_r1_hits": 0,
        },
        "scope_exclusions": ["target-overlap actors", "non-N2 actions"],
        "failure_count": len(failures),
        "failures": failures,
    }
    Path(args.out).write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))
    raise SystemExit(0 if not failures else 1)


if __name__ == "__main__":
    main()
