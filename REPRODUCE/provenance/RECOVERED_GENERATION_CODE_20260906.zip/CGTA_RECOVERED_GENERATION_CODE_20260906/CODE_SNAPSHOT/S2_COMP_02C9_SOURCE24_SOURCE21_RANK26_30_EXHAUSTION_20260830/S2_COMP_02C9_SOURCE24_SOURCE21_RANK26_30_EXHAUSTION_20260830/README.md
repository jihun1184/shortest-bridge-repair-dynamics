# S2-COMP-02C9 — Source-24/21 Frozen Ranks 26–30 Exhaustion

Status: **BOUNDED_EXHAUSTIVE_CLOSED**

Immediate immutable predecessor:
`source/S2_COMP_02C8_SOURCE26_SIGNATURE_STRATIFIED_EXHAUSTION_20260830_SANITIZED_REPAIR.zip`

Expected SHA-256:
`a5507c0583a2a082ffaeb381d8ed4ef3e0843861be2882de4cbae496b4567a1b`

Embedded 02C7 lineage asserted through the predecessor:
`115ae4e199b1ca4e7437423f234d9718cbf751ef2644f1a203305fd2da864817`

Direct execution dependency:
`source/S2_COMP_02C4_RESCUE_EXISTENCE_BOUNDARY_20260830.zip`

Expected SHA-256:
`b119ca582a6b07158399ffd77ee52b4683453da9621f019b49ce379e0253fbdd`

02C9 exhausts all five target-specific N2 actor-history domains at frozen
structural ranks 26–30. Ranks 26, 27, 28, and 30 use source state 24; rank 29
uses source state 21. Target-overlap actors and non-N2 actions remain excluded
evidence buckets.

## Main bounded result

```text
depth-1 census: 5 targets / 1,829 actor-target cases
source 24: 355 N2 actors per target
source 21: 409 N2 actors per target
full-outcome signature classes: 5
survivor-actor-set classes: 2

exhaustive closures: ranks 26,27,28,29,30
target-specific transitions = 18,400
continuous survivors        =    284
anchor extinction           =      0
local-converse/no-stable    =      0
independent R2              =      0
unstable-target R1          =      0
all five closures exhausted naturally at depth 3
```

The four source-24 targets share the same survivor actor set and active path
counts `[1,19,33]`, yet their transition totals are respectively
`2,920`, `2,914`, `2,861`, and `2,776`. Signature equality and equal path-count
profiles are therefore controls, not deeper-closure equivalence or pruning
rules.

## Reproduce

Use `-B` so validation does not create bytecode in the package tree.

```bash
sha256sum -c SHA256SUMS.txt

python3 -B run_s2comp02c9_signature_census.py \
  --out /tmp/s2comp02c9_census.json

python3 -B run_s2comp02c9_all_closures.py \
  --out-dir /tmp/s2comp02c9_closures

for spec in '26 24' '27 24' '28 24' '29 21' '30 24'; do
  set -- $spec
  python3 -B run_exact_confirmation.py \
    --closure-json "/tmp/s2comp02c9_closures/s2comp02c9_rank${1}_closure.json" \
    --source-index "$2" \
    --label-prefix "d7b_alt_$(printf '%03d' "$2")_rank${1}" \
    --out "/tmp/s2comp02c9_rank${1}_exact.json"
done

python3 -B run_s2comp02c9_registry_build.py --out /tmp/s2comp02c9_registry.json
python3 -B run_s2comp02c9_audit.py --out /tmp/s2comp02c9_audit.json
python3 -B run_s2comp02c9_smoke_gate.py --out /tmp/s2comp02c9_smoke.json
```

All five closures, all five exact confirmations, census, registry, audit, and
smoke were fresh-rerun and compared byte-for-byte before packaging.

See `CLAIM_BOUNDARY.md` and `PACKAGING_SCOPE.md`. No zero count is promoted to
a universal impossibility theorem.
