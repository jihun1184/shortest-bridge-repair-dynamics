from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path


PACKAGE_ROOT = Path(__file__).resolve().parent
PREDECESSOR_NAME = (
    "S2_COMP_02C8_SOURCE26_SIGNATURE_STRATIFIED_EXHAUSTION_20260830_"
    "SANITIZED_REPAIR.zip"
)
PREDECESSOR_ROOT = "S2_COMP_02C8_SOURCE26_SIGNATURE_STRATIFIED_EXHAUSTION_20260830"
PREDECESSOR_SHA256 = "a5507c0583a2a082ffaeb381d8ed4ef3e0843861be2882de4cbae496b4567a1b"
PREDECESSOR_REGISTRY_SHA256 = "4657092ffce2157c5a7d6da331e982bbe844aea1cd7e2dd67b6836ae6190eb64"
PREDECESSOR_SELECTION_SHA256 = "ae6938bec10db3e6a70391df4c706d8902a5d52f86ae83f08f094ac342a0df83"
PREDECESSOR_CENSUS_SHA256 = "0f4fc1c0a4ae3dc420fbe5847535ebf0e0a84f0ba451a1958f924a89c33105cc"
EMBEDDED_02C7_NAME = "source/S2_COMP_02C7_DETERMINISTIC_N2_DOMAIN_EXTENSION_20260830.zip"
EMBEDDED_02C7_SHA256 = "115ae4e199b1ca4e7437423f234d9718cbf751ef2644f1a203305fd2da864817"
C4_NAME = "S2_COMP_02C4_RESCUE_EXISTENCE_BOUNDARY_20260830.zip"
C4_SHA256 = "b119ca582a6b07158399ffd77ee52b4683453da9621f019b49ce379e0253fbdd"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def assert_execution_dependencies() -> None:
    predecessor = PACKAGE_ROOT / "source" / PREDECESSOR_NAME
    c4 = PACKAGE_ROOT / "source" / C4_NAME
    if sha256_file(predecessor) != PREDECESSOR_SHA256:
        raise AssertionError("02C8 sanitized predecessor hash mismatch")
    if sha256_file(c4) != C4_SHA256:
        raise AssertionError("02C4 execution dependency hash mismatch")
    with zipfile.ZipFile(predecessor) as archive:
        embedded = archive.read(f"{PREDECESSOR_ROOT}/{EMBEDDED_02C7_NAME}")
    if sha256_bytes(embedded) != EMBEDDED_02C7_SHA256:
        raise AssertionError("embedded 02C7 lineage hash mismatch")


def read_predecessor_member(relative_path: str, expected_sha256: str) -> bytes:
    assert_execution_dependencies()
    predecessor = PACKAGE_ROOT / "source" / PREDECESSOR_NAME
    with zipfile.ZipFile(predecessor) as archive:
        data = archive.read(f"{PREDECESSOR_ROOT}/{relative_path}")
    if sha256_bytes(data) != expected_sha256:
        raise AssertionError(f"02C8 predecessor member hash mismatch: {relative_path}")
    return data


def load_prior_registry() -> dict:
    return json.loads(
        read_predecessor_member("cell_status_registry.json", PREDECESSOR_REGISTRY_SHA256)
    )


def load_frozen_selection() -> dict:
    return json.loads(
        read_predecessor_member(
            "s2comp02c7_domain_selection.json", PREDECESSOR_SELECTION_SHA256
        )
    )


def load_predecessor_census() -> dict:
    return json.loads(
        read_predecessor_member(
            "s2comp02c8_signature_census.json", PREDECESSOR_CENSUS_SHA256
        )
    )
