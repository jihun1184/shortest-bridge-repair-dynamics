from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

from s2comp02c5_env import frozen_env
from s2comp02c5_domains import eligible_n2_actors  # noqa: F401 (kept for parity; not directly used, logic inlined below)
from s2comp02c5_multistep import (
    n2_target_index,
    initialize_tracks,
    advance_tracks,
    local_mechanism,
)


def serial_additions(additions):
    return [list(p) for p in additions]


def path_id(path):
    raw = json.dumps(path, separators=(",", ":"), sort_keys=True).encode()
    return "p-" + hashlib.sha256(raw).hexdigest()[:16]


def run(source_state_index: int, target: tuple):
    """Exact reimplementation of run_s2comp02c5_audit.run(), generalized to an
    arbitrary D7B alternate first-successor source index and target literal.

    No logic changed from run_s2comp02c5_audit.py other than:
      - source_state_index / target passed as parameters instead of hardcoded
      - the two source-10-specific regression assertions (02C4_state10_r2_regression,
        frozen_closure_regression) are dropped, since they only apply to source 10.
    All memoization / dedup / continuation / anchor-tracking rules are identical.

    NOTE: this opens its own frozen_env(). Calling this function (or the module-
    level `run`) more than once within the SAME process re-imports s2comp02c4_env
    from a NEW temp directory, but Python's sys.modules cache returns the ALREADY
    imported module object bound to the FIRST (by-then-deleted) temp directory,
    causing FileNotFoundError on the second call. Callers that need multiple
    closures in one process must use `run_with_env` with a single shared
    frozen_env()/frozen_env() pair instead of calling `run` repeatedly.
    """
    with frozen_env() as outer:
        with outer.frozen.frozen_env() as env:
            return run_with_env(outer, env, source_state_index, target)


def run_with_env(outer, env, source_state_index: int, target: tuple):
    """Core closure logic, reusable across multiple (source_index, target)
    computations against a single already-open frozen_env()/frozen_env() pair."""
    failures = []
    if True:
        if True:
            root, root_meta = outer.domains.d7b_alternate_first_successor(env, source_state_index)
            cache = {}
            actor_cache = {}
            root_index = n2_target_index(root, target, env, cache)
            root_support_count = len(root_index["target_supporters"])
            tracks = initialize_tracks(root_index)

            active = [{
                "state": root,
                "tracks": tracks,
                "path": tuple(),
            }]
            depth_rows = []
            extinction_hits = []
            local_converse_hits = []
            all_survivor_mechanisms = Counter()
            representative_r2 = []

            for depth in range(1, 32):
                next_active = []
                transitions = 0
                b_survivors = 0
                unique_children = set()
                unique_survivor_states = set()
                overlap_excluded = 0
                independent_r2_count = 0
                unstable_r1_count = 0
                no_immediate_stable_count = 0
                stable_anchor_hist = Counter()

                active.sort(key=lambda row: tuple((step["actor_index"], tuple(tuple(p) for p in step["actor_additions"])) for step in row["path"]))
                for parent in active:
                    state = parent["state"]
                    current_index = n2_target_index(state, target, env, cache)
                    certs = current_index["certificates"]
                    state_key = tuple(sorted(state))
                    if state_key not in actor_cache:
                        all_n2_cached = tuple(a for a in env.pred["canonical_actions"](state, env.api, certs) if "N2" in a.roles)
                        actors_cached = tuple(a for a in all_n2_cached if set(a.additions).isdisjoint(target))
                        additions = [a.additions for a in actors_cached]
                        if additions != sorted(additions):
                            failures.append(["eligible_N2_actor_order_not_lexicographic", depth, path_id(parent["path"])])
                        actor_cache[state_key] = (all_n2_cached, actors_cached)
                    all_n2, actors = actor_cache[state_key]
                    overlap_excluded += len(all_n2) - len(actors)
                    for actor_index, actor in enumerate(actors):
                        transitions += 1
                        successor = frozenset(state | set(actor.additions))
                        unique_children.add(tuple(sorted(successor)))
                        successor_index = n2_target_index(successor, target, env, cache)
                        b_now = bool(successor_index["target_supporters"])
                        if not b_now:
                            continue
                        b_survivors += 1
                        unique_survivor_states.add(tuple(sorted(successor)))
                        mechanism = local_mechanism(state, successor, current_index, successor_index, env)
                        if mechanism["independent_r2_present"]:
                            independent_r2_count += 1
                        if mechanism["unstable_target_r1_present"]:
                            unstable_r1_count += 1
                        if mechanism["stable_old_target_support_count"] == 0:
                            no_immediate_stable_count += 1
                        all_survivor_mechanisms[(
                            mechanism["stable_old_target_support_count"] > 0,
                            mechanism["independent_r2_present"],
                            mechanism["unstable_target_r1_present"],
                        )] += 1

                        next_tracks = advance_tracks(
                            parent["tracks"], current_index, successor, successor_index, env
                        )
                        stable_anchor_count = sum(t.stable_support_alive for t in next_tracks)
                        stable_anchor_hist[stable_anchor_count] += 1
                        step = {
                            "depth": depth,
                            "actor_index": actor_index,
                            "actor_additions": serial_additions(actor.additions),
                        }
                        new_path = parent["path"] + (step,)

                        for tr in next_tracks:
                            if tr.current_snapshot_id is None:
                                continue
                            current_cert = successor_index["certificate_by_id"][tr.current_snapshot_id]
                            root_cert = root_index["certificate_by_id"][tr.root_snapshot_id]
                            comps = env.api.components6(successor)
                            ld = env.api.descendant(frozenset(root_cert.carrier[0]), comps)
                            rd = env.api.descendant(frozenset(root_cert.carrier[1]), comps)
                            if ld == rd:
                                failures.append(["transitive_descendant_direct_merge_mismatch", depth, path_id(new_path)])
                            else:
                                direct_key = tuple(sorted((tuple(sorted(ld)), tuple(sorted(rd)))))
                                composed_key = tuple(sorted((tuple(sorted(current_cert.carrier[0])), tuple(sorted(current_cert.carrier[1])))))
                                if direct_key != composed_key:
                                    failures.append(["transitive_descendant_carrier_mismatch", depth, path_id(new_path)])

                        if stable_anchor_count == 0:
                            extinction_hits.append({
                                "path_id": path_id(new_path),
                                "depth": depth,
                                "path": list(new_path),
                                "mechanism": mechanism,
                                "after_target_supporters": sorted(successor_index["target_supporters"]),
                            })
                            continue
                        if mechanism["stable_old_target_support_count"] == 0:
                            local_converse_hits.append({
                                "path_id": path_id(new_path),
                                "depth": depth,
                                "path": list(new_path),
                                "mechanism": mechanism,
                            })
                        if mechanism["independent_r2_present"] and len(representative_r2) < 20:
                            representative_r2.append({
                                "path_id": path_id(new_path),
                                "depth": depth,
                                "path": list(new_path),
                                "mechanism": mechanism,
                            })

                        next_active.append({
                            "state": successor,
                            "tracks": next_tracks,
                            "path": new_path,
                        })

                depth_rows.append({
                    "lineage_depth": depth,
                    "active_parent_paths": len(active),
                    "target_disjoint_n2_transitions": transitions,
                    "target_overlap_n2_actors_excluded": overlap_excluded,
                    "continuous_b_survivors": b_survivors,
                    "literal_loss_transitions": transitions - b_survivors,
                    "continuing_stable_anchor_paths": len(next_active),
                    "unique_successor_states": len(unique_children),
                    "unique_continuous_b_survivor_states": len(unique_survivor_states),
                    "independent_r2_survivor_transitions": independent_r2_count,
                    "unstable_target_r1_survivor_transitions": unstable_r1_count,
                    "no_immediate_stable_support_survivors": no_immediate_stable_count,
                    "anchor_extinction_survivors": stable_anchor_hist.get(0, 0),
                    "stable_anchor_support_count_histogram": {str(k): v for k, v in sorted(stable_anchor_hist.items())},
                })
                if extinction_hits:
                    failures.append(["unexpected_anchor_extinction_hit", len(extinction_hits)])
                    break
                if not next_active:
                    break
                active = next_active
            else:
                failures.append(["closure_depth_cap_reached", 31])

            total_transitions = sum(r["target_disjoint_n2_transitions"] for r in depth_rows)
            total_survivors = sum(r["continuous_b_survivors"] for r in depth_rows)
            result = {
                "checkpoint": "generalized_closure",
                "source_state_index": source_state_index,
                "target": [list(p) for p in target],
                "root_meta": root_meta,
                "root_target_supporter_count": root_support_count,
                "search_strategy": "exhaustive",
                "depth_rows": depth_rows,
                "totals": {
                    "target_disjoint_n2_transitions": total_transitions,
                    "continuous_b_survivor_transitions": total_survivors,
                    "anchor_extinction_hit_count": len(extinction_hits),
                    "local_converse_hit_count": len(local_converse_hits),
                    "independent_r2_survivor_transition_count": sum(r["independent_r2_survivor_transitions"] for r in depth_rows),
                    "unstable_target_r1_survivor_transition_count": sum(r["unstable_target_r1_survivor_transitions"] for r in depth_rows),
                    "max_lineage_depth_reached": depth_rows[-1]["lineage_depth"] if depth_rows else 0,
                    "closure_exhausted": bool(depth_rows and depth_rows[-1]["continuing_stable_anchor_paths"] == 0),
                },
                "survivor_mechanism_histogram": {
                    f"stable={int(k[0])},independent_r2={int(k[1])},unstable_r1={int(k[2])}": v
                    for k, v in sorted(all_survivor_mechanisms.items())
                },
                "representative_independent_r2": representative_r2,
                "extinction_hits": extinction_hits,
                "local_converse_hits": local_converse_hits,
                "failure_count": len(failures),
                "failures": failures,
            }
            return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-index", type=int, required=True)
    parser.add_argument("--target", type=str, default="[[-1,1,-1],[-1,2,-1]]",
                         help="JSON list of 3-tuples, e.g. '[[-1,1,-1],[-1,2,-1]]'")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    target = tuple(sorted(tuple(p) for p in json.loads(args.target)))
    result = run(args.source_index, target)
    Path(args.out).write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "source_state_index": result["source_state_index"],
        "failure_count": result["failure_count"],
        "totals": result["totals"],
        "depth_rows": [
            {k: v for k, v in r.items() if k != "stable_anchor_support_count_histogram"}
            for r in result["depth_rows"]
        ],
    }, indent=2))
    raise SystemExit(0 if result["failure_count"] == 0 else 1)


if __name__ == "__main__":
    main()
