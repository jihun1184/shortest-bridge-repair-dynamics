from __future__ import annotations

import hashlib
import sys
import tempfile
import zipfile
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parent
PREDECESSOR_NAME = "S2_COMP_02C4_RESCUE_EXISTENCE_BOUNDARY_20260830.zip"
PREDECESSOR_SHA256 = "b119ca582a6b07158399ffd77ee52b4683453da9621f019b49ce379e0253fbdd"
PREDECESSOR_ROOT_NAME = "S2_COMP_02C4_RESCUE_EXISTENCE_BOUNDARY_20260830"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


@dataclass(frozen=True)
class Env:
    temp_root: Path
    predecessor_root: Path
    frozen: object
    domains: object
    mechanism: object


@contextmanager
def frozen_env():
    pred_zip = PACKAGE_ROOT / "source" / PREDECESSOR_NAME
    if sha256(pred_zip) != PREDECESSOR_SHA256:
        raise AssertionError("02C4 predecessor hash mismatch")
    with tempfile.TemporaryDirectory(prefix="s2comp02c5_") as td:
        tmp = Path(td)
        with zipfile.ZipFile(pred_zip) as zf:
            zf.extractall(tmp / "pred")
        root = tmp / "pred" / PREDECESSOR_ROOT_NAME
        if not root.is_dir():
            raise RuntimeError("02C4 predecessor extraction failed")
        sys.dont_write_bytecode = True
        sys.path.insert(0, str(root))
        try:
            import s2comp02c4_env as frozen
            import s2comp02c4_domains as domains
            import s2comp02c4_mechanism_search as mechanism
            yield Env(tmp, root, frozen, domains, mechanism)
        finally:
            try:
                sys.path.remove(str(root))
            except ValueError:
                pass
