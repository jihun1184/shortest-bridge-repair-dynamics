# 다음 세션 시작 메시지 — S2-COMP-02C9

첨부된 02C9 ZIP을 먼저 직접 fresh-unzip하여 검증한 뒤 S2-COMP 연구를
이어가 주세요. 이전 대화의 기억보다 ZIP 내부 raw code, results, manifest,
audit artifacts를 source of truth로 우선하세요.

## Canonical checkpoint

유일한 canonical source of truth는 첨부된
`S2_COMP_02C9_SOURCE24_SOURCE21_RANK26_30_EXHAUSTION_20260830.zip`입니다.
외부 ZIP SHA-256은 전달 메시지의 값을 사용하고, fresh-unzip 후
`SHA256SUMS.txt` 전 항목을 직접 검증하세요.

즉시 predecessor는 ZIP 내부의 02C8 sanitized repair이며 SHA-256은
`a5507c0583a2a082ffaeb381d8ed4ef3e0843861be2882de4cbae496b4567a1b`입니다.
그 내부 02C7 lineage는
`115ae4e199b1ca4e7437423f234d9718cbf751ef2644f1a203305fd2da864817`,
direct 02C4 dependency는
`b119ca582a6b07158399ffd77ee52b4683453da9621f019b49ce379e0253fbdd`입니다.
이 lineage를 재구성하거나 predecessor를 교체하지 마세요.

## Scientific status

상태는 `BOUNDED_EXHAUSTIVE_CLOSED`이며 새 universal theorem은 없습니다.

- ranks 26–30 census: 5 targets / 1,829 actor-target cases
- source 24: ranks 26,27,28,30; 355 N2 actors per target
- source 21: rank 29; 409 N2 actors
- full-outcome classes: 5
- survivor-actor-set classes: 2
- exhaustive closures: 18,400 transitions / 284 continuous survivors
- anchor extinction, local converse/no-stable support, independent R2,
  unstable-target R1: 모두 0
- 다섯 closure 모두 depth 3에서 자연 소진

source-24의 네 ranks는 survivor actor set과 active paths `[1,19,33]`가
같지만 transition totals가 `2920,2914,2861,2776`으로 다릅니다. 따라서
signature나 path-count profile을 deeper equivalence/pruning에 사용하지
마세요. physical-state dedup도 금지합니다.

## Packaging scope

02C9 top-level payload는 `.pyc`/`__pycache__`와 authoring path가 없습니다.
다만 immutable predecessor를 재귀적으로 검사하면 embedded 02C7 안에
historical `.pyc` 5개가 남아 있습니다. 이는 `PACKAGING_SCOPE.md`에
공개되어 있으며, canonical lineage hash 보존을 위해 수정하지 않습니다.

## Claim boundary

universal stable-anchor persistence, zero-stable-support independent R2
impossibility, unstable-target R1 impossibility, signature-based deeper closure
equivalence는 모두 OPEN입니다. target-overlap과 non-N2는 별도 evidence
bucket으로 유지하세요.

새 연구를 시작하기 전에 census, all-closure rerun, exact confirmation,
registry, audit, smoke를 가능한 범위에서 fresh 실행하고 stored output과
byte identity를 확인하세요. 실제 fresh 실행 사실과 stored artifact만
확인한 사실을 구분해 보고하세요.
