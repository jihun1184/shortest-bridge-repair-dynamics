from __future__ import annotations

import argparse
import json
from pathlib import Path

from s2comp02c9_inputs import PACKAGE_ROOT, load_frozen_selection, load_prior_registry


RANKS = [26, 27, 28, 29, 30]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", default=str(PACKAGE_ROOT))
    parser.add_argument("--out", default=str(PACKAGE_ROOT / "cell_status_registry.json"))
    args = parser.parse_args()
    root = Path(args.package_root)
    prior = load_prior_registry()
    registry = json.loads(json.dumps(prior))
    census = json.loads((root / "s2comp02c9_signature_census.json").read_text())
    selection = load_frozen_selection()
    rows = {row["structural_rank"]: row for row in census["rows"]}
    if census["target_count"] != 5 or census["selected_ranks"] != RANKS:
        raise AssertionError("unexpected 02C9 census selection")
    if census["outcome_signature_class_count"] != 5:
        raise AssertionError("expected five singleton full-outcome signature classes")

    closures = {}
    for rank in RANKS:
        closure = json.loads(
            (root / "results" / f"s2comp02c9_rank{rank}_closure.json").read_text()
        )
        expected = selection["structural_priority_top"][rank - 1]
        if (
            closure["source_state_index"] != expected["source_state_index"]
            or closure["target"] != expected["target_literal"]
        ):
            raise AssertionError((rank, "domain mismatch"))
        if closure["failure_count"] or not closure["totals"]["closure_exhausted"]:
            raise AssertionError((rank, "closure not cleanly exhausted"))
        closures[rank] = closure
        totals = closure["totals"]
        registry.setdefault("lineage_searches", []).append(
            {
                "checkpoint": "S2-COMP-02C9",
                "group": f"source{closure['source_state_index']}_structural_rank{rank}",
                "selection_class": "singleton_source_stratified_full_outcome_signature_class",
                "selection_evidence": {
                    "frozen_structural_rank_range": [26, 30],
                    "outcome_signature_classes": 5,
                    "survivor_actor_set_classes": 2,
                    "outcome_signature_sha256": rows[rank]["outcome_signature_sha256"],
                    "survivor_actor_set_sha256": rows[rank]["survivor_actor_set_sha256"],
                },
                "search_strategy": "exhaustive",
                "domain": {
                    "source_state_index": closure["source_state_index"],
                    "branch_index": 1,
                    "target_additions": closure["target"],
                    "structural_rank": rank,
                },
                "status": "BOUNDED_EXHAUSTIVE_CLOSED",
                "closure_exhausted": totals["closure_exhausted"],
                "transition_count": totals["target_disjoint_n2_transitions"],
                "continuous_survivor_transition_count": totals[
                    "continuous_b_survivor_transitions"
                ],
                "anchor_extinction_hit_count": totals["anchor_extinction_hit_count"],
                "local_converse_hit_count": totals["local_converse_hit_count"],
                "independent_r2_count": totals[
                    "independent_r2_survivor_transition_count"
                ],
                "unstable_target_r1_count": totals[
                    "unstable_target_r1_survivor_transition_count"
                ],
                "max_lineage_depth": totals["max_lineage_depth_reached"],
            }
        )

    domain_text = (
        "all five frozen structural ranks 26-30: source 24 ranks 26/27/28/30 "
        "and source 21 rank 29; target-disjoint N2 actor-history lineages"
    )
    survivor_total = sum(
        closure["totals"]["continuous_b_survivor_transitions"]
        for closure in closures.values()
    )
    registry.setdefault("lineage_open_patterns", []).extend(
        [
            {
                "checkpoint": "S2-COMP-02C9",
                "pattern": "continuous b survival AND zero stable depth-0 anchor supports",
                "status": "NOT_YET_OBSERVED",
                "boundary": "not an impossibility claim; bounded to the exhausted domains listed",
                "bounded_count": 0,
                "search_strategy": "exhaustive",
                "evidence_through_02C9": {
                    "selected_lineage_domains": 5,
                    "continuous_survivor_transitions": survivor_total,
                    "zero_stable_support_hits": 0,
                },
                "domain": domain_text,
            },
            {
                "checkpoint": "S2-COMP-02C9",
                "pattern": "unstable-target R1",
                "status": "NOT_YET_OBSERVED",
                "boundary": "not an impossibility claim; bounded to the exhausted domains listed",
                "bounded_count": 0,
                "search_strategy": "exhaustive",
                "evidence_through_02C9": {
                    "selected_lineage_domains": 5,
                    "exact_hits": 0,
                },
                "domain": domain_text,
            },
        ]
    )
    Path(args.out).write_text(json.dumps(registry, indent=2, sort_keys=True) + "\n")
    print(
        json.dumps(
            {
                "cells": len(registry["cells"]),
                "lineage_searches": len(registry["lineage_searches"]),
                "lineage_open_patterns": len(registry["lineage_open_patterns"]),
            },
            indent=2,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
