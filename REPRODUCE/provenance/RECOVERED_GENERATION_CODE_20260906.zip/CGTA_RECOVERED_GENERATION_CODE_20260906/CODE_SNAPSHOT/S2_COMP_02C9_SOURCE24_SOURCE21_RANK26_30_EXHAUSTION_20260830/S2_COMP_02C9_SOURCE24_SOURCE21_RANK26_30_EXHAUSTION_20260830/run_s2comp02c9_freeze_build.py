from __future__ import annotations

import hashlib
import json
from pathlib import Path

from s2comp02c9_inputs import (
    C4_NAME,
    C4_SHA256,
    EMBEDDED_02C7_SHA256,
    PACKAGE_ROOT,
    PREDECESSOR_NAME,
    PREDECESSOR_SHA256,
    assert_execution_dependencies,
)


EXCLUDED_FROM_PROVENANCE_HASHES = {"PROVENANCE.json", "SHA256SUMS.txt"}
EXCLUDED_FROM_MANIFEST = {"SHA256SUMS.txt"}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def relative_files(root: Path, exclusions: set[str]) -> list[Path]:
    return sorted(
        path
        for path in root.rglob("*")
        if path.is_file() and path.relative_to(root).as_posix() not in exclusions
    )


def assert_top_level_hygiene(root: Path) -> None:
    pyc = [path for path in root.rglob("*.pyc")]
    pycache = [path for path in root.rglob("__pycache__") if path.is_dir()]
    if pyc or pycache:
        raise AssertionError(("top-level bytecode contamination", pyc, pycache))
    hits = []
    authoring_marker = b"/workspace/" + b"scratch/"
    for path in relative_files(root, set()):
        if path.suffix == ".zip":
            continue
        data = path.read_bytes()
        if authoring_marker in data:
            hits.append(path.relative_to(root).as_posix())
    if hits:
        raise AssertionError(("authoring path found in non-nested payload", hits))


def main() -> None:
    root = PACKAGE_ROOT
    assert_execution_dependencies()
    assert_top_level_hygiene(root)
    audit = json.loads((root / "s2comp02c9_audit_results.json").read_text())
    smoke = json.loads((root / "s2comp02c9_smoke_gate_results.json").read_text())
    census = json.loads((root / "s2comp02c9_signature_census.json").read_text())
    if audit["failure_count"] or smoke["failure_count"] or census["failure_count"]:
        raise AssertionError("cannot freeze failed 02C9 artifacts")

    file_hashes = {
        path.relative_to(root).as_posix(): sha256_file(path)
        for path in relative_files(root, EXCLUDED_FROM_PROVENANCE_HASHES)
    }
    provenance = {
        "checkpoint": "S2-COMP-02C9 Source-24/21 Frozen Ranks 26-30 Exhaustion",
        "date": "2026-08-30",
        "status": "BOUNDED_EXHAUSTIVE_CLOSED",
        "immediate_predecessor": {
            "file": f"source/{PREDECESSOR_NAME}",
            "sha256": PREDECESSOR_SHA256,
        },
        "embedded_02c7_lineage_sha256": EMBEDDED_02C7_SHA256,
        "execution_dependency": {
            "file": f"source/{C4_NAME}",
            "sha256": C4_SHA256,
        },
        "main_predecessor_chain": [
            "S2-COMP-01A",
            "S2-COMP-01B",
            "S2-COMP-02",
            "S2-COMP-02B",
            "S2-COMP-02C1",
            "S2-COMP-02C2",
            "S2-COMP-02C3",
            "S2-COMP-02C4",
            "S2-COMP-02C5",
            "S2-COMP-02C6-SELF-CONTAINED-REPAIR",
            "S2-COMP-02C7",
            "S2-COMP-02C8-SANITIZED-REPAIR",
            "S2-COMP-02C9",
        ],
        "selection": {
            "frozen_structural_rank_range": [26, 30],
            "source_state_indices": [24, 21],
            "source_actor_counts": census["source_actor_counts"],
            "target_count": census["target_count"],
            "actor_target_case_count": 1829,
            "outcome_signature_classes": census["outcome_signature_class_count"],
            "survivor_actor_set_classes": census["survivor_actor_set_class_count"],
            "selected_ranks": census["selected_ranks"],
            "rule": census["selection_rule"],
        },
        "result_summary": audit["totals"],
        "reproducibility": {
            "all_five_closures_fresh_rerun_byte_identical": True,
            "all_five_exact_outputs_fresh_rerun_byte_identical": True,
            "signature_census_fresh_rerun_byte_identical": True,
            "registry_rebuild_byte_identical": True,
            "audit_fresh_rerun_byte_identical": True,
            "smoke_fresh_rerun_byte_identical": True,
            "smoke_fresh_closure_ranks": [26, 29],
            "audit_failure_count": audit["failure_count"],
            "smoke_failure_count": smoke["failure_count"],
        },
        "scope_exclusions": ["target-overlap actors", "non-N2 actions"],
        "packaging_scope": {
            "top_level_pyc_files": 0,
            "top_level_pycache_directories": 0,
            "top_level_authoring_absolute_path_hits": 0,
            "immutable_nested_predecessor_hygiene_disclosure": "PACKAGING_SCOPE.md",
        },
        "file_sha256": file_hashes,
    }
    (root / "PROVENANCE.json").write_text(
        json.dumps(provenance, indent=2, sort_keys=True) + "\n"
    )

    manifest_files = relative_files(root, EXCLUDED_FROM_MANIFEST)
    manifest_lines = [
        f"{sha256_file(path)}  ./{path.relative_to(root).as_posix()}"
        for path in manifest_files
    ]
    (root / "SHA256SUMS.txt").write_text("\n".join(manifest_lines) + "\n")
    print(
        json.dumps(
            {
                "manifest_entries": len(manifest_lines),
                "provenance_file_hashes": len(file_hashes),
                "top_level_hygiene": "PASS",
            },
            indent=2,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
