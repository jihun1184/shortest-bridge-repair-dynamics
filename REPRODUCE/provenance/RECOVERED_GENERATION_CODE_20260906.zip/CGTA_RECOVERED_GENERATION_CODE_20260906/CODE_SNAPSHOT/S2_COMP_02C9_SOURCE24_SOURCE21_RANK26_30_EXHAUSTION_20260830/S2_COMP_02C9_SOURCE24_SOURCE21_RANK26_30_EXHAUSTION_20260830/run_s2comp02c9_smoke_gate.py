from __future__ import annotations

import argparse
import json
from pathlib import Path

import run_generalized_closure as closure_engine
from s2comp02c5_env import frozen_env
from s2comp02c9_inputs import PACKAGE_ROOT, assert_execution_dependencies, load_frozen_selection


FRESH_RANKS = [26, 29]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", default=str(PACKAGE_ROOT))
    parser.add_argument(
        "--out", default=str(PACKAGE_ROOT / "s2comp02c9_smoke_gate_results.json")
    )
    args = parser.parse_args()
    root = Path(args.package_root)
    failures = []
    assert_execution_dependencies()
    selection = load_frozen_selection()
    fresh_summaries = {}

    with frozen_env() as outer:
        with outer.frozen.frozen_env() as env:
            for rank in FRESH_RANKS:
                row = selection["structural_priority_top"][rank - 1]
                source = row["source_state_index"]
                target = tuple(sorted(tuple(p) for p in row["target_literal"]))
                fresh = closure_engine.run_with_env(outer, env, source, target)
                stored = json.loads(
                    (root / "results" / f"s2comp02c9_rank{rank}_closure.json").read_text()
                )
                if fresh != stored:
                    failures.append(["fresh_closure_not_semantically_identical", rank])
                fresh_summaries[f"rank{rank}"] = {
                    "source_state_index": source,
                    "transitions": fresh["totals"]["target_disjoint_n2_transitions"],
                    "survivors": fresh["totals"]["continuous_b_survivor_transitions"],
                    "active_parent_paths": [
                        depth["active_parent_paths"] for depth in fresh["depth_rows"]
                    ],
                    "unique_survivor_states": [
                        depth["unique_continuous_b_survivor_states"]
                        for depth in fresh["depth_rows"]
                    ],
                    "failure_count": fresh["failure_count"],
                }

    census = json.loads((root / "s2comp02c9_signature_census.json").read_text())
    rows = {row["structural_rank"]: row for row in census["rows"]}
    source24_ranks = [26, 27, 28, 30]
    same_survivor_set = len(
        {rows[rank]["survivor_actor_set_sha256"] for rank in source24_ranks}
    ) == 1
    closures = {
        rank: json.loads(
            (root / "results" / f"s2comp02c9_rank{rank}_closure.json").read_text()
        )
        for rank in source24_ranks
    }
    active_profiles = {
        tuple(depth["active_parent_paths"] for depth in closure["depth_rows"])
        for closure in closures.values()
    }
    transition_counts = [
        closures[rank]["totals"]["target_disjoint_n2_transitions"]
        for rank in source24_ranks
    ]
    control_caught = (
        same_survivor_set
        and active_profiles == {(1, 19, 33)}
        and transition_counts == [2920, 2914, 2861, 2776]
    )
    if not control_caught:
        failures.append(["equal_survivor_set_deeper_equivalence_negative_control_failed"])

    path_state_controls = {}
    for rank in FRESH_RANKS:
        closure = json.loads(
            (root / "results" / f"s2comp02c9_rank{rank}_closure.json").read_text()
        )
        row = closure["depth_rows"][1]
        paths = row["continuing_stable_anchor_paths"]
        states = row["unique_continuous_b_survivor_states"]
        path_state_controls[f"rank{rank}"] = {
            "depth": 2,
            "continuing_lineage_paths": paths,
            "unique_survivor_states": states,
        }
        if paths <= states:
            failures.append(["lineage_path_multiplicity_control_failed", rank])

    result = {
        "checkpoint": "S2-COMP-02C9",
        "kind": "smoke_and_regression_gate",
        "fresh_closures": fresh_summaries,
        "equal_survivor_set_not_deeper_equivalence_control": {
            "source_state_index": 24,
            "ranks": source24_ranks,
            "same_survivor_actor_set": same_survivor_set,
            "same_active_parent_paths": active_profiles == {(1, 19, 33)},
            "transition_counts": transition_counts,
            "control_caught": control_caught,
        },
        "path_vs_state_controls": path_state_controls,
        "scope_exclusions_enforced": ["target-overlap actors", "non-N2 actions"],
        "failure_count": len(failures),
        "failures": failures,
    }
    Path(args.out).write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))
    raise SystemExit(0 if not failures else 1)


if __name__ == "__main__":
    main()
