# S2-COMP-02C9 — Claim Boundary

## PROVED

No new theorem is proved. The exact N2 quotient fiber formula, R3 exclusion,
and necessary R1-or-independent-R2 dichotomy are inherited unchanged.

## BOUNDED_EXHAUSTIVE_EVIDENCE

- Depth-1 continuation signatures were exhaustively computed for frozen
  structural ranks 26–30 over 1,829 source-stratified actor-target cases.
- All five target-specific, target-disjoint N2 actor-history lineage domains
  were exhausted naturally through depth 3.
- Their sums are 18,400 transitions and 284 continuous survivor transitions.
- Anchor extinction, no-stable-support/local-converse, independent R2, and
  unstable-target R1 each have bounded count zero in all five closures.

Equal survivor signatures and equal active-path count profiles are explicitly
**not** treated as proof of deeper equivalence.

## OBSERVED_EXISTENCE

No new rescue fixture is observed. Predecessor independent-R2 fixtures remain
valid but are not new 02C9 observations.

## OPEN

- universal stable-anchor persistence;
- existence or impossibility of independent R2 with zero stable old target
  support;
- existence or impossibility of unstable-target R1;
- general deeper-closure equivalence based on any depth-1 signature;
- unselected source-26 deeper closures and structural targets beyond rank 30;
- target-overlap actors;
- non-N2 action extensions;
- loss-to-reappearance lineages.

The zero counts above are bounded evidence only, not impossibility claims.
