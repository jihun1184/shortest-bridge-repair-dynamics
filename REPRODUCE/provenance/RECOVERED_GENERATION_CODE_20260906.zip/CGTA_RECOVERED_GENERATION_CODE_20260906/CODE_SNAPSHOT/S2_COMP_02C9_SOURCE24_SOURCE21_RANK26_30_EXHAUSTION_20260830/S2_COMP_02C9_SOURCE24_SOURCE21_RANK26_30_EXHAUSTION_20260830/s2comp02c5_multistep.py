from __future__ import annotations

from dataclasses import dataclass


def _carrier_key(certificate):
    left, right = certificate.carrier
    return tuple(sorted((tuple(sorted(tuple(p) for p in left)), tuple(sorted(tuple(p) for p in right)))))


@dataclass(frozen=True)
class AnchorTrack:
    root_snapshot_id: str
    current_snapshot_id: str | None
    cumulative_d6_stable: bool
    continuous_certificate_support: bool

    @property
    def stable_support_alive(self) -> bool:
        return (
            self.current_snapshot_id is not None
            and self.cumulative_d6_stable
            and self.continuous_certificate_support
        )


def n2_target_index(state, target, env, cache=None):
    """Exact N2 certificate/support index for one state.

    The target is a canonical sorted tuple of voxel additions.  This calls the
    frozen bridge generator directly, so support is certificate-level rather
    than deduplicated CanonicalAction-level support.
    """
    key = tuple(sorted(state))
    if cache is not None and key in cache:
        return cache[key]
    certs = env.pred["extract_certificates"](state, env.api)
    n2 = [c for c in certs if c.predicate == "N2_facet_connectivity"]
    bridge_sets = {}
    supporters = set()
    for cert in n2:
        actions, _ = env.bridge.certificate_bridge_actions(
            state, (frozenset(cert.carrier[0]), frozenset(cert.carrier[1]))
        )
        literals = {
            tuple(sorted(tuple(p) for p in action["additions"])) for action in actions
        }
        bridge_sets[cert.snapshot_id] = literals
        if target in literals:
            supporters.add(cert.snapshot_id)
    out = {
        "certificates": n2,
        "certificate_by_id": {c.snapshot_id: c for c in n2},
        "certificate_by_carrier": {_carrier_key(c): c for c in n2},
        "bridge_sets": bridge_sets,
        "target_supporters": supporters,
    }
    if cache is not None:
        cache[key] = out
    return out


def descendant_certificate(old_cert, successor, successor_index, env):
    comps = env.api.components6(successor)
    left, right = old_cert.carrier
    ld = env.api.descendant(frozenset(left), comps)
    rd = env.api.descendant(frozenset(right), comps)
    if ld == rd:
        return None, False
    key = tuple(sorted((tuple(sorted(ld)), tuple(sorted(rd)))))
    after_cert = successor_index["certificate_by_carrier"][key]
    stable = env.pred["d6"](ld, rd) == env.pred["d6"](left, right)
    return after_cert, stable


def initialize_tracks(root_index):
    tracks = []
    for sid in sorted(root_index["target_supporters"]):
        tracks.append(AnchorTrack(sid, sid, True, True))
    return tuple(tracks)


def advance_tracks(tracks, current_index, successor, successor_index, env):
    out = []
    for track in tracks:
        if track.current_snapshot_id is None:
            out.append(track)
            continue
        old_cert = current_index["certificate_by_id"][track.current_snapshot_id]
        after_cert, step_stable = descendant_certificate(old_cert, successor, successor_index, env)
        after_id = None if after_cert is None else after_cert.snapshot_id
        supports = after_id in successor_index["target_supporters"] if after_id else False
        out.append(
            AnchorTrack(
                root_snapshot_id=track.root_snapshot_id,
                current_snapshot_id=after_id,
                cumulative_d6_stable=track.cumulative_d6_stable and step_stable,
                continuous_certificate_support=track.continuous_certificate_support and supports,
            )
        )
    return tuple(out)


def local_mechanism(current, successor, current_index, successor_index, env):
    """Exact one-step target mechanism classification used for audit counts."""
    old_support = current_index["target_supporters"]
    after_support = successor_index["target_supporters"]
    ancestors = {sid: set() for sid in successor_index["certificate_by_id"]}
    stable = {}
    descendants = {}
    comps = env.api.components6(successor)
    for cert in current_index["certificates"]:
        left, right = cert.carrier
        ld = env.api.descendant(frozenset(left), comps)
        rd = env.api.descendant(frozenset(right), comps)
        if ld == rd:
            descendants[cert.snapshot_id] = None
            stable[cert.snapshot_id] = False
            continue
        key = tuple(sorted((tuple(sorted(ld)), tuple(sorted(rd)))))
        dc = successor_index["certificate_by_carrier"][key]
        descendants[cert.snapshot_id] = dc.snapshot_id
        stable[cert.snapshot_id] = env.pred["d6"](ld, rd) == env.pred["d6"](left, right)
        ancestors[dc.snapshot_id].add(cert.snapshot_id)

    stable_old = [
        sid for sid in old_support
        if stable.get(sid, False) and descendants.get(sid) in after_support
    ]
    unstable_r1 = [
        sid for sid in old_support
        if not stable.get(sid, False) and descendants.get(sid) in after_support
    ]
    independent_r2 = [
        sid for sid in after_support if ancestors.get(sid, set()).isdisjoint(old_support)
    ]
    return {
        "stable_old_target_support_count": len(stable_old),
        "unstable_target_r1_present": bool(unstable_r1),
        "independent_r2_present": bool(independent_r2),
        "after_target_support_count": len(after_support),
    }
