from __future__ import annotations

import argparse
import json
from pathlib import Path

from s2comp02c5_env import frozen_env


def key(points):
    return tuple(tuple(p) for p in points)


def confirm_candidate(env, state, actor_additions, target_additions, label):
    """Verbatim reuse of run_s2comp02c4_exact_confirmation.confirm_candidate,
    generalized to take actor/target additions directly instead of a fast-search
    candidate dict."""
    canonical_actions = env.pred["canonical_actions"]
    extract_certificates = env.pred["extract_certificates"]
    directed_stability = env.pred["directed_stability"]
    trace_provenance = env.pred["trace_provenance"]
    quotient_fn = env.pred["assert_frozen_n2_bridge_quotient"]
    classify = env.pred["classify_target_descendants"]
    targeted_index = env.pred["_targeted_n2_successor_index"]
    fake_action = env.pred["_targeted_fake_action"]

    before = extract_certificates(state, env.api)
    before_dict = {c.snapshot_id: c for c in before}
    actions = {a.additions: a for a in canonical_actions(state, env.api, before)}
    actor = actions[key(actor_additions)]
    target = actions[key(target_additions)]
    after_components, after_certificates, index = targeted_index(
        state, actor, env.api, env.bridge
    )
    after_ids = index.get(target.additions, ())
    if not after_ids:
        raise AssertionError(("candidate target did not survive exact targeted lookup", label))
    after_actions = {target.additions: fake_action(target, after_ids)}
    after_dict = {c.snapshot_id: c for c in after_certificates}
    stability = directed_stability(
        state, actor, target, env.api,
        successor_actions=after_actions,
        source_certificates=before_dict,
        after_components=after_components,
        after_certificates=after_dict,
    )
    quotient = quotient_fn(state, actor, env.api)
    profile = classify(
        target=target, directed_stability=stability, after_actions=after_actions,
        after_certificates=after_certificates, quotient=quotient, api=env.api,
        state=state, actor=actor,
    )
    trace = trace_provenance(
        state, actor, target, env.api, env.bridge,
        state_label=label, before_certificates=before,
    )
    return {
        "label": label,
        "actor_additions": [list(p) for p in actor.additions],
        "target_additions": [list(p) for p in target.additions],
        "survives": stability.target_literal_survives,
        "profile": profile.record(),
        "rescue_classes": list(trace.rescue_classes),
        "primary_rescue_class": trace.primary_rescue_class,
    }


def replay_state(env, domains, source_index, path_steps):
    """Reconstruct the state immediately BEFORE the final step in path_steps,
    by replaying every step except the last from the source's alternate root."""
    state, meta = domains.d7b_alternate_first_successor(env, source_index)
    for step in path_steps[:-1]:
        state = frozenset(state | {tuple(p) for p in step["actor_additions"]})
    return state, meta


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--closure-json", required=True, help="path to a run_generalized_closure.py output")
    parser.add_argument("--source-index", type=int, required=True)
    parser.add_argument("--label-prefix", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    closure = json.loads(Path(args.closure_json).read_text())
    target_additions = closure["target"]
    candidates = closure["representative_independent_r2"]

    verified = []
    failures = []
    with frozen_env() as outer:
        with outer.frozen.frozen_env() as env:
            for ordinal, cand in enumerate(candidates):
                path_steps = cand["path"]
                state, meta = replay_state(env, outer.domains, args.source_index, path_steps)
                last_actor_additions = path_steps[-1]["actor_additions"]
                label = f"{args.label_prefix}_depth{cand['depth']:02d}_candidate_{ordinal:03d}"
                try:
                    rec = confirm_candidate(env, state, last_actor_additions, target_additions, label)
                except AssertionError as exc:
                    failures.append({"kind": "confirm_error", "label": label, "error": str(exc)})
                    continue
                rec["depth"] = cand["depth"]
                rec["path_id"] = cand["path_id"]
                rec["fast_mechanism"] = cand["mechanism"]
                verified.append(rec)

    for rec in verified:
        profile = rec["profile"]
        if not rec["survives"]:
            failures.append({"kind": "candidate_did_not_survive", "label": rec["label"]})
        if not profile["independent_r2_branch_present"]:
            failures.append({"kind": "candidate_not_independent_r2", "label": rec["label"]})

    result = {
        "checkpoint": "generalized_exact_confirmation",
        "source_state_index": args.source_index,
        "label_prefix": args.label_prefix,
        "verified_count": len(verified),
        "independent_r2_verified_count": sum(bool(r["profile"]["independent_r2_branch_present"]) for r in verified),
        "none_stable_verified_count": sum(r["profile"]["d6_stability_type"] == "NONE_STABLE" for r in verified),
        "unstable_target_r1_verified_count": sum(bool(r["profile"]["unstable_target_r1_branch_present"]) for r in verified),
        "stable_old_target_support_zero_count": sum(r["profile"]["stable_old_target_support_count"] == 0 for r in verified),
        "verified": verified,
        "failure_count": len(failures),
        "failures": failures,
    }
    Path(args.out).write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: result[k] for k in [
        "verified_count", "independent_r2_verified_count", "none_stable_verified_count",
        "unstable_target_r1_verified_count", "stable_old_target_support_zero_count", "failure_count"
    ]}, indent=2))
    raise SystemExit(0 if result["failure_count"] == 0 else 1)


if __name__ == "__main__":
    main()
