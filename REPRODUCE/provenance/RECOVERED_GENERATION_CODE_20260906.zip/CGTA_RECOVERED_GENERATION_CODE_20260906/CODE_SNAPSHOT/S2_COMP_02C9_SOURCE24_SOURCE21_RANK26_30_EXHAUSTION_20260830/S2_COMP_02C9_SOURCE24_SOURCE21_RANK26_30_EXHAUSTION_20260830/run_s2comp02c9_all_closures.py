from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import run_generalized_closure as engine
from s2comp02c5_env import frozen_env
from s2comp02c9_inputs import PACKAGE_ROOT, assert_execution_dependencies, load_frozen_selection


RANKS = [26, 27, 28, 29, 30]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", default=str(PACKAGE_ROOT))
    parser.add_argument("--out-dir", required=True)
    args = parser.parse_args()
    root = Path(args.package_root).resolve()
    out_dir = Path(args.out_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    assert_execution_dependencies()
    selection = load_frozen_selection()
    summaries = []
    with frozen_env() as outer:
        with outer.frozen.frozen_env() as env:
            for rank in RANKS:
                row = selection["structural_priority_top"][rank - 1]
                source = row["source_state_index"]
                target = tuple(sorted(tuple(p) for p in row["target_literal"]))
                result = engine.run_with_env(outer, env, source, target)
                path = out_dir / f"s2comp02c9_rank{rank}_closure.json"
                path.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
                summary = {
                    "rank": rank,
                    "source_state_index": source,
                    "failure_count": result["failure_count"],
                    "totals": result["totals"],
                    "active_parent_paths": [
                        depth["active_parent_paths"] for depth in result["depth_rows"]
                    ],
                    "unique_survivor_states": [
                        depth["unique_continuous_b_survivor_states"]
                        for depth in result["depth_rows"]
                    ],
                }
                summaries.append(summary)
                print(json.dumps(summary, sort_keys=True), flush=True)
                if result["failure_count"]:
                    raise SystemExit(1)
    print(json.dumps({"completed_ranks": RANKS, "failure_count": 0}, sort_keys=True))


if __name__ == "__main__":
    main()
