from __future__ import annotations

TARGET = tuple(sorted(((-1, 1, -1), (-1, 2, -1))))
SOURCE_STATE_INDEX = 10
BRANCH_INDEX = 1


def reconstruct_root(env, domains):
    """02C5 lineage depth 0 = D7B source 10 alternate first successor.

    This deliberately starts one level before the 02C4 parent-191 R2-positive
    fixture, so the exhaustive closure contains every state-10 alternate R2
    transition rather than conditioning on a hand-picked parent.
    """
    root, meta = domains.d7b_alternate_first_successor(env, SOURCE_STATE_INDEX)
    if meta["branch_index"] != BRANCH_INDEX:
        raise AssertionError("unexpected alternate branch index")
    return root, meta


def eligible_n2_actors(state, target, env, current_certificates=None):
    """All target-disjoint N2-role canonical actors, lexicographically ordered."""
    actions = env.pred["canonical_actions"](state, env.api, current_certificates)
    actions = [a for a in actions if "N2" in a.roles and set(a.additions).isdisjoint(target)]
    additions = [a.additions for a in actions]
    if additions != sorted(additions):
        raise AssertionError("eligible N2 actor order is not lexicographic by additions")
    return actions
