from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import defaultdict
from pathlib import Path

from s2comp02c9_inputs import PACKAGE_ROOT, assert_execution_dependencies, load_frozen_selection


RANK_START = 26
RANK_END = 30


def digest(value) -> str:
    raw = json.dumps(value, separators=(",", ":"), sort_keys=True).encode()
    return hashlib.sha256(raw).hexdigest()


def carrier_key(certificate):
    left, right = certificate.carrier
    return tuple(sorted((tuple(sorted(left)), tuple(sorted(right)))))


def bridge_literal_sets(state, certificates, bridge):
    out = {}
    for cert in certificates:
        actions, _ = bridge.certificate_bridge_actions(
            state, (frozenset(cert.carrier[0]), frozenset(cert.carrier[1]))
        )
        out[cert.snapshot_id] = {
            tuple(sorted(tuple(p) for p in action["additions"])) for action in actions
        }
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", default=str(PACKAGE_ROOT))
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    root = Path(args.package_root).resolve()
    assert_execution_dependencies()
    sys.path.insert(0, str(root))
    try:
        from s2comp02c5_env import frozen_env
    finally:
        sys.path.remove(str(root))

    selection = load_frozen_selection()
    top_level_selection = json.loads((root / "s2comp02c7_domain_selection.json").read_text())
    if selection != top_level_selection:
        raise AssertionError("top-level frozen selection differs from 02C8 predecessor")
    ranked = selection["structural_priority_top"][RANK_START - 1:RANK_END]
    target_rows = [
        (rank, row["source_state_index"], tuple(tuple(p) for p in row["target_literal"]), row)
        for rank, row in enumerate(ranked, RANK_START)
    ]
    expected_sources = [24, 24, 24, 21, 24]
    if [row[1] for row in target_rows] != expected_sources:
        raise AssertionError("frozen ranks 26-30 source sequence changed")

    records_by_source = {}
    with frozen_env() as outer:
        with outer.frozen.frozen_env() as env:
            for source_index in sorted({row[1] for row in target_rows}):
                state, meta = outer.domains.d7b_alternate_first_successor(env, source_index)
                canonical_actions = env.pred["canonical_actions"]
                extract_certificates = env.pred["extract_certificates"]
                d6 = env.pred["d6"]
                before = extract_certificates(state, env.api)
                old_n2 = [c for c in before if c.predicate == "N2_facet_connectivity"]
                old_sets = bridge_literal_sets(state, old_n2, env.bridge)
                old_support = defaultdict(set)
                for sid, literals in old_sets.items():
                    for literal in literals:
                        old_support[literal].add(sid)
                actors = [
                    actor
                    for actor in canonical_actions(state, env.api, before)
                    if "N2" in actor.roles
                ]
                actor_records = []
                for actor in actors:
                    actor_set = set(actor.additions)
                    successor = state | actor_set
                    after_components = env.api.components6(successor)
                    after = extract_certificates(successor, env.api)
                    after_n2 = [c for c in after if c.predicate == "N2_facet_connectivity"]
                    after_by_carrier = {carrier_key(c): c for c in after_n2}
                    after_sets = bridge_literal_sets(successor, after_n2, env.bridge)
                    descendants = {}
                    stable = {}
                    ancestors = {c.snapshot_id: set() for c in after_n2}
                    for cert in old_n2:
                        left, right = cert.carrier
                        left_descendant = env.api.descendant(frozenset(left), after_components)
                        right_descendant = env.api.descendant(frozenset(right), after_components)
                        if left_descendant == right_descendant:
                            descendants[cert.snapshot_id] = None
                            stable[cert.snapshot_id] = False
                            continue
                        descendant = after_by_carrier[
                            tuple(
                                sorted(
                                    (
                                        tuple(sorted(left_descendant)),
                                        tuple(sorted(right_descendant)),
                                    )
                                )
                            )
                        ]
                        descendants[cert.snapshot_id] = descendant.snapshot_id
                        stable[cert.snapshot_id] = (
                            d6(left_descendant, right_descendant) == d6(left, right)
                        )
                        ancestors[descendant.snapshot_id].add(cert.snapshot_id)
                    after_support = defaultdict(set)
                    for sid, literals in after_sets.items():
                        for literal in literals:
                            after_support[literal].add(sid)
                    actor_records.append(
                        {
                            "actor_additions": tuple(actor.additions),
                            "actor_set": actor_set,
                            "descendants": descendants,
                            "stable": stable,
                            "ancestors": ancestors,
                            "after_support": after_support,
                        }
                    )
                records_by_source[source_index] = (meta, old_support, actor_records)

            rows = []
            failures = []
            for rank, source_index, target, prior_row in target_rows:
                _, old_support, actor_records = records_by_source[source_index]
                supporters = old_support[target]
                outcomes = []
                survivor_actors = []
                for record in actor_records:
                    actor_serial = [list(p) for p in record["actor_additions"]]
                    if not record["actor_set"].isdisjoint(target):
                        outcomes.append([actor_serial, "OVERLAP"])
                        continue
                    after_sids = record["after_support"].get(target, set())
                    if not after_sids:
                        outcomes.append([actor_serial, "LOSS"])
                        continue
                    stable_anchor_count = sum(
                        record["stable"][sid]
                        and record["descendants"][sid] in after_sids
                        for sid in supporters
                    )
                    unstable_r1 = any(
                        not record["stable"][sid]
                        and record["descendants"][sid] in after_sids
                        for sid in supporters
                    )
                    independent_r2 = any(
                        supporters.isdisjoint(record["ancestors"].get(after_sid, set()))
                        for after_sid in after_sids
                    )
                    outcomes.append(
                        [
                            actor_serial,
                            "SURVIVE",
                            stable_anchor_count,
                            int(independent_r2),
                            int(unstable_r1),
                        ]
                    )
                    survivor_actors.append(actor_serial)
                if len(actor_records) not in (355, 409):
                    failures.append(["unexpected_N2_actor_count", source_index, len(actor_records)])
                if len(survivor_actors) != prior_row["continuous_survivor_actors"]:
                    failures.append(["stored_depth1_survivor_mismatch", rank])
                rows.append(
                    {
                        "structural_rank": rank,
                        "source_state_index": source_index,
                        "target_literal": [list(p) for p in target],
                        "n2_actor_count": len(actor_records),
                        "root_supporter_ids": sorted(supporters),
                        "prior_metrics": {
                            key: prior_row[key]
                            for key in (
                                "eligible_target_disjoint_actors",
                                "continuous_survivor_actors",
                                "all_root_supporters_changed_actors",
                                "root_support_change_fraction",
                            )
                        },
                        "outcome_signature_sha256": digest(outcomes),
                        "survivor_actor_set_sha256": digest(survivor_actors),
                        "survivor_actor_count": len(survivor_actors),
                    }
                )

    outcome_classes = defaultdict(list)
    survivor_classes = defaultdict(list)
    for row in rows:
        outcome_classes[(row["source_state_index"], row["outcome_signature_sha256"])].append(
            row["structural_rank"]
        )
        survivor_classes[(row["source_state_index"], row["survivor_actor_set_sha256"])].append(
            row["structural_rank"]
        )
    selected_ranks = sorted(rank for ranks in outcome_classes.values() for rank in ranks)
    result = {
        "checkpoint": "S2-COMP-02C9-SIGNATURE-CENSUS",
        "kind": "source24_source21_frozen_rank26_30_depth1_signature_census",
        "structural_rank_range": [RANK_START, RANK_END],
        "target_count": len(rows),
        "source_actor_counts": {
            str(source): len(data[2]) for source, data in sorted(records_by_source.items())
        },
        "outcome_signature_class_count": len(outcome_classes),
        "survivor_actor_set_class_count": len(survivor_classes),
        "outcome_signature_classes": [
            {"source_state_index": source, "sha256": sha, "ranks": ranks}
            for (source, sha), ranks in sorted(outcome_classes.items(), key=lambda item: item[1])
        ],
        "survivor_actor_set_classes": [
            {"source_state_index": source, "sha256": sha, "ranks": ranks}
            for (source, sha), ranks in sorted(survivor_classes.items(), key=lambda item: item[1])
        ],
        "selected_ranks": selected_ranks,
        "selection_rule": (
            "Every source-stratified full-outcome signature class is a singleton, so ranks "
            "26-30 are all selected; survivor-set equality is retained only as a control."
        ),
        "rows": rows,
        "selection_boundary": (
            "Signatures are source-stratified depth-1 descriptors used only for deterministic "
            "domain selection; equality does not imply deeper-closure equivalence or pruning."
        ),
        "failure_count": len(failures),
        "failures": failures,
    }
    Path(args.out).write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(
        json.dumps(
            {
                "target_count": result["target_count"],
                "source_actor_counts": result["source_actor_counts"],
                "outcome_signature_class_count": result["outcome_signature_class_count"],
                "survivor_actor_set_class_count": result["survivor_actor_set_class_count"],
                "selected_ranks": result["selected_ranks"],
                "failure_count": result["failure_count"],
            },
            indent=2,
            sort_keys=True,
        )
    )
    raise SystemExit(0 if not failures else 1)


if __name__ == "__main__":
    main()
