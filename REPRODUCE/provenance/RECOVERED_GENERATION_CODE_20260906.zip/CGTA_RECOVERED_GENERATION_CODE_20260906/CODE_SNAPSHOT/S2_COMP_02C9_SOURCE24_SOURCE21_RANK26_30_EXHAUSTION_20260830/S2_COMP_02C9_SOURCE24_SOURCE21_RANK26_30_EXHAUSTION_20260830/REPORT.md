# S2-COMP-02C9 Report — Source-24/21 Ranks 26–30

## 1. Frozen-domain census

The 02C8 predecessor freezes structural ranks 26–30 as follows:

| rank | source | N2 actors | target-disjoint actors | depth-1 survivors |
|---:|---:|---:|---:|---:|
| 26 | 24 | 355 | 342 | 19 |
| 27 | 24 | 355 | 340 | 19 |
| 28 | 24 | 355 | 339 | 19 |
| 29 | 21 | 409 | 345 | 26 |
| 30 | 24 | 355 | 337 | 19 |

This is an exact census of `4 × 355 + 1 × 409 = 1,829` actor-target cases.
It yields five source-stratified full-outcome signature classes and two
source-stratified survivor-actor-set classes:

- source 24: ranks `[26,27,28,30]` share one survivor actor set;
- source 21: rank `[29]` forms the other survivor actor set.

All five full-outcome classes are singletons. Therefore every rank 26–30 is
selected. No signature class is used to merge states, actor histories, or
deeper closures.

## 2. Exhaustive closure results

| rank | source | depth-1 survivors | depth-2 lineage paths | depth-2 physical states | transitions | total survivors | max depth |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 26 | 24 | 19 | 33 | 20 | 2,920 | 52 | 3 |
| 27 | 24 | 19 | 33 | 20 | 2,914 | 52 | 3 |
| 28 | 24 | 19 | 33 | 20 | 2,861 | 52 | 3 |
| 29 | 21 | 26 | 50 | 35 | 6,929 | 76 | 3 |
| 30 | 24 | 19 | 33 | 20 | 2,776 | 52 | 3 |
| **sum** | — | — | — | — | **18,400** | **284** | — |

Every closure has:

```text
closure_exhausted = true
failure_count = 0
anchor_extinction = 0
local_converse/no-stable-support hit = 0
independent R2 = 0
unstable-target R1 = 0
```

Every exact-confirmation output has `verified_count=0` and `failure_count=0`,
because no independent-R2 candidate was emitted by the exhaustive closures.

## 3. Load-bearing controls

### Equal depth-1 survivor set and path profile are not full equivalence

Ranks 26, 27, 28, and 30 share the same source-24 survivor actor set and the
same active-parent-path counts `[1,19,33]`. Nevertheless, their complete
transition counts are all distinct:

```text
rank 26 = 2,920
rank 27 = 2,914
rank 28 = 2,861
rank 30 = 2,776
```

Thus the census is a deterministic domain descriptor, not a quotient or a
pruning theorem.

### Actor-history multiplicity remains essential

At depth 2, source-24 domains have `33 lineage paths / 20 physical states`,
while source-21 rank 29 has `50 lineage paths / 35 physical states`.
Physical-state deduplication would change the frozen actor-history semantics.

## 4. Reproducibility actually performed

- outer 02C8 predecessor hash, embedded 02C7 hash, and direct 02C4 hash asserted;
- five-domain census fresh-rerun byte-identically;
- all five exhaustive closures fresh-rerun byte-identically;
- all five exact-confirmation outputs fresh-rerun byte-identically;
- registry rebuild, audit, and smoke fresh-rerun byte-identically;
- smoke independently reran one source-24 domain (rank 26) and the source-21
  domain (rank 29);
- all Python validation used `-B`; no top-level `.pyc` or `__pycache__` was
  generated.

## 5. Interpretation

This checkpoint closes exactly the five frozen target-specific,
target-disjoint N2 lineage domains at ranks 26–30. It does not prove universal
stable-anchor persistence, independent-R2 impossibility under zero stable
support, unstable-target R1 impossibility, or a signature-based equivalence
theorem.

Target-overlap and non-N2 cases remain separate future evidence buckets.
