from __future__ import annotations

import argparse
import json
from pathlib import Path

from s2comp02c4_env import PACKAGE_ROOT, PREDECESSOR_SHA256, C07_SHA256, sha256

EXPECTED = {
    "d7b_alternate_0_29": {
        "actors": 4635, "old_certs": 300, "old_literals": 4635,
        "changed_cert_actor_pairs": 18875, "r1_candidates": 0,
        "r2_candidates": 29, "r2_no_stable_candidates": 0,
    },
    "d6b3_admitted_both_branches": {
        "actors": 3029, "old_certs": 204, "old_literals": 3029,
        "changed_cert_actor_pairs": 8550, "r1_candidates": 0,
        "r2_candidates": 0, "r2_no_stable_candidates": 0,
    },
    "d7b_state10_alternate_depth2": {
        "actors": 5580, "old_certs": 912, "old_literals": 5580,
        "changed_cert_actor_pairs": 7150, "r1_candidates": 0,
        "r2_candidates": 6, "r2_no_stable_candidates": 0,
    },
}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--fast", type=Path, default=PACKAGE_ROOT/"s2comp02c4_fast_search_results.json")
    ap.add_argument("--exact", type=Path, default=PACKAGE_ROOT/"s2comp02c4_exact_confirmation_results.json")
    ap.add_argument("--out", type=Path, default=PACKAGE_ROOT/"s2comp02c4_audit_results.json")
    args=ap.parse_args()
    fast=json.loads(args.fast.read_text()); exact=json.loads(args.exact.read_text()); failures=[]
    for name,expected in EXPECTED.items():
        actual=fast["domains"][name]["aggregate"]
        if actual!=expected:
            failures.append({"kind":"aggregate_mismatch","domain":name,"expected":expected,"actual":actual})
    checks={
        "verified_count":35,
        "independent_r2_verified_count":35,
        "none_stable_verified_count":0,
        "unstable_target_r1_verified_count":0,
        "failure_count":0,
    }
    for k,v in checks.items():
        if exact.get(k)!=v: failures.append({"kind":"exact_mismatch","field":k,"expected":v,"actual":exact.get(k)})
    if exact.get("rescue_class_histogram")!={"R0+R1+R2":35}:
        failures.append({"kind":"rescue_histogram_mismatch","actual":exact.get("rescue_class_histogram")})
    pred=PACKAGE_ROOT/"source/S2_COMP_02C3_TARGET_DESCENDANT_NECESSITY_BOUNDARY_20260830.zip"
    c07=PACKAGE_ROOT/"source/c07d7c_absorption_partition_package.zip"
    if sha256(pred)!=PREDECESSOR_SHA256: failures.append({"kind":"predecessor_hash_mismatch","actual":sha256(pred)})
    if sha256(c07)!=C07_SHA256: failures.append({"kind":"c07_hash_mismatch","actual":sha256(c07)})
    result={
        "checkpoint":"S2-COMP-02C4 Rescue Existence Boundary",
        "status":"BOUNDED_SEARCH_CLOSED",
        "predecessor_sha256":sha256(pred),
        "c07_sha256":sha256(c07),
        "domain_aggregates":{name:fast["domains"][name]["aggregate"] for name in EXPECTED},
        "exact_confirmation":{k:exact.get(k) for k in ["verified_count","independent_r2_verified_count","none_stable_verified_count","unstable_target_r1_verified_count","rescue_class_histogram","failure_count"]},
        "closed_finite_claims":[
            "independent R2 is realizable in frozen semantics by explicit exact-confirmed witnesses",
            "all 35 audited independent-R2 witnesses coexist with stable old target provenance",
        ],
        "bounded_zero_counts_only":[
            "unstable-target R1 candidates = 0 in the three audited expanded domains",
            "no-stable independent-R2 candidates = 0 in the three audited expanded domains",
        ],
        "not_claimed":[
            "universal impossibility of unstable-target R1",
            "universal impossibility of R2-only/no-stable rescue",
            "R1 sufficiency",
            "independent-R2 sufficiency",
            "universal converse characterization",
        ],
        "failure_count":len(failures),
        "failures":failures,
    }
    args.out.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
    print(json.dumps(result,indent=2,sort_keys=True))
    if failures: raise SystemExit(1)

if __name__=="__main__": main()
