# S2-COMP-02C4 Claim Boundary

## CLOSED finite claims

1. The 02C3 packaged checkpoint is an immutable predecessor.
2. The three 02C4 search-domain reconstruction rules are explicit and deterministic.
3. Independent R2 is **realizable** in the frozen semantics: 35 explicit candidates
   were exact-confirmed, including the fixed state-10 witness.
4. All 35 exact-confirmed independent-R2 witnesses in the audited 02C4 domains
   also have at least one stable old target provenance.
5. The new four-axis cell
   `R0+R1+R2 × INDEPENDENT_NONTARGET_PRESENT × MULTI_MIXED × ALL_STABLE`
   is therefore OBSERVED and is recorded with a concrete fixture.

## BOUNDED EVIDENCE ONLY

Across the exact 02C4 audited domains:

- D7B alternate indices 0..29: 0 unstable-target-R1 candidates and 0 no-stable R2;
- D6B3 17 admitted states × 2 branches: 0 unstable-target-R1 and 0 independent R2;
- state-10 alternate depth-2 closure: 0 unstable-target-R1 and 0 no-stable R2.

These are **not** impossibility theorems.

## NOT CLAIMED / OPEN

- universal impossibility of unstable-target R1;
- universal impossibility of R2-only/no-stable independent rescue;
- R1 sufficiency;
- R2 sufficiency;
- universal converse;
- completeness of the 4-axis registry over all frozen states.

## Terminology guard

`rescue_classes` remains non-exclusive mechanism provenance. In particular,
`(R0,R1,R2)` does not mean that all three mechanisms are necessary for survival.
The 35 new R2 witnesses have stable old target provenance, so this checkpoint
must not be summarized as “R2 rescues a target after all old stable support is lost.”
