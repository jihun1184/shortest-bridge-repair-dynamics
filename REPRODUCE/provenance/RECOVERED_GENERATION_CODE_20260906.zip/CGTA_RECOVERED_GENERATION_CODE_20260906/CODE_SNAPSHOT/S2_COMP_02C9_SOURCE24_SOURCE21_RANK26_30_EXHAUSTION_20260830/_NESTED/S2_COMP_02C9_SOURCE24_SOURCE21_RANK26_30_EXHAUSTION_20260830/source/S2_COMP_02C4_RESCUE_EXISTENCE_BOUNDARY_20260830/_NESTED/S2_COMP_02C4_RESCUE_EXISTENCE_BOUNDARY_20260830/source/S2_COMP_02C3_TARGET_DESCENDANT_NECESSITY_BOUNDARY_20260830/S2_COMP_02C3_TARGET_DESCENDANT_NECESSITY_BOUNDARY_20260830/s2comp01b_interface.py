"""S2-COMP-01B: transition identity and exact certificate-effect interface.

This module does not redefine the repair semantics.  It exposes the existing
C07-D5 implementation through the hardened certificate record

    (predicate, anchor, support, carrier, witness, status)

and a canonical action record.  Snapshot identity is explicitly separated
from transition-level obligation identity.  The supported scope is narrow:
3D voxel states, addition-only actions, N1c Q2/Q3 failures, and N2 compatible
coordinate-wise monotone shortest bridges.
"""

from __future__ import annotations

import importlib
import hashlib
import json
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

Point = tuple[int, int, int]


def _points(values: Iterable[Iterable[int]]) -> tuple[Point, ...]:
    return tuple(sorted(tuple(int(x) for x in value) for value in values))


def _stable(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _stable(value[key]) for key in sorted(value)}
    if isinstance(value, (set, frozenset)):
        return tuple(sorted(_stable(item) for item in value))
    if isinstance(value, (tuple, list)):
        return tuple(_stable(item) for item in value)
    return value


@dataclass(frozen=True)
class Certificate:
    snapshot_id: str
    obligation_id: str
    layer: str
    predicate: str
    anchor: Any
    support: tuple[Point, ...]
    carrier: Any
    witness: Any
    status: str

    @property
    def certificate_id(self) -> str:
        """Backward-compatible 01A name; identity is snapshot-local."""
        return self.snapshot_id

    def record(self) -> dict[str, Any]:
        record = _stable(asdict(self))
        record["certificate_id"] = self.snapshot_id
        return record


@dataclass(frozen=True)
class CanonicalAction:
    action_id: str
    additions: tuple[Point, ...]
    roles: tuple[str, ...]
    certificate_snapshot_ids: tuple[str, ...]
    certificate_obligation_ids: tuple[str, ...]
    witnesses: tuple[Any, ...]
    edit_region: tuple[Point, ...]
    local_affected_region: tuple[Point, ...]

    @property
    def certificate_ids(self) -> tuple[str, ...]:
        """Backward-compatible 01A alias."""
        return self.certificate_snapshot_ids

    def record(self) -> dict[str, Any]:
        return _stable(asdict(self))


@dataclass(frozen=True)
class PersistenceLink:
    predicate: str
    before_snapshot_id: str
    after_snapshot_id: str
    before_obligation_id: str
    after_obligation_id: str
    relation: str

    def record(self) -> dict[str, Any]:
        return _stable(asdict(self))


@dataclass(frozen=True)
class TransitionEffect:
    action_id: str
    additions: tuple[Point, ...]
    resolved_snapshot_ids: tuple[str, ...]
    persisted: tuple[PersistenceLink, ...]
    created_snapshot_ids: tuple[str, ...]
    before_certificates: tuple[Certificate, ...]
    after_certificates: tuple[Certificate, ...]

    def record(self) -> dict[str, Any]:
        return {
            "action_id": self.action_id,
            "additions": self.additions,
            "resolved_snapshot_ids": self.resolved_snapshot_ids,
            "persisted": tuple(link.record() for link in self.persisted),
            "created_snapshot_ids": self.created_snapshot_ids,
            "before_certificates": tuple(item.record() for item in self.before_certificates),
            "after_certificates": tuple(item.record() for item in self.after_certificates),
        }


@dataclass(frozen=True)
class LegacyAPI:
    has_fail: Any
    masks_touching: Any
    is_disconnected: Any
    components6: Any
    component_certificates: Any
    descendant: Any
    atomic_actions: Any


def load_legacy(source_root: str | Path) -> LegacyAPI:
    """Load the exact C07-D7C package without modifying it."""
    root = Path(source_root).resolve()
    work = root / "work"
    paths = (
        work / "c07d3b" / "c07a_scripts",
        work / "c07d3e",
        work / "c07d4",
        work / "c07d5",
    )
    missing = [str(path) for path in paths if not path.is_dir()]
    if missing:
        raise FileNotFoundError(f"not a C07-D7C package root; missing: {missing}")
    for path in reversed(paths):
        value = str(path)
        if value not in sys.path:
            sys.path.insert(0, value)

    finite = importlib.import_module("finite_window_classification")
    compressed = importlib.import_module("compressed_decider")
    viability = importlib.import_module("c07d3e_component_viability")
    planning = importlib.import_module("c07d5_atomic_planning_census")
    return LegacyAPI(
        has_fail=finite.has_fail,
        masks_touching=compressed.masks_touching,
        is_disconnected=compressed.is_disconnected,
        components6=viability.components6,
        component_certificates=viability.component_certificates,
        descendant=viability.descendant,
        atomic_actions=planning.atomic_actions,
    )


def _occupied_labels(mask: dict[str, Any], state: frozenset[Point]) -> frozenset[Any]:
    return frozenset(
        label
        for position, label in zip(mask["positions"], mask["labels"])
        if tuple(position) in state
    )


def _identity_id(prefix: str, value: Any) -> str:
    payload = json.dumps(
        _stable(value),
        sort_keys=True,
        separators=(",", ":"),
    )
    return f"{prefix}-{hashlib.sha256(payload.encode('utf-8')).hexdigest()[:16]}"


def _legacy_snapshot_id(layer: str, predicate: str, anchor: Any, witness: Any) -> str:
    """Preserve the exact 01A certificate_id bytes as the 01B snapshot_id."""
    value = {
        "layer": layer,
        "predicate": predicate,
        "anchor": anchor,
        "witness": witness,
    }
    payload = json.dumps(_stable(value), sort_keys=True, separators=(",", ":"))
    return f"{layer.lower()}-{hashlib.sha256(payload.encode('utf-8')).hexdigest()[:16]}"


def _action_id(additions: tuple[Point, ...]) -> str:
    return _identity_id("add", additions)


def extract_certificates(state: Iterable[Point], api: LegacyAPI) -> tuple[Certificate, ...]:
    """Extract frozen-scope N1c and N2 component-pair certificates."""
    state = frozenset(tuple(point) for point in state)
    certificates: list[Certificate] = []

    seen_masks: set[Any] = set()
    masks = sorted(
        api.masks_touching(state),
        key=lambda mask: (mask["kind"], _points(mask["positions"])),
    )
    for mask in masks:
        positions = _points(mask["positions"])
        key = (mask["kind"], positions)
        if key in seen_masks:
            continue
        seen_masks.add(key)
        occupancy = _occupied_labels(mask, state)
        if not api.is_disconnected(mask, occupancy):
            continue
        predicate = f"N1c_{mask['kind']}_connectivity"
        anchor = {"kind": mask["kind"], "positions": positions}
        witness = {"occupied_labels": _stable(occupancy)}
        obligation_value = {"layer": "N", "predicate": predicate, "anchor": anchor}
        certificates.append(
            Certificate(
                snapshot_id=_legacy_snapshot_id("N", predicate, anchor, witness),
                obligation_id=_identity_id("obl-n1", obligation_value),
                layer="N",
                predicate=predicate,
                anchor=_stable(anchor),
                support=positions,
                carrier=tuple(),
                witness=_stable(witness),
                status="FAILED",
            )
        )

    for left, right in api.component_certificates(state):
        left_points = _points(left)
        right_points = _points(right)
        carrier = (left_points, right_points)
        anchor = {"kind": "unordered_6_component_pair"}
        witness = {"left_component": left_points, "right_component": right_points}
        obligation_value = {
            "layer": "N",
            "predicate": "N2_facet_connectivity",
            "carrier": carrier,
        }
        legacy_anchor = {"component_pair": carrier}
        certificates.append(
            Certificate(
                snapshot_id=_legacy_snapshot_id(
                    "N", "N2_facet_connectivity", legacy_anchor, witness
                ),
                obligation_id=_identity_id("obl-n2", obligation_value),
                layer="N",
                predicate="N2_facet_connectivity",
                anchor=_stable(anchor),
                support=tuple(),
                carrier=_stable(carrier),
                witness=_stable(witness),
                status="FAILED",
            )
        )

    return tuple(sorted(certificates, key=lambda item: item.snapshot_id))


def canonical_actions(
    state: Iterable[Point], api: LegacyAPI, certificates: tuple[Certificate, ...] | None = None
) -> tuple[CanonicalAction, ...]:
    """Return the frozen A_atom(X), deduplicated by addition set with provenance."""
    state = frozenset(tuple(point) for point in state)
    certificates = certificates or extract_certificates(state, api)
    n1 = [certificate for certificate in certificates if certificate.predicate.startswith("N1c_")]
    n2_by_pair = {
        (
            tuple(certificate.witness["left_component"]),
            tuple(certificate.witness["right_component"]),
        ): certificate
        for certificate in certificates
        if certificate.predicate == "N2_facet_connectivity"
    }

    output: list[CanonicalAction] = []
    for legacy in api.atomic_actions(state):
        additions = _points(legacy["additions"])
        roles = tuple(sorted(legacy["roles"]))
        certificate_snapshot_ids: set[str] = set()
        certificate_obligation_ids: set[str] = set()
        witnesses = tuple(_stable(witness) for witness in legacy["witnesses"])

        if "N1" in roles:
            addition_set = set(additions)
            matched = [
                certificate
                for certificate in n1
                if addition_set & set(certificate.support)
            ]
            certificate_snapshot_ids.update(item.snapshot_id for item in matched)
            certificate_obligation_ids.update(item.obligation_id for item in matched)
        if "N2" in roles:
            for witness in legacy["witnesses"]:
                if "certificate" not in witness:
                    continue
                pair = tuple(tuple(tuple(point) for point in component) for component in witness["certificate"])
                certificate = n2_by_pair.get(pair)
                if certificate is None:
                    reverse = (pair[1], pair[0])
                    certificate = n2_by_pair.get(reverse)
                if certificate is None:
                    raise AssertionError(f"legacy N2 witness did not resolve: {pair!r}")
                certificate_snapshot_ids.add(certificate.snapshot_id)
                certificate_obligation_ids.add(certificate.obligation_id)

        affected = {
            tuple(position)
            for mask in api.masks_touching(additions)
            for position in mask["positions"]
        }
        output.append(
            CanonicalAction(
                action_id=_action_id(additions),
                additions=additions,
                roles=roles,
                certificate_snapshot_ids=tuple(sorted(certificate_snapshot_ids)),
                certificate_obligation_ids=tuple(sorted(certificate_obligation_ids)),
                witnesses=tuple(sorted(witnesses, key=lambda item: json.dumps(item, sort_keys=True))),
                edit_region=additions,
                local_affected_region=_points(affected),
            )
        )
    return tuple(sorted(output, key=lambda action: action.additions))


def _n2_carrier_key(certificate: Certificate) -> tuple[Any, Any]:
    if certificate.predicate != "N2_facet_connectivity":
        raise ValueError("N2 carrier key requested for a non-N2 certificate")
    left, right = certificate.carrier
    return tuple(sorted((tuple(left), tuple(right))))


def transition_effect(
    state: Iterable[Point],
    action: CanonicalAction | Iterable[Point],
    api: LegacyAPI,
) -> TransitionEffect:
    """Classify exact before/after certificate effects under one addition.

    Persistence is a relation, not a snapshot-ID intersection.  N1 snapshots
    persist when predicate+mask-anchor obligation identity persists.  N2
    snapshots persist by mapping both old components to their unique
    addition-only descendants.  Several old pairs may map to one after pair.
    """
    state = frozenset(tuple(point) for point in state)
    if isinstance(action, CanonicalAction):
        additions = action.additions
        action_id = action.action_id
    else:
        additions = _points(action)
        action_id = _action_id(additions)
    if not additions:
        raise ValueError("effect requires a nonempty addition set")
    if set(additions) & state:
        raise ValueError("effect additions must be disjoint from the current state")
    successor = state | set(additions)
    before = extract_certificates(state, api)
    after = extract_certificates(successor, api)

    after_n1 = {
        item.obligation_id: item
        for item in after
        if item.predicate.startswith("N1c_")
    }
    after_n2 = {
        _n2_carrier_key(item): item
        for item in after
        if item.predicate == "N2_facet_connectivity"
    }
    after_components = api.components6(successor)
    links: list[PersistenceLink] = []

    for item in before:
        target = None
        relation = None
        if item.predicate.startswith("N1c_"):
            target = after_n1.get(item.obligation_id)
            relation = "same_predicate_and_mask_anchor"
        elif item.predicate == "N2_facet_connectivity":
            left, right = item.carrier
            left_descendant = api.descendant(frozenset(left), after_components)
            right_descendant = api.descendant(frozenset(right), after_components)
            if left_descendant != right_descendant:
                key = tuple(
                    sorted((_points(left_descendant), _points(right_descendant)))
                )
                target = after_n2.get(key)
                if target is None:
                    raise AssertionError(f"missing descendant N2 certificate for {key!r}")
                relation = "distinct_component_descendants"
        if target is not None:
            links.append(
                PersistenceLink(
                    predicate=item.predicate,
                    before_snapshot_id=item.snapshot_id,
                    after_snapshot_id=target.snapshot_id,
                    before_obligation_id=item.obligation_id,
                    after_obligation_id=target.obligation_id,
                    relation=relation,
                )
            )

    source_ids = {link.before_snapshot_id for link in links}
    target_ids = {link.after_snapshot_id for link in links}
    before_ids = {item.snapshot_id for item in before}
    after_ids = {item.snapshot_id for item in after}
    resolved = tuple(sorted(before_ids - source_ids))
    created = tuple(sorted(after_ids - target_ids))
    links_tuple = tuple(
        sorted(
            links,
            key=lambda link: (
                link.predicate,
                link.before_snapshot_id,
                link.after_snapshot_id,
            ),
        )
    )
    if source_ids | set(resolved) != before_ids:
        raise AssertionError("before-certificate effect partition failed")
    if target_ids | set(created) != after_ids:
        raise AssertionError("after-certificate effect partition failed")
    return TransitionEffect(
        action_id=action_id,
        additions=additions,
        resolved_snapshot_ids=resolved,
        persisted=links_tuple,
        created_snapshot_ids=created,
        before_certificates=before,
        after_certificates=after,
    )


def snapshot(state: Iterable[Point], api: LegacyAPI) -> dict[str, Any]:
    state = frozenset(tuple(point) for point in state)
    certificates = extract_certificates(state, api)
    actions = canonical_actions(state, api, certificates)
    return {
        "scope": "N1c/N2, 3D, addition-only, frozen C07-D5 atomic semantics",
        "state": _points(state),
        "certificate_count": len(certificates),
        "action_count": len(actions),
        "certificates": tuple(certificate.record() for certificate in certificates),
        "actions": tuple(action.record() for action in actions),
    }
