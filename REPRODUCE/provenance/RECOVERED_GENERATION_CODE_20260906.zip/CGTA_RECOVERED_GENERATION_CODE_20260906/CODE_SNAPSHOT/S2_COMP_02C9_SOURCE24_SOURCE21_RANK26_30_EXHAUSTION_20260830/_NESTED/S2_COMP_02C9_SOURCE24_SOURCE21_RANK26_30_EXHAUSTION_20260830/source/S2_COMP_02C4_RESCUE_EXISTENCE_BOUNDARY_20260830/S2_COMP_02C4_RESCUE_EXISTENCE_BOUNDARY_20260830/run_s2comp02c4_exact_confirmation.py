from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

from s2comp02c4_env import PACKAGE_ROOT, frozen_env
from s2comp02c4_domains import d7b_alternate_first_successor, state10_depth2_children


def key(points):
    return tuple(tuple(p) for p in points)


def confirm_candidate(env, state, candidate, label):
    canonical_actions = env.pred["canonical_actions"]
    extract_certificates = env.pred["extract_certificates"]
    directed_stability = env.pred["directed_stability"]
    trace_provenance = env.pred["trace_provenance"]
    quotient_fn = env.pred["assert_frozen_n2_bridge_quotient"]
    classify = env.pred["classify_target_descendants"]
    targeted_index = env.pred["_targeted_n2_successor_index"]
    fake_action = env.pred["_targeted_fake_action"]

    before = extract_certificates(state, env.api)
    before_dict = {c.snapshot_id: c for c in before}
    actions = {a.additions: a for a in canonical_actions(state, env.api, before)}
    actor = actions[key(candidate["actor"])]
    target = actions[key(candidate["literal"])]
    after_components, after_certificates, index = targeted_index(
        state, actor, env.api, env.bridge
    )
    after_ids = index.get(target.additions, ())
    if not after_ids:
        raise AssertionError(("fast candidate target did not survive exact targeted lookup", label, candidate))
    after_actions = {target.additions: fake_action(target, after_ids)}
    after_dict = {c.snapshot_id: c for c in after_certificates}
    stability = directed_stability(
        state,
        actor,
        target,
        env.api,
        successor_actions=after_actions,
        source_certificates=before_dict,
        after_components=after_components,
        after_certificates=after_dict,
    )
    quotient = quotient_fn(state, actor, env.api)
    profile = classify(
        target=target,
        directed_stability=stability,
        after_actions=after_actions,
        after_certificates=after_certificates,
        quotient=quotient,
        api=env.api,
        state=state,
        actor=actor,
    )
    trace = trace_provenance(
        state,
        actor,
        target,
        env.api,
        env.bridge,
        state_label=label,
        before_certificates=before,
    )
    return {
        "label": label,
        "actor_additions": [list(p) for p in actor.additions],
        "target_additions": [list(p) for p in target.additions],
        "survives": stability.target_literal_survives,
        "profile": profile.record(),
        "rescue_classes": list(trace.rescue_classes),
        "primary_rescue_class": trace.primary_rescue_class,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fast", type=Path, default=PACKAGE_ROOT / "s2comp02c4_fast_search_results.json")
    parser.add_argument("--out", type=Path, default=PACKAGE_ROOT / "s2comp02c4_exact_confirmation_results.json")
    args = parser.parse_args()
    fast = json.loads(args.fast.read_text())
    verified = []
    failures = []

    with frozen_env() as env:
        # Alternate branch candidates: exact confirmation of every fast R2/R2-no-stable hit.
        for row in fast["domains"]["d7b_alternate_0_29"]["rows"]:
            candidates = row["representatives"]["r2"] + row["representatives"]["r2_no_stable"]
            if not candidates:
                continue
            state, meta = d7b_alternate_first_successor(env, row["source_state_index"])
            for ordinal, candidate in enumerate(candidates):
                rec = confirm_candidate(
                    env, state, candidate,
                    f"d7b_alt_{row['source_state_index']:03d}_candidate_{ordinal:03d}",
                )
                rec["domain"] = "d7b_alternate_0_29"
                rec["state_meta"] = meta
                verified.append(rec)

        # Depth-2 candidates: reconstruct all 225 children in the frozen actor order.
        child_by_index = {}
        for child, meta in state10_depth2_children(env, env.pred["canonical_actions"]):
            child_by_index[meta["parent_actor_index"]] = (child, meta)
        for row in fast["domains"]["d7b_state10_alternate_depth2"]["rows"]:
            candidates = row["representatives"]["r2"] + row["representatives"]["r2_no_stable"]
            if not candidates:
                continue
            state, meta = child_by_index[row["parent_actor_index"]]
            for ordinal, candidate in enumerate(candidates):
                rec = confirm_candidate(
                    env, state, candidate,
                    f"d7b_alt_010_depth2_parent_{row['parent_actor_index']:03d}_candidate_{ordinal:03d}",
                )
                rec["domain"] = "d7b_state10_alternate_depth2"
                rec["state_meta"] = meta
                verified.append(rec)

    for rec in verified:
        profile = rec["profile"]
        if not rec["survives"]:
            failures.append({"kind": "candidate_did_not_survive", "record": rec})
        if not profile["independent_r2_branch_present"]:
            failures.append({"kind": "candidate_not_independent_r2", "record": rec})

    fast_agg = {
        name: block["aggregate"] for name, block in fast["domains"].items()
    }
    expected_fast_r2 = sum(x["r2_candidates"] for x in fast_agg.values())
    if len(verified) != expected_fast_r2:
        failures.append({
            "kind": "candidate_count_mismatch",
            "fast_r2": expected_fast_r2,
            "exact_verified": len(verified),
        })

    result = {
        "checkpoint": "S2-COMP-02C4",
        "kind": "exact_02C3_confirmation",
        "fast_domain_aggregates": fast_agg,
        "verified_count": len(verified),
        "independent_r2_verified_count": sum(
            bool(r["profile"]["independent_r2_branch_present"]) for r in verified
        ),
        "none_stable_verified_count": sum(
            r["profile"]["d6_stability_type"] == "NONE_STABLE" for r in verified
        ),
        "unstable_target_r1_verified_count": sum(
            bool(r["profile"]["unstable_target_r1_branch_present"]) for r in verified
        ),
        "rescue_class_histogram": {
            "+".join(classes): count
            for classes, count in sorted(Counter(tuple(r["rescue_classes"]) for r in verified).items())
        },
        "verified": verified,
        "failure_count": len(failures),
        "failures": failures,
    }
    args.out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: result[k] for k in [
        "verified_count", "independent_r2_verified_count", "none_stable_verified_count",
        "unstable_target_r1_verified_count", "rescue_class_histogram", "failure_count"
    ]}, indent=2, sort_keys=True))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
