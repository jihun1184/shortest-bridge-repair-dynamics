from __future__ import annotations

import argparse
import json
from pathlib import Path

from s2comp02c4_env import PACKAGE_ROOT, frozen_env
from s2comp02c4_domains import (
    d7b_alternate_first_successor,
    generate_d6b3_admitted_states,
    d6b3_first_successors,
    state10_depth2_children,
)
from s2comp02c4_mechanism_search import search_state

COUNT_KEYS = [
    "actors", "old_certs", "old_literals", "changed_cert_actor_pairs",
    "r1_candidates", "r2_candidates", "r2_no_stable_candidates",
]


def aggregate(rows):
    return {k: sum(row["counts"][k] for row in rows) for k in COUNT_KEYS}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--domain", required=True, choices=["d7b-alt", "d6b3", "state10-depth2"])
    ap.add_argument("--start", type=int, required=True)
    ap.add_argument("--end", type=int, required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    if args.start < 0 or args.end < args.start:
        raise SystemExit("invalid range")

    with frozen_env() as env:
        tasks = []
        if args.domain == "d7b-alt":
            if args.end > 30:
                raise SystemExit("d7b-alt canonical freeze range is 0..30")
            for i in range(args.start, args.end):
                state, meta = d7b_alternate_first_successor(env, i)
                tasks.append((i, state, meta))
        elif args.domain == "d6b3":
            admitted = generate_d6b3_admitted_states(env)
            all_tasks = list(d6b3_first_successors(env, admitted))
            if args.end > len(all_tasks):
                raise SystemExit(f"d6b3 flattened range is 0..{len(all_tasks)}")
            for j in range(args.start, args.end):
                state, meta = all_tasks[j]
                tasks.append((j, state, meta))
        else:
            all_tasks = list(state10_depth2_children(env, env.pred["canonical_actions"]))
            if args.end > len(all_tasks):
                raise SystemExit(f"state10-depth2 range is 0..{len(all_tasks)}")
            for j in range(args.start, args.end):
                state, meta = all_tasks[j]
                if meta["parent_actor_index"] != j:
                    raise AssertionError((j, meta))
                tasks.append((j, state, meta))

        rows = []
        for index, state, meta in tasks:
            counts, reps = search_state(state, env.api, env.bridge)
            rows.append({"index": index, **meta, "counts": counts, "representatives": reps})

    result = {
        "checkpoint": "S2-COMP-02C4",
        "kind": "mechanism_search_shard",
        "domain": args.domain,
        "range": [args.start, args.end],
        "rows": rows,
        "aggregate": aggregate(rows),
    }
    args.out.write_text(json.dumps(result, indent=2, sort_keys=True, default=list) + "\n")
    print(json.dumps(result["aggregate"], indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
