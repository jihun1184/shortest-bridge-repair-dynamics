"""Regression gate: targeted N2 successor support == full canonical successor support.

Uses the frozen 02C1 multi-provenance fixture (state index 1), all three
multi-provenance targets, and every disjoint canonical actor: 128 directions.
"""
from __future__ import annotations
import contextlib, json, tempfile
from pathlib import Path

from s2comp01b_interface import canonical_actions, extract_certificates, load_legacy
from s2comp02c_provenance import load_bridge_api
from run_s2comp02c1_audit import extract_single_root
from run_s2comp02c3_audit import HERE, SOURCE_C07_ZIP, _targeted_n2_successor_index

OUT = HERE / 's2comp02c3_targeted_support_gate_results.json'


def main():
    mismatches=[]; directions=0
    with contextlib.ExitStack() as stack:
        tmp=Path(stack.enter_context(tempfile.TemporaryDirectory(prefix='c3_target_gate_')))
        root=extract_single_root(SOURCE_C07_ZIP,tmp/'c07')
        api=load_legacy(root); bridge=load_bridge_api(root)
        raw=json.loads((root/'work/c07d7/c07d7b_satellite_depth4_attack_results.json').read_text())
        initial=frozenset(tuple(p) for p in raw['tested'][1]['state'])
        first=api.atomic_actions(initial)[0]
        state=initial|{tuple(p) for p in first['additions']}
        before=extract_certificates(state,api)
        before_n2={c.snapshot_id for c in before if c.predicate=='N2_facet_connectivity'}
        actions=canonical_actions(state,api,before)
        targets=tuple(a for a in actions if 'N2' in a.roles and sum(s in before_n2 for s in a.certificate_snapshot_ids)>1)
        for target in targets:
            for actor in actions:
                if actor.action_id==target.action_id or set(actor.additions)&set(target.additions):
                    continue
                directions += 1
                successor=state|set(actor.additions)
                full_actions={a.additions:a for a in canonical_actions(successor,api)}
                full=full_actions.get(target.additions)
                after_certs=extract_certificates(successor,api)
                after_n2_ids={c.snapshot_id for c in after_certs if c.predicate=='N2_facet_connectivity'}
                full_ids=tuple(sorted(
                    sid for sid in (full.certificate_snapshot_ids if full is not None and 'N2' in full.roles else tuple())
                    if sid in after_n2_ids
                ))
                _ac,_aft,targeted_index=_targeted_n2_successor_index(state,actor,api,bridge)
                targeted_ids=tuple(targeted_index.get(target.additions,tuple()))
                if full_ids != targeted_ids:
                    mismatches.append({
                        'actor_additions':actor.additions,
                        'target_additions':target.additions,
                        'full_n2_support_ids':full_ids,
                        'targeted_n2_support_ids':targeted_ids,
                    })
    result={
        'checkpoint':'S2-COMP-02C3 targeted successor support regression gate',
        'state_index':1,
        'multi_target_count':3,
        'direction_count':directions,
        'mismatch_count':len(mismatches),
        'mismatches':mismatches[:20],
    }
    OUT.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))
    if directions != 128 or mismatches:
        raise SystemExit(1)

if __name__=='__main__': main()
