# S2-COMP-02C4 — Rescue Existence Boundary

This is a bounded-search checkpoint above the immutable 02C3 package.

## Canonical stored results

- `results/d7b_alt_000_015.json`
- `results/d7b_alt_015_030.json`
- `results/d6b3_000_034.json`
- `results/state10_depth2_000_225.json`
- `s2comp02c4_fast_search_results.json` — deterministic aggregate
- `s2comp02c4_exact_confirmation_results.json` — exact 02C3 confirmation of all 35 R2 hits
- `cell_status_registry.json`

## Fresh reproduction

Searches are shardable because depth-2 state costs vary substantially. The
canonical commands are:

```bash
python run_s2comp02c4_search_shard.py --domain d7b-alt --start 0 --end 15 --out /tmp/alt0.json
python run_s2comp02c4_search_shard.py --domain d7b-alt --start 15 --end 30 --out /tmp/alt1.json
python run_s2comp02c4_search_shard.py --domain d6b3 --start 0 --end 34 --out /tmp/d6b3.json
python run_s2comp02c4_search_shard.py --domain state10-depth2 --start 0 --end 225 --out /tmp/depth2.json
python run_s2comp02c4_aggregate.py /tmp/alt0.json /tmp/alt1.json /tmp/d6b3.json /tmp/depth2.json --out /tmp/fast.json
python run_s2comp02c4_exact_confirmation.py --fast /tmp/fast.json --out /tmp/exact.json
python run_s2comp02c4_audit.py --fast /tmp/fast.json --exact /tmp/exact.json --out /tmp/audit.json
```

Any range may be subdivided further. `run_s2comp02c4_aggregate.py` rejects gaps,
duplicates, or out-of-range row indices.
