from __future__ import annotations

import hashlib
import importlib
import json
import sys
import tempfile
import zipfile
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parent
PREDECESSOR_NAME = "S2_COMP_02C3_TARGET_DESCENDANT_NECESSITY_BOUNDARY_20260830.zip"
C07_NAME = "c07d7c_absorption_partition_package.zip"
PREDECESSOR_SHA256 = "200cb0567c3298d39841b18a2b208d0505df6b861797ddead1b0fe7f1e468022"
C07_SHA256 = "c4dffec9864126566a8ad8e8c5825961b375b6bdddede0630c2c3a56a1804fc2"
PREDECESSOR_ROOT_NAME = "S2_COMP_02C3_TARGET_DESCENDANT_NECESSITY_BOUNDARY_20260830"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


@dataclass(frozen=True)
class FrozenEnv:
    temp_root: Path
    predecessor_root: Path
    c07_root: Path
    api: object
    bridge: object
    pred: dict[str, object]


@contextmanager
def frozen_env():
    pred_zip = PACKAGE_ROOT / "source" / PREDECESSOR_NAME
    c07_zip = PACKAGE_ROOT / "source" / C07_NAME
    assert sha256(pred_zip) == PREDECESSOR_SHA256
    assert sha256(c07_zip) == C07_SHA256
    with tempfile.TemporaryDirectory(prefix="s2comp02c4_") as td:
        tmp = Path(td)
        with zipfile.ZipFile(pred_zip) as zf:
            zf.extractall(tmp / "pred")
        with zipfile.ZipFile(c07_zip) as zf:
            zf.extractall(tmp / "c07")
        pred_root = tmp / "pred" / PREDECESSOR_ROOT_NAME
        c07_root = tmp / "c07" / "c07d7c_package"
        if not pred_root.is_dir() or not c07_root.is_dir():
            raise RuntimeError("frozen predecessor extraction failed")
        sys.dont_write_bytecode = True
        sys.path.insert(0, str(pred_root))
        try:
            from s2comp01b_interface import load_legacy, canonical_actions, extract_certificates
            from s2comp02b_distance import d6, directed_stability
            from s2comp02c_provenance import load_bridge_api, trace_provenance
            from s2comp02c2_quotient import assert_frozen_n2_bridge_quotient
            from s2comp02c3_target_descendants import classify_target_descendants
            from run_s2comp02c3_audit import _targeted_n2_successor_index, _targeted_fake_action
            api = load_legacy(c07_root)
            bridge = load_bridge_api(c07_root)
            pred = {
                "canonical_actions": canonical_actions,
                "extract_certificates": extract_certificates,
                "d6": d6,
                "directed_stability": directed_stability,
                "trace_provenance": trace_provenance,
                "assert_frozen_n2_bridge_quotient": assert_frozen_n2_bridge_quotient,
                "classify_target_descendants": classify_target_descendants,
                "_targeted_n2_successor_index": _targeted_n2_successor_index,
                "_targeted_fake_action": _targeted_fake_action,
            }
            yield FrozenEnv(tmp, pred_root, c07_root, api, bridge, pred)
        finally:
            try:
                sys.path.remove(str(pred_root))
            except ValueError:
                pass
