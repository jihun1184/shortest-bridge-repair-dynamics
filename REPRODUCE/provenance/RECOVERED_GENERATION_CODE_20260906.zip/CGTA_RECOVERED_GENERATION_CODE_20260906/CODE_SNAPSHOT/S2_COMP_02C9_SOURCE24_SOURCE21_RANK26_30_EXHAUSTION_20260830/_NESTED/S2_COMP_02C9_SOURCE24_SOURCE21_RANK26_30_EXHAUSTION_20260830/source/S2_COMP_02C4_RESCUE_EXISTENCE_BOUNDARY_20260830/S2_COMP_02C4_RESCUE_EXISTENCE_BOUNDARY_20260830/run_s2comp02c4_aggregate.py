from __future__ import annotations

import argparse
import json
from pathlib import Path

COUNT_KEYS = [
    "actors", "old_certs", "old_literals", "changed_cert_actor_pairs",
    "r1_candidates", "r2_candidates", "r2_no_stable_candidates",
]
EXPECTED_RANGES = {"d7b-alt": (0,30), "d6b3": (0,34), "state10-depth2": (0,225)}
CANONICAL_NAMES = {
    "d7b-alt": "d7b_alternate_0_29",
    "d6b3": "d6b3_admitted_both_branches",
    "state10-depth2": "d7b_state10_alternate_depth2",
}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("shards", nargs="+", type=Path)
    ap.add_argument("--out", type=Path, required=True)
    args=ap.parse_args()
    by_domain={k:[] for k in EXPECTED_RANGES}
    for path in args.shards:
        d=json.loads(path.read_text()); by_domain[d["domain"]].append(d)
    domains={}
    for domain, shards in by_domain.items():
        if not shards: raise SystemExit(f"missing domain {domain}")
        rows=[]
        for s in shards: rows.extend(s["rows"])
        rows.sort(key=lambda r:r["index"])
        expected=list(range(*EXPECTED_RANGES[domain]))
        actual=[r["index"] for r in rows]
        if actual!=expected: raise AssertionError((domain,"gap/overlap",actual[:10],actual[-10:]))
        agg={k:sum(r["counts"][k] for r in rows) for k in COUNT_KEYS}
        domains[CANONICAL_NAMES[domain]]={"rows":rows,"aggregate":agg}
    result={"checkpoint":"S2-COMP-02C4","kind":"aggregated_fast_candidate_search","domains":domains}
    args.out.write_text(json.dumps(result,indent=2,sort_keys=True,default=list)+"\n")
    print(json.dumps({k:v["aggregate"] for k,v in domains.items()},indent=2,sort_keys=True))

if __name__=="__main__": main()
