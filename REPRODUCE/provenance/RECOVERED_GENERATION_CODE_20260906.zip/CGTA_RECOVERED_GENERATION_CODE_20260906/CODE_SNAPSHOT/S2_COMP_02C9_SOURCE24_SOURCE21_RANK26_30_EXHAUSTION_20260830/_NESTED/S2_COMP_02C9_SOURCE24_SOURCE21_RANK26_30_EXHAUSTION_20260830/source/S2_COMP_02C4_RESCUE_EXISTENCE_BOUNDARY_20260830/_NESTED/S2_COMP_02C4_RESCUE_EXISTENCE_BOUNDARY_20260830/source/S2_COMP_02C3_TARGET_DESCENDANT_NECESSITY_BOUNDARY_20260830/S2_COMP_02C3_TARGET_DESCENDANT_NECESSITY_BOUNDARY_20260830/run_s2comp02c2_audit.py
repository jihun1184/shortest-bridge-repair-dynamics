"""S2-COMP-02C2: adversarial multi-provenance rescue exhaustion + N2 quotient gate.

This checkpoint has two jobs:

Q1. Exhaust the complete D7B first-successor source index range 0..149 for
    multi-provenance N2 canonical actions, then audit every disjoint actor ->
    multi-target direction in every discovered state.

Q2. Check the exact component-pair quotient theorem for every canonical actor
    in every discovered multi-provenance state.  The quotient theorem proves,
    for frozen N2 bridge actions, that after N2 certificates have old ancestors
    (hence N2-R3 is impossible) and that strict component coarsening with at
    least two after-components forces certificate merge.

The expanded zero count for independent R2 is bounded evidence only; it is not
promoted to a universal theorem here.
"""
from __future__ import annotations

import contextlib
import json
import tempfile
from collections import Counter
from pathlib import Path

from s2comp01b_interface import canonical_actions, extract_certificates, load_legacy
from s2comp02b_distance import directed_stability
from s2comp02c_provenance import load_bridge_api, trace_provenance
from s2comp02c2_quotient import assert_frozen_n2_bridge_quotient
from run_s2comp02c1_audit import (
    classify_r2,
    extract_single_root,
    is_locally_separated,
    successor_caches,
    unique_n2_witness_count,
)

HERE = Path(__file__).resolve().parent
SOURCE_C07_ZIP = HERE / "source" / "c07d7c_absorption_partition_package.zip"
ALL_SOURCE_INDICES = tuple(range(150))


def _json_hist(counter: Counter) -> dict[str, int]:
    return {str(k): v for k, v in sorted(counter.items(), key=lambda item: str(item[0]))}


def discover_multi_provenance(initial_states, api):
    support_histogram = Counter()
    role_histogram = Counter()
    records = []
    state_summary = []
    for index in ALL_SOURCE_INDICES:
        initial = initial_states[index]
        first = api.atomic_actions(initial)[0]
        state = initial | {tuple(p) for p in first["additions"]}
        actions = api.atomic_actions(state)
        n2_count = 0
        multi_count = 0
        for action in actions:
            if "N2" not in action["roles"]:
                continue
            n2_count += 1
            role_histogram[tuple(sorted(action["roles"]))] += 1
            k = unique_n2_witness_count(action)
            support_histogram[k] += 1
            if k > 1:
                multi_count += 1
                records.append({
                    "state_index": index,
                    "first_additions": action.get("first_additions", first["additions"]),
                    "target_additions": action["additions"],
                    "n2_provenance_count": k,
                })
        state_summary.append({
            "state_index": index,
            "canonical_action_count": len(actions),
            "n2_action_count": n2_count,
            "multi_provenance_action_count": multi_count,
        })
        if index in (49, 99, 149):
            print(f"[Q1 discovery] completed indices 0..{index}; multi={len(records)}", flush=True)
    records.sort(key=lambda row: (row["state_index"], row["target_additions"]))
    return {
        "searched_state_indices": list(ALL_SOURCE_INDICES),
        "n2_support_count_histogram": dict(sorted(support_histogram.items())),
        "n2_role_histogram": {"+".join(k): v for k, v in sorted(role_histogram.items())},
        "multi_provenance_action_count": len(records),
        "multi_state_indices": sorted({row["state_index"] for row in records}),
        "records": records,
        "state_summary": state_summary,
    }


def audit_discovered_multi_states(initial_states, api, bridge_api, state_indices):
    total = Counter()
    direction_hist = Counter()
    local_hist = Counter()
    rescue_hist = Counter()
    quotient_transition_hist = Counter()
    actor_role_hist = Counter()
    state_rows = []
    representative_independent = []
    representative_r3 = []
    representative_merge = []

    for index in state_indices:
        initial = initial_states[index]
        first = api.atomic_actions(initial)[0]
        state = initial | {tuple(p) for p in first["additions"]}
        before_certificates_tuple = extract_certificates(state, api)
        before_certificates = {c.snapshot_id: c for c in before_certificates_tuple}
        before_n2_ids = {
            c.snapshot_id for c in before_certificates_tuple
            if c.predicate == "N2_facet_connectivity"
        }
        actions = canonical_actions(state, api, before_certificates_tuple)
        multi_targets = tuple(
            action for action in actions
            if "N2" in action.roles
            and sum(sid in before_n2_ids for sid in action.certificate_snapshot_ids) > 1
        )

        q_by_actor = {}
        for actor in actions:
            actor_role_hist[tuple(actor.roles)] += 1
            if "N2" not in actor.roles:
                raise AssertionError(f"unexpected non-N2 actor in multi state {index}: {actor.roles}")
            q = assert_frozen_n2_bridge_quotient(state, actor, api)
            q_by_actor[actor.action_id] = q
            quotient_transition_hist[(q.before_component_count, q.after_component_count)] += 1
            total["quotient_actor_count"] += 1
            total["quotient_after_pair_without_ancestor_count"] += len(q.after_pairs_without_old_ancestor)
            total["quotient_after_component_without_old_ancestor_count"] += len(q.after_components_without_old_ancestor)
            if q.after_component_count >= 2 and q.persistence_noninjective:
                total["quotient_forced_merge_actor_count"] += 1
            if q.after_component_count >= 2 and not q.persistence_noninjective:
                total["quotient_merge_theorem_violation_count"] += 1

        cache = {}
        state_count = Counter()
        for target in multi_targets:
            for actor in actions:
                if actor.action_id == target.action_id or set(actor.additions) & set(target.additions):
                    continue
                total["direction_count"] += 1
                state_count["direction_count"] += 1
                q = q_by_actor[actor.action_id]
                if not q.persistence_noninjective:
                    total["globally_merge_free_direction_count"] += 1

                after_actions, after_components, after_certificates_tuple, after_certificates = successor_caches(
                    state, actor, api, cache
                )
                ds = directed_stability(
                    state, actor, target, api,
                    successor_actions=after_actions,
                    source_certificates=before_certificates,
                    after_components=after_components,
                    after_certificates=after_certificates,
                )
                stable_count = sum(w.distance_stable for w in ds.witnesses)
                survives = ds.target_literal_survives
                local = is_locally_separated(actor, target)
                direction_hist[(stable_count, survives)] += 1
                local_hist[(local, stable_count, survives)] += 1
                if survives and stable_count == 0:
                    total["converse_counterexample_count"] += 1
                if local and stable_count > 0 and not survives:
                    total["local_sufficient_violation_count"] += 1
                if not survives:
                    continue

                total["survivor_count"] += 1
                state_count["survivor_count"] += 1
                if not q.persistence_noninjective:
                    total["globally_merge_free_survivor_count"] += 1

                trace = trace_provenance(
                    state, actor, target, api, bridge_api,
                    state_label=f"D7B_first_successor_{index:03d}",
                    before_certificates=before_certificates_tuple,
                    after_actions=after_actions,
                    after_certificates=after_certificates_tuple,
                ).record()
                rescue_hist[tuple(trace["rescue_classes"])] += 1
                r2_rows, merge_rows, independent_rows = classify_r2(trace)
                total["r2_trace_count"] += len(r2_rows)
                total["merge_induced_r2_trace_count"] += len(merge_rows)
                total["independent_r2_trace_count"] += len(independent_rows)
                if r2_rows:
                    total["r2_direction_count"] += 1
                if merge_rows:
                    total["merge_induced_r2_direction_count"] += 1
                    if len(representative_merge) < 8:
                        representative_merge.append({
                            "state_index": index,
                            "actor_additions": actor.additions,
                            "target_additions": target.additions,
                            "merge_descendant_ids": sorted({row["descendant_snapshot_id"] for row in merge_rows}),
                        })
                if independent_rows:
                    total["independent_r2_direction_count"] += 1
                    if len(representative_independent) < 8:
                        representative_independent.append({
                            "state_index": index,
                            "actor_additions": actor.additions,
                            "target_additions": target.additions,
                            "independent_descendant_ids": sorted({row["descendant_snapshot_id"] for row in independent_rows}),
                        })
                if trace["r3_certificate_snapshot_ids"]:
                    total["r3_direction_count"] += 1
                    if len(representative_r3) < 8:
                        representative_r3.append({
                            "state_index": index,
                            "actor_additions": actor.additions,
                            "target_additions": target.additions,
                            "r3_ids": trace["r3_certificate_snapshot_ids"],
                        })

        state_rows.append({
            "state_index": index,
            "first_additions": first["additions"],
            "before_component_count": len(api.components6(state)),
            "before_n2_certificate_count": len(before_n2_ids),
            "canonical_action_count": len(actions),
            "multi_target_count": len(multi_targets),
            "direction_count": state_count["direction_count"],
            "survivor_count": state_count["survivor_count"],
        })
        print(
            f"[Q2 adversarial] state={index} targets={len(multi_targets)} "
            f"directions={state_count['direction_count']} survivors={state_count['survivor_count']}",
            flush=True,
        )

    for key in (
        "quotient_after_pair_without_ancestor_count",
        "quotient_after_component_without_old_ancestor_count",
        "quotient_merge_theorem_violation_count",
        "globally_merge_free_direction_count",
        "globally_merge_free_survivor_count",
        "converse_counterexample_count",
        "local_sufficient_violation_count",
        "independent_r2_direction_count",
        "independent_r2_trace_count",
        "r3_direction_count",
    ):
        total.setdefault(key, 0)

    return {
        "state_indices": list(state_indices),
        "state_rows": state_rows,
        "totals": dict(total),
        "direction_histogram": {
            f"stable_supports={stable},survives={survives}": count
            for (stable, survives), count in sorted(direction_hist.items())
        },
        "local_direction_histogram": {
            f"local={local},stable_supports={stable},survives={survives}": count
            for (local, stable, survives), count in sorted(local_hist.items())
        },
        "rescue_combination_histogram_among_survivors": {
            "+".join(key): value for key, value in sorted(rescue_hist.items())
        },
        "actor_role_histogram": {
            "+".join(key): value for key, value in sorted(actor_role_hist.items())
        },
        "quotient_component_transition_histogram": {
            f"{before}->{after}": value
            for (before, after), value in sorted(quotient_transition_hist.items())
        },
        "representative_merge_induced_r2": representative_merge,
        "representative_independent_r2": representative_independent,
        "representative_r3": representative_r3,
    }


def main():
    failures = []
    with contextlib.ExitStack() as stack:
        tmp = Path(stack.enter_context(tempfile.TemporaryDirectory(prefix="s2comp02c2_")))
        root = extract_single_root(SOURCE_C07_ZIP, tmp / "c07")
        api = load_legacy(root)
        bridge_api = load_bridge_api(root)
        raw = json.loads((root / "work" / "c07d7" / "c07d7b_satellite_depth4_attack_results.json").read_text())
        rows = raw["tested"] if isinstance(raw, dict) else raw
        initial_states = [
            frozenset(tuple(point) for point in (row["state"] if isinstance(row, dict) else row))
            for row in rows
        ]

        discovery = discover_multi_provenance(initial_states, api)
        adversarial = audit_discovered_multi_states(
            initial_states, api, bridge_api, discovery["multi_state_indices"]
        )

    expected_indices = [1, 2, 4, 7, 40, 41, 112, 113, 114, 115]
    if discovery["n2_support_count_histogram"] != {1: 57464, 2: 26}:
        failures.append({"gate": "Q1_support_histogram", "observed": discovery["n2_support_count_histogram"]})
    if discovery["multi_provenance_action_count"] != 26:
        failures.append({"gate": "Q1_multi_action_count", "observed": discovery["multi_provenance_action_count"]})
    if discovery["multi_state_indices"] != expected_indices:
        failures.append({"gate": "Q1_multi_state_indices", "observed": discovery["multi_state_indices"]})

    totals = adversarial["totals"]
    expected_totals = {
        "quotient_actor_count": 1988,
        "quotient_forced_merge_actor_count": 1986,
        "quotient_after_pair_without_ancestor_count": 0,
        "quotient_after_component_without_old_ancestor_count": 0,
        "quotient_merge_theorem_violation_count": 0,
        "direction_count": 2575,
        "globally_merge_free_direction_count": 0,
        "survivor_count": 809,
        "globally_merge_free_survivor_count": 0,
        "converse_counterexample_count": 0,
        "local_sufficient_violation_count": 0,
        "r2_direction_count": 579,
        "merge_induced_r2_direction_count": 579,
        "independent_r2_direction_count": 0,
        "r2_trace_count": 802,
        "merge_induced_r2_trace_count": 802,
        "independent_r2_trace_count": 0,
        "r3_direction_count": 0,
    }
    for key, expected in expected_totals.items():
        observed = totals.get(key, 0)
        if observed != expected:
            failures.append({"gate": f"Q2_{key}", "observed": observed, "expected": expected})

    expected_direction_hist = {
        "stable_supports=0,survives=False": 1693,
        "stable_supports=1,survives=False": 61,
        "stable_supports=1,survives=True": 293,
        "stable_supports=2,survives=False": 12,
        "stable_supports=2,survives=True": 516,
    }
    if adversarial["direction_histogram"] != expected_direction_hist:
        failures.append({
            "gate": "Q2_direction_histogram",
            "observed": adversarial["direction_histogram"],
            "expected": expected_direction_hist,
        })
    expected_rescue = {"R0": 230, "R0+R1+R2": 579}
    if adversarial["rescue_combination_histogram_among_survivors"] != expected_rescue:
        failures.append({
            "gate": "Q2_rescue_histogram",
            "observed": adversarial["rescue_combination_histogram_among_survivors"],
            "expected": expected_rescue,
        })
    expected_transition_hist = {"5->1": 2, "5->2": 402, "5->3": 1020, "5->4": 564}
    if adversarial["quotient_component_transition_histogram"] != expected_transition_hist:
        failures.append({
            "gate": "Q2_quotient_transition_histogram",
            "observed": adversarial["quotient_component_transition_histogram"],
            "expected": expected_transition_hist,
        })
    if adversarial["actor_role_histogram"] != {"N2": 1988}:
        failures.append({"gate": "Q2_actor_roles", "observed": adversarial["actor_role_histogram"]})

    result = {
        "checkpoint": "S2-COMP-02C2 N2 quotient / adversarial rescue exhaustion",
        "scope": {
            "discovery": "complete D7B first-successor source indices 0..149",
            "adversarial": "all disjoint actor->target directions for all multi-provenance N2 targets in every discovered first-successor state",
            "proved_here": [
                "exact N2 component-pair quotient fiber formula for frozen N2 bridge actions",
                "no genuinely created after N2 certificate (N2-R3 exclusion) under frozen N2 bridge actions",
                "strict component coarsening with >=2 after components forces non-injective N2 certificate persistence",
            ],
            "not_proved_here": [
                "universal converse survival=>exists stable old target provenance",
                "universal impossibility of independent R2",
            ],
            "predecessors_modified": [],
        },
        "multi_provenance_discovery": discovery,
        "adversarial_multi_state_audit": adversarial,
        "failure_count": len(failures),
        "failures": failures,
    }
    out = HERE / "s2comp02c2_audit_results.json"
    out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "multi_provenance_action_count_all_150": discovery["multi_provenance_action_count"],
        "multi_state_count": len(discovery["multi_state_indices"]),
        "adversarial_direction_count": totals.get("direction_count", 0),
        "survivor_count": totals.get("survivor_count", 0),
        "globally_merge_free_direction_count": totals.get("globally_merge_free_direction_count", 0),
        "independent_r2_direction_count": totals.get("independent_r2_direction_count", 0),
        "r3_direction_count": totals.get("r3_direction_count", 0),
        "failure_count": len(failures),
    }, indent=2, sort_keys=True))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
