"""S2-COMP-02: exact pairwise action-interaction observables.

This module deliberately stops short of asserting a global independence
theorem.  It classifies two actions that are both canonical at one state and
records enabling as a separate directed relation.
"""

from __future__ import annotations

import hashlib
import json
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from typing import Any, Iterable

from s2comp01b_interface import (
    CanonicalAction,
    LegacyAPI,
    TransitionEffect,
    canonical_actions,
    transition_effect,
)

Point = tuple[int, int, int]


def _stable(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _stable(value[key]) for key in sorted(value)}
    if isinstance(value, (set, frozenset)):
        return tuple(sorted(_stable(item) for item in value))
    if isinstance(value, (tuple, list)):
        return tuple(_stable(item) for item in value)
    return value


def _identifier(prefix: str, value: Any) -> str:
    payload = json.dumps(_stable(value), sort_keys=True, separators=(",", ":"))
    return f"{prefix}-{hashlib.sha256(payload.encode('utf-8')).hexdigest()[:16]}"


def _predicate_map(effect: TransitionEffect) -> dict[str, str]:
    return {item.snapshot_id: item.predicate for item in effect.before_certificates} | {
        item.snapshot_id: item.predicate for item in effect.after_certificates
    }


def effect_profile(effect: TransitionEffect) -> tuple[tuple[str, str, int], ...]:
    """Return a context-comparable but intentionally coarse effect profile."""
    predicates = _predicate_map(effect)
    counts: Counter[tuple[str, str]] = Counter()
    for snapshot_id in effect.resolved_snapshot_ids:
        counts[("resolved", predicates[snapshot_id])] += 1
    for link in effect.persisted:
        counts[("persisted_link", link.predicate)] += 1
    for snapshot_id in effect.created_snapshot_ids:
        counts[("created", predicates[snapshot_id])] += 1
    return tuple(sorted((kind, predicate, count) for (kind, predicate), count in counts.items()))


@dataclass(frozen=True)
class NetEffect:
    resolved_snapshot_ids: tuple[str, ...]
    persisted_pairs: tuple[tuple[str, str, str], ...]
    created_snapshot_ids: tuple[str, ...]

    def record(self) -> dict[str, Any]:
        return _stable(asdict(self))


def direct_net_effect(effect: TransitionEffect) -> NetEffect:
    return NetEffect(
        resolved_snapshot_ids=effect.resolved_snapshot_ids,
        persisted_pairs=tuple(
            sorted(
                (link.predicate, link.before_snapshot_id, link.after_snapshot_id)
                for link in effect.persisted
            )
        ),
        created_snapshot_ids=effect.created_snapshot_ids,
    )


def compose_effects(first: TransitionEffect, second: TransitionEffect) -> NetEffect:
    """Compose persistence relations and recover the net endpoint partition."""
    first_after = {item.snapshot_id for item in first.after_certificates}
    second_before = {item.snapshot_id for item in second.before_certificates}
    if first_after != second_before:
        raise ValueError("effects are not composable: intermediate snapshots differ")

    second_by_source: dict[str, list[Any]] = defaultdict(list)
    for link in second.persisted:
        second_by_source[link.before_snapshot_id].append(link)

    composed: list[tuple[str, str, str]] = []
    for left in first.persisted:
        for right in second_by_source.get(left.after_snapshot_id, ()):  # relation composition
            if left.predicate != right.predicate:
                raise AssertionError("predicate changed across a persistence composition")
            composed.append((left.predicate, left.before_snapshot_id, right.after_snapshot_id))

    source_ids = {before for _, before, _ in composed}
    target_ids = {after for _, _, after in composed}
    initial_ids = {item.snapshot_id for item in first.before_certificates}
    final_ids = {item.snapshot_id for item in second.after_certificates}
    return NetEffect(
        resolved_snapshot_ids=tuple(sorted(initial_ids - source_ids)),
        persisted_pairs=tuple(sorted(composed)),
        created_snapshot_ids=tuple(sorted(final_ids - target_ids)),
    )


def _lookup(actions: Iterable[CanonicalAction]) -> dict[tuple[Point, ...], CanonicalAction]:
    return {action.additions: action for action in actions}


@dataclass(frozen=True)
class PairInteraction:
    pair_id: str
    action_a_id: str
    action_b_id: str
    additions_a: tuple[Point, ...]
    additions_b: tuple[Point, ...]
    roles_a: tuple[str, ...]
    roles_b: tuple[str, ...]
    edit_overlap: tuple[Point, ...]
    b_survives_after_a: bool
    a_survives_after_b: bool
    availability_class: str
    interaction_class: str
    composed_relation_equal: bool | None
    path_ab_matches_direct_union: bool | None
    path_ba_matches_direct_union: bool | None
    profile_b_stable_after_a: bool | None
    profile_a_stable_after_b: bool | None
    local_affected_separation: bool

    def record(self) -> dict[str, Any]:
        return _stable(asdict(self))


def classify_pair(
    state: Iterable[Point],
    action_a: CanonicalAction,
    action_b: CanonicalAction,
    api: LegacyAPI,
    successor_action_cache: dict[str, dict[tuple[Point, ...], CanonicalAction]] | None = None,
    base_effect_cache: dict[str, TransitionEffect] | None = None,
) -> PairInteraction:
    """Classify an unordered pair of actions canonical at ``state``.

    ``I`` is an operational census class, not a theorem: both literal actions
    survive and both composed persistence relations agree with the direct
    union effect.  Whole-state predicate-count profile stability is retained
    as a stricter diagnostic; it is not part of ``I``.
    """
    state = frozenset(tuple(point) for point in state)
    if action_b.additions < action_a.additions:
        action_a, action_b = action_b, action_a
    overlap = tuple(sorted(set(action_a.additions) & set(action_b.additions)))
    local_separation = (
        not (set(action_a.edit_region) & set(action_b.local_affected_region))
        and not (set(action_b.edit_region) & set(action_a.local_affected_region))
    )
    pair_id = _identifier("pair", (action_a.additions, action_b.additions))
    if overlap:
        return PairInteraction(
            pair_id, action_a.action_id, action_b.action_id,
            action_a.additions, action_b.additions, action_a.roles, action_b.roles,
            overlap, False, False, "OVERLAPPING_EDIT", "C", None, None, None,
            None, None, local_separation,
        )

    state_a = state | set(action_a.additions)
    state_b = state | set(action_b.additions)
    successor_action_cache = successor_action_cache if successor_action_cache is not None else {}
    base_effect_cache = base_effect_cache if base_effect_cache is not None else {}
    actions_a = successor_action_cache.get(action_a.action_id)
    if actions_a is None:
        actions_a = _lookup(canonical_actions(state_a, api))
        successor_action_cache[action_a.action_id] = actions_a
    actions_b = successor_action_cache.get(action_b.action_id)
    if actions_b is None:
        actions_b = _lookup(canonical_actions(state_b, api))
        successor_action_cache[action_b.action_id] = actions_b
    b_after_a = actions_a.get(action_b.additions)
    a_after_b = actions_b.get(action_a.additions)
    b_survives = b_after_a is not None
    a_survives = a_after_b is not None

    if b_survives and a_survives:
        availability = "BIDIRECTIONAL"
    elif b_survives:
        availability = "A_THEN_B_ONLY"
    elif a_survives:
        availability = "B_THEN_A_ONLY"
    else:
        availability = "MUTUAL_DISABLEMENT"

    effect_a = base_effect_cache.get(action_a.action_id)
    if effect_a is None:
        effect_a = transition_effect(state, action_a, api)
        base_effect_cache[action_a.action_id] = effect_a
    effect_b = base_effect_cache.get(action_b.action_id)
    if effect_b is None:
        effect_b = transition_effect(state, action_b, api)
        base_effect_cache[action_b.action_id] = effect_b
    profile_b_stable = None
    profile_a_stable = None
    path_ab = None
    path_ba = None
    composed_equal = None

    union = tuple(sorted(set(action_a.additions) | set(action_b.additions)))
    direct = direct_net_effect(transition_effect(state, union, api))
    net_ab = None
    net_ba = None
    if b_after_a is not None:
        second_b = transition_effect(state_a, b_after_a, api)
        net_ab = compose_effects(effect_a, second_b)
        path_ab = net_ab == direct
        profile_b_stable = effect_profile(effect_b) == effect_profile(second_b)
    if a_after_b is not None:
        second_a = transition_effect(state_b, a_after_b, api)
        net_ba = compose_effects(effect_b, second_a)
        path_ba = net_ba == direct
        profile_a_stable = effect_profile(effect_a) == effect_profile(second_a)
    if net_ab is not None and net_ba is not None:
        composed_equal = net_ab == net_ba

    if availability == "BIDIRECTIONAL":
        interaction = "I" if all(
            (composed_equal, path_ab, path_ba)
        ) else "C"
    elif availability in ("A_THEN_B_ONLY", "B_THEN_A_ONLY"):
        interaction = "P"
    else:
        interaction = "D"

    return PairInteraction(
        pair_id, action_a.action_id, action_b.action_id,
        action_a.additions, action_b.additions, action_a.roles, action_b.roles,
        overlap, b_survives, a_survives, availability, interaction,
        composed_equal, path_ab, path_ba, profile_b_stable,
        profile_a_stable, local_separation,
    )


@dataclass(frozen=True)
class EnablingEvent:
    event_id: str
    enabler_action_id: str
    enabler_additions: tuple[Point, ...]
    enabled_action_id: str
    enabled_additions: tuple[Point, ...]
    enabled_roles: tuple[str, ...]

    def record(self) -> dict[str, Any]:
        return _stable(asdict(self))


def enabling_events(state: Iterable[Point], action: CanonicalAction, api: LegacyAPI) -> tuple[EnablingEvent, ...]:
    """Return literal new canonical actions after ``action``.

    This is generator-level enabling.  It does not yet assert causal
    minimality, because an enabled action may depend on several state changes.
    """
    state = frozenset(tuple(point) for point in state)
    before = _lookup(canonical_actions(state, api))
    successor = state | set(action.additions)
    after = _lookup(canonical_actions(successor, api))
    events = []
    for additions, enabled in sorted(after.items()):
        if additions in before:
            continue
        events.append(
            EnablingEvent(
                event_id=_identifier("enable", (action.additions, additions)),
                enabler_action_id=action.action_id,
                enabler_additions=action.additions,
                enabled_action_id=enabled.action_id,
                enabled_additions=enabled.additions,
                enabled_roles=enabled.roles,
            )
        )
    return tuple(events)
