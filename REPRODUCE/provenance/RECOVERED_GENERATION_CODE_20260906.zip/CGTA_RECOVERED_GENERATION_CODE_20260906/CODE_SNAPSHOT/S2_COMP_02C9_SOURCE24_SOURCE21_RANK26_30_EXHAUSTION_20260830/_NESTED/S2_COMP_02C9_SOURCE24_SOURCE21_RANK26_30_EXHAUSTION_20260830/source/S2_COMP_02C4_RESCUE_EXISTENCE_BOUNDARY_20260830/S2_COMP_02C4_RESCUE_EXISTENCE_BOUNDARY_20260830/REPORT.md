# S2-COMP-02C4 Report — Rescue Existence Boundary

## Main result

The expanded search found the first exact independent-R2 instances in the
project. 29 occur in D7B alternate first-successor states (indices 9/10/25:
8/8/13), and 6 more occur one level deeper below the state-10 alternate branch.
All 35 exact-confirm as `INDEPENDENT_NONTARGET_PRESENT`, but all 35 also retain
stable old target support. Thus independent R2 exists, while R2-only/no-stable
rescue remains unobserved.

## Domain totals

| Domain | N2 actors | changed-cert/actor | R1 candidates | independent R2 | no-stable R2 |
|---|---:|---:|---:|---:|---:|
| D7B alternate 0..29 | 4,635 | 18,875 | 0 | 29 | 0 |
| D6B3 17×2 branches | 3,029 | 8,550 | 0 | 0 | 0 |
| state-10 alternate depth-2 | 5,580 | 7,150 | 0 | 6 | 0 |

The search stage is deliberately a candidate generator. All 35 nonzero R2
hits are subsequently confirmed through the complete frozen 02C3 classifier.

## Rejected lemma

A provisional argument `|b| = d6-1`, intended to exclude unstable R1 by literal
cardinality, was rejected before freeze. The frozen generator contains bridge
actions with `d6=6` and only four additions because a shortest path may traverse
a third already-existing component. No theorem or gate in this checkpoint uses
that invalid cardinality argument.

## Registry

`cell_status_registry.json` is append-only by policy. It imports the four
previously observed 02C3 multi-domain cells with concrete fixtures and appends
the new independent-R2 cell with the state-10 alternate fixture. R3-containing
patterns remain `IMPOSSIBLE_BY_THEOREM` by the frozen 02C2 quotient result.
