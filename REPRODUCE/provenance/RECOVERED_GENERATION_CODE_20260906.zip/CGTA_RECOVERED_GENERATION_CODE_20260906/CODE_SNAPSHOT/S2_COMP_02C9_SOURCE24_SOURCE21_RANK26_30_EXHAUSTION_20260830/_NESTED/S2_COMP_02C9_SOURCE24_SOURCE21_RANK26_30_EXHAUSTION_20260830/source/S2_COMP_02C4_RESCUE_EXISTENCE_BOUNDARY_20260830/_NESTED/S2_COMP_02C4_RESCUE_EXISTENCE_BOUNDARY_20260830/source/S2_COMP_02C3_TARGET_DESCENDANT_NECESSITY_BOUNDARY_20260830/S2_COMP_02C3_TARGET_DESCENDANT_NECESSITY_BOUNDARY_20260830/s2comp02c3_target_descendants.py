"""S2-COMP-02C3 target-descendant structure and necessity instrumentation.

Additive instrumentation only; no frozen predecessor is modified.

For one surviving N2 target b after actor a, combine:
  * 02B directed_stability(): each old target-supporting certificate c, its
    descendant certificate c^a, and whether d6(c^a)=d6(c);
  * the surviving canonical action's after-state certificate_snapshot_ids;
  * 02C2's exact quotient fiber multiplicity for every after N2 certificate.

This yields three orthogonal axes without re-running realization-level tracing:
  ancestry type x target-descendant structure x old-target d6 stability.

Necessity lemma encoded here:
If b survives and no old target-supporting provenance has stable d6, then every
after N2 certificate supporting b has an old ancestor (02C2 R3 exclusion).  If
one has a target-supporting old ancestor, that old provenance's descendant
regenerates b with changed d6 (the changed-realization R1 branch).  Otherwise
that supporting after certificate has only non-target old ancestors, giving an
independent R2 branch.  Hence R1 OR independent-R2 is necessary.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class TargetDescendantCertificate:
    snapshot_id: str
    ancestor_multiplicity: int
    target_old_ancestor_count: int
    nontarget_old_ancestor_count: int
    stable_target_old_ancestor_count: int
    unstable_target_old_ancestor_count: int

    def record(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class TargetDescendantProfile:
    target_descendant_multiplicity: int
    descendant_structure: str
    ancestry_type: str
    d6_stability_type: str
    old_target_support_count: int
    stable_old_target_support_count: int
    unstable_old_target_support_count: int
    target_descendants: tuple[TargetDescendantCertificate, ...]
    stable_target_descendant_present: bool
    unstable_target_r1_branch_present: bool
    independent_r2_branch_present: bool
    target_local_merge_present: bool
    doubled_independent_realization: bool

    def record(self) -> dict[str, Any]:
        value = asdict(self)
        value["target_descendants"] = tuple(row.record() for row in self.target_descendants)
        return value


def _descendant_structure(multiplicities: tuple[int, ...]) -> str:
    if not multiplicities:
        return "NONE"
    if len(multiplicities) == 1:
        return "SINGLE_UNMERGED" if multiplicities[0] == 1 else "SINGLE_MERGED"
    if all(value == 1 for value in multiplicities):
        return "MULTI_INDEPENDENT"
    return "MULTI_MIXED"


def _d6_type(stable: int, total: int) -> str:
    if total <= 0:
        return "NO_OLD_TARGET_SUPPORT"
    if stable == 0:
        return "NONE_STABLE"
    if stable == total:
        return "ALL_STABLE"
    return "SOME_STABLE"


def _ancestry_type(rows: tuple[TargetDescendantCertificate, ...]) -> str:
    independent_nontarget = any(
        row.target_old_ancestor_count == 0 and row.nontarget_old_ancestor_count > 0
        for row in rows
    )
    merged_nontarget = any(
        row.target_old_ancestor_count > 0 and row.nontarget_old_ancestor_count > 0
        for row in rows
    )
    if independent_nontarget:
        return "INDEPENDENT_NONTARGET_PRESENT"
    if merged_nontarget:
        return "TARGET_WITH_MERGED_NONTARGET"
    return "TARGET_OLD_ONLY"


def classify_target_descendants(
    *, target, directed_stability, after_actions, after_certificates,
    quotient, api, state, actor,
) -> TargetDescendantProfile:
    """Classify one surviving N2 target and cross-check the exact fiber formula."""
    surviving = after_actions.get(target.additions)
    if surviving is None or "N2" not in surviving.roles:
        raise ValueError("target-descendant profile requires a surviving N2 target")

    after_n2 = {
        cert.snapshot_id: cert for cert in after_certificates
        if cert.predicate == "N2_facet_connectivity"
    }
    support_ids = tuple(sorted(
        sid for sid in surviving.certificate_snapshot_ids if sid in after_n2
    ))
    if not support_ids:
        raise AssertionError("surviving N2 target has no after N2 certificate support")

    successor = frozenset(state) | set(actor.additions)
    after_components = tuple(api.components6(successor))
    component_index = {
        tuple(sorted(tuple(p) for p in comp)): idx for idx, comp in enumerate(after_components)
    }
    quotient_mult = dict(quotient.after_pair_ancestor_multiplicities)

    witnesses_by_descendant: dict[str, list[Any]] = {}
    for witness in directed_stability.witnesses:
        if witness.descendant_snapshot_id is None:
            continue
        witnesses_by_descendant.setdefault(witness.descendant_snapshot_id, []).append(witness)

    cert_rows = []
    for sid in support_ids:
        cert = after_n2[sid]
        left_key = tuple(sorted(tuple(p) for p in cert.carrier[0]))
        right_key = tuple(sorted(tuple(p) for p in cert.carrier[1]))
        pair = tuple(sorted((component_index[left_key], component_index[right_key])))
        ancestor_multiplicity = quotient_mult[pair]

        target_witnesses = witnesses_by_descendant.get(sid, [])
        target_count = len(target_witnesses)
        if target_count > ancestor_multiplicity:
            raise AssertionError("target-old ancestors exceed quotient fiber multiplicity")
        stable_target = sum(bool(w.distance_stable) for w in target_witnesses)
        cert_rows.append(TargetDescendantCertificate(
            snapshot_id=sid,
            ancestor_multiplicity=ancestor_multiplicity,
            target_old_ancestor_count=target_count,
            nontarget_old_ancestor_count=ancestor_multiplicity - target_count,
            stable_target_old_ancestor_count=stable_target,
            unstable_target_old_ancestor_count=target_count - stable_target,
        ))

    cert_rows = tuple(sorted(cert_rows, key=lambda row: row.snapshot_id))
    multiplicities = tuple(row.ancestor_multiplicity for row in cert_rows)
    stable_count = sum(bool(w.distance_stable) for w in directed_stability.witnesses)
    old_support_count = len(directed_stability.witnesses)

    # Certificate-level source branches.  If an unstable old target witness's
    # descendant certificate supports the surviving target, that descendant
    # regenerates b despite changed d6; this is precisely the R1 branch at the
    # source/certificate level (realization identity itself need not be traced).
    changed_r1 = any(
        (not w.distance_stable) and w.target_descendant_provenance_survives
        for w in directed_stability.witnesses
    )
    stable_desc = any(
        w.distance_stable and w.target_descendant_provenance_survives
        for w in directed_stability.witnesses
    )
    independent_r2 = any(
        row.target_old_ancestor_count == 0 and row.nontarget_old_ancestor_count > 0
        for row in cert_rows
    )

    profile = TargetDescendantProfile(
        target_descendant_multiplicity=len(cert_rows),
        descendant_structure=_descendant_structure(multiplicities),
        ancestry_type=_ancestry_type(cert_rows),
        d6_stability_type=_d6_type(stable_count, old_support_count),
        old_target_support_count=old_support_count,
        stable_old_target_support_count=stable_count,
        unstable_old_target_support_count=old_support_count - stable_count,
        target_descendants=cert_rows,
        stable_target_descendant_present=stable_desc,
        unstable_target_r1_branch_present=changed_r1,
        independent_r2_branch_present=independent_r2,
        target_local_merge_present=any(row.ancestor_multiplicity > 1 for row in cert_rows),
        doubled_independent_realization=(len(cert_rows) > 1 and all(row.ancestor_multiplicity == 1 for row in cert_rows)),
    )
    assert_profile_consistency(profile)
    return profile


def assert_profile_consistency(profile: TargetDescendantProfile) -> None:
    if profile.target_descendant_multiplicity < 1:
        raise AssertionError("surviving target must have >=1 after N2 certificate")
    if profile.doubled_independent_realization and profile.descendant_structure != "MULTI_INDEPENDENT":
        raise AssertionError("doubled-independent/profile structure mismatch")
    if profile.independent_r2_branch_present and profile.ancestry_type != "INDEPENDENT_NONTARGET_PRESENT":
        raise AssertionError("independent-R2/profile ancestry mismatch")


def necessity_dichotomy(profile: TargetDescendantProfile) -> dict[str, Any]:
    predicate = profile.d6_stability_type == "NONE_STABLE"
    if not predicate:
        return {
            "predicate_no_stable_old_target": False,
            "required_branch_satisfied": None,
        }
    return {
        "predicate_no_stable_old_target": True,
        "required_branch_satisfied": (
            profile.unstable_target_r1_branch_present
            or profile.independent_r2_branch_present
        ),
    }
