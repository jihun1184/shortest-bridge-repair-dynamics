from __future__ import annotations

import itertools
import json
import sys
from contextlib import contextmanager


def _serial_action(action):
    return {
        "additions": [list(p) for p in action["additions"]],
        "roles": list(action["roles"]),
    }


def _assert_legacy_action_order(actions):
    additions = [tuple(tuple(p) for p in a["additions"]) for a in actions]
    if additions != sorted(additions):
        raise AssertionError("frozen atomic_actions order is not lexicographic by additions")


def load_d7b_rows(env):
    path = env.c07_root / "work/c07d7/c07d7b_satellite_depth4_attack_results.json"
    return json.loads(path.read_text())["tested"]


def d7b_alternate_first_successor(env, state_index: int):
    """Reconstruct the previously unused second N1 first-successor branch.

    Frozen c07d5.atomic_actions returns actions sorted lexicographically by
    additions. D7B tested sources have exactly two N1-only initial actions.
    The historical 02C1--02C3 path used index 0; 02C4 alternate branch is index 1.
    """
    rows = load_d7b_rows(env)
    row = rows[state_index]
    initial = frozenset(tuple(p) for p in row["state"])
    actions = env.api.atomic_actions(initial)
    _assert_legacy_action_order(actions)
    if len(actions) != 2:
        raise AssertionError((state_index, "expected exactly two initial actions", len(actions)))
    if any(tuple(a["roles"]) != ("N1",) for a in actions):
        raise AssertionError((state_index, "expected N1-only initial actions", actions))
    chosen = actions[1]
    state = initial | frozenset(tuple(p) for p in chosen["additions"])
    return state, {
        "source_state_index": state_index,
        "branch_index": 1,
        "branch_rule": "second lexicographic frozen atomic_actions entry",
        "initial_action": _serial_action(chosen),
    }


@contextmanager
def _c07_import_paths(env, relative_dirs):
    paths = [str(env.c07_root / rel) for rel in relative_dirs]
    for path in reversed(paths):
        sys.path.insert(0, path)
    try:
        yield
    finally:
        for path in paths:
            try:
                sys.path.remove(path)
            except ValueError:
                pass


def generate_d6b3_admitted_states(env):
    """Exact reconstruction of the 17 admitted D6B3 overlap states."""
    work = env.c07_root / "work"
    rels = [
        "work/c07d6b",
        "work/c07d3e",
        "work/c07d4",
        "work/c07d5",
        "work/c07d3b/c07a_scripts",
    ]
    with _c07_import_paths(env, rels):
        from finite_window_classification import has_fail
        from c07d3e1_targeted_search import valid_single_add_repairs
        from c07d3e5_counterexample_verify import X as X0
        from c07d3e_component_viability import components6
        from c07d5_atomic_planning_census import atomic_actions, canonical_isometry_class
        from c07d6b1_one_voxel_break_search import dual_role_N1_repairs
        from c07d6b3_overlap_attack import preserves_all_current_N2_fast, preservation_audit

        source = json.loads(
            (work / "c07d6b/c07d6b2_two_voxel_break_search_results.json").read_text()
        )
        seeds = tuple(
            frozenset(tuple(p) for p in audit["representative"])
            for audit in source["audits"]
        )
        mins = tuple(min(p[a] for p in X0) - 2 for a in range(3))
        maxs = tuple(max(p[a] for p in X0) + 2 for a in range(3))
        window = tuple(
            itertools.product(*(range(mins[a], maxs[a] + 1) for a in range(3)))
        )
        reps = {}
        for seed_index, seed in enumerate(seeds):
            for extra in window:
                if extra in seed:
                    continue
                state = frozenset(set(seed) | {extra})
                reps.setdefault(canonical_isometry_class(state), (state, seed_index, extra))

        admitted = []
        for orbit_index, (_orbit_key, (state, seed_index, extra)) in enumerate(sorted(reps.items())):
            if not has_fail(state):
                continue
            repairs = valid_single_add_repairs(state)
            if not repairs:
                continue
            if dual_role_N1_repairs(state, repairs):
                continue
            if any(
                preserves_all_current_N2_fast(state, {"additions": (v,), "roles": ("N1",)})
                for v in repairs
            ):
                continue
            actions = atomic_actions(state)
            _assert_legacy_action_order(actions)
            if any(preserves_all_current_N2_fast(state, action) for action in actions):
                continue
            policy = preservation_audit(state, actions)
            if any(record["allowed"] for record in policy):
                raise AssertionError("D6B3 fast/full preservation crosscheck mismatch")
            admitted.append(
                {
                    "orbit_index": orbit_index,
                    "state": [list(p) for p in sorted(state)],
                    "seed_index": seed_index,
                    "extra": list(extra),
                    "component_count": len(components6(state)),
                    "repair_count": len(repairs),
                    "action_count": len(actions),
                }
            )
    if len(admitted) != 17:
        raise AssertionError(("expected 17 D6B3 admitted states", len(admitted)))
    return admitted


def d6b3_first_successors(env, admitted):
    """Yield both deterministic initial branches for each admitted state."""
    for admitted_index, row in enumerate(admitted):
        initial = frozenset(tuple(p) for p in row["state"])
        actions = env.api.atomic_actions(initial)
        _assert_legacy_action_order(actions)
        if len(actions) != 2:
            raise AssertionError((admitted_index, "expected exactly two D6B3 initial actions", len(actions)))
        for branch_index, chosen in enumerate(actions):
            state = initial | frozenset(tuple(p) for p in chosen["additions"])
            yield state, {
                "admitted_index": admitted_index,
                "orbit_index": row["orbit_index"],
                "branch_index": branch_index,
                "branch_rule": "frozen atomic_actions lexicographic index",
                "initial_action": _serial_action(chosen),
            }


def state10_alternate_depth1(env):
    state, meta = d7b_alternate_first_successor(env, 10)
    return state, meta


def state10_depth2_children(env, canonical_actions):
    """Yield the full deterministic depth-2 closure used in 02C4.

    Parent actors are all canonical actions with an N2 role at D7B source index
    10's alternate first successor, in canonical_actions lexicographic-additions
    order. Each parent actor is applied once. All 225 successors are distinct.
    """
    depth1, base_meta = state10_alternate_depth1(env)
    actors = [a for a in canonical_actions(depth1, env.api) if "N2" in a.roles]
    additions = [a.additions for a in actors]
    if additions != sorted(additions):
        raise AssertionError("canonical N2 actor order is not lexicographic by additions")
    if len(actors) != 225:
        raise AssertionError(("expected 225 state-10 alternate N2 parent actors", len(actors)))
    seen = set()
    for actor_index, actor in enumerate(actors):
        child = frozenset(depth1 | set(actor.additions))
        key = tuple(sorted(child))
        if key in seen:
            raise AssertionError(("duplicate depth-2 child", actor_index))
        seen.add(key)
        yield child, {
            **base_meta,
            "parent_actor_index": actor_index,
            "parent_actor_additions": [list(p) for p in actor.additions],
            "parent_actor_id": actor.action_id,
            "parent_actor_rule": "all N2-role canonical_actions, lexicographic additions order",
        }
    if len(seen) != 225:
        raise AssertionError(("expected 225 distinct depth-2 states", len(seen)))
