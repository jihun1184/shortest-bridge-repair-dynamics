"""S2-COMP-02C3: Target-Descendant Necessity Boundary audit.

Frozen predecessors are imported byte-for-byte.  This audit adds one new
classifier and applies it to two already-frozen bounded domains:

A. the exact 02C1 broad six-state domain (11,156 directed cases), and
B. the complete 02C2 multi-provenance target domain (2,575 directed cases).

For every surviving N2 target it records three orthogonal axes:
ancestry type x target-descendant structure x old-target d6 stability.
It also gates the necessity implication proved in THEOREM.md:

    if b survives and every old target-supporting d6 changes,
    then (R1 from an old target provenance) OR (independent R2) is necessary,

because R0 would imply a stable old realization and R3 is impossible in the
frozen N2 quotient semantics.
"""
from __future__ import annotations

import contextlib
import itertools
import json
import tempfile
from collections import Counter
from pathlib import Path

from s2comp01b_interface import CanonicalAction, canonical_actions, extract_certificates, load_legacy
from s2comp02b_distance import directed_stability
from s2comp02c2_quotient import assert_frozen_n2_bridge_quotient
from s2comp02c_provenance import load_bridge_api, trace_provenance
from s2comp02c3_target_descendants import classify_target_descendants, necessity_dichotomy
from run_s2comp02c1_audit import (
    DISTRIBUTED_INDICES,
    EXPANSION_SAMPLE_SIZE,
    evenly_spaced,
    extract_single_root,
    is_locally_separated,
)

HERE = Path(__file__).resolve().parent
SOURCE_C07_ZIP = HERE / "source" / "c07d7c_absorption_partition_package.zip"


def _hist(counter: Counter) -> dict[str, int]:
    return {str(k): v for k, v in sorted(counter.items(), key=lambda kv: str(kv[0]))}


def _profile_key(profile) -> str:
    return (
        f"ancestry={profile.ancestry_type}|"
        f"desc={profile.descendant_structure}|"
        f"d6={profile.d6_stability_type}"
    )



def _targeted_n2_successor_index(state, actor, api, bridge_api):
    """Build only the after-state N2 addition->certificate map for one actor.

    This is semantically the N2 slice of canonical_actions(successor), but it
    calls the frozen certificate_bridge_actions() directly and skips all N1
    work.  A regression gate checks its survivor counts against 02C1/02C2.
    """
    successor = frozenset(state) | set(actor.additions)
    after_components = api.components6(successor)
    after_certificates = extract_certificates(successor, api)
    additions_to_ids = {}
    for cert in after_certificates:
        if cert.predicate != "N2_facet_connectivity":
            continue
        left, right = cert.carrier
        bridge_actions, _meta = bridge_api.certificate_bridge_actions(
            successor, (frozenset(left), frozenset(right))
        )
        for legacy in bridge_actions:
            additions = tuple(sorted(tuple(p) for p in legacy["additions"]))
            additions_to_ids.setdefault(additions, set()).add(cert.snapshot_id)
    return after_components, after_certificates, {
        additions: tuple(sorted(ids)) for additions, ids in additions_to_ids.items()
    }


def _targeted_fake_action(target, support_ids):
    if not support_ids:
        return None
    return CanonicalAction(
        action_id="targeted-n2-successor",
        additions=target.additions,
        roles=("N2",),
        certificate_snapshot_ids=tuple(support_ids),
        certificate_obligation_ids=tuple(),
        witnesses=tuple(),
        edit_region=target.edit_region,
        local_affected_region=target.local_affected_region,
    )

def _audit_direction_set(state, targets, actors, api, bridge_api, label, trace_rescue=False):
    before_tuple = extract_certificates(state, api)
    before_dict = {c.snapshot_id: c for c in before_tuple}
    successor_index_cache = {}
    quotient_cache = {}
    totals = Counter()
    profile_hist = Counter()
    descendant_structure_hist = Counter()
    ancestry_hist = Counter()
    d6_hist = Counter()
    multiplicity_hist = Counter()
    old_support_hist = Counter()
    stable_support_hist = Counter()
    local_hist = Counter()
    rescue_profile_hist = Counter()
    representative = {
        "single_merged": [],
        "multi_independent": [],
        "multi_mixed": [],
        "independent_r2": [],
        "no_stable_survivor": [],
    }

    for target in targets:
        for actor in actors:
            if actor.action_id == target.action_id or set(actor.additions) & set(target.additions):
                continue
            totals["direction_count"] += 1
            cached = successor_index_cache.get(actor.action_id)
            if cached is None:
                cached = _targeted_n2_successor_index(state, actor, api, bridge_api)
                successor_index_cache[actor.action_id] = cached
            ac, aft, n2_index = cached
            support_ids = n2_index.get(target.additions, tuple())
            surviving = _targeted_fake_action(target, support_ids)
            aa = {} if surviving is None else {target.additions: surviving}
            afd = {c.snapshot_id: c for c in aft}
            ds = directed_stability(
                state, actor, target, api,
                successor_actions=aa,
                source_certificates=before_dict,
                after_components=ac,
                after_certificates=afd,
            )
            stable_count = sum(w.distance_stable for w in ds.witnesses)
            local = is_locally_separated(actor, target)
            local_hist[(local, stable_count, ds.target_literal_survives)] += 1
            if ds.target_literal_survives and stable_count == 0:
                totals["converse_counterexample_count"] += 1
            if local and stable_count > 0 and not ds.target_literal_survives:
                totals["local_sufficient_violation_count"] += 1
            if not ds.target_literal_survives:
                continue

            totals["survivor_count"] += 1
            q = quotient_cache.get(actor.action_id)
            if q is None:
                q = assert_frozen_n2_bridge_quotient(state, actor, api)
                quotient_cache[actor.action_id] = q
            profile = classify_target_descendants(
                target=target,
                directed_stability=ds,
                after_actions=aa,
                after_certificates=aft,
                quotient=q,
                api=api,
                state=state,
                actor=actor,
            )
            profile_hist[_profile_key(profile)] += 1
            if trace_rescue:
                tr = trace_provenance(
                    state, actor, target, api, bridge_api,
                    state_label=label, before_certificates=before_tuple,
                    after_actions=aa, after_certificates=aft,
                ).record()
                rescue_profile_hist[(tuple(tr["rescue_classes"]), _profile_key(profile))] += 1
            descendant_structure_hist[profile.descendant_structure] += 1
            ancestry_hist[profile.ancestry_type] += 1
            d6_hist[profile.d6_stability_type] += 1
            multiplicity_hist[profile.target_descendant_multiplicity] += 1
            old_support_hist[profile.old_target_support_count] += 1
            stable_support_hist[profile.stable_old_target_support_count] += 1

            if profile.unstable_target_r1_branch_present:
                totals["unstable_target_r1_survivor_count"] += 1
            if profile.stable_target_descendant_present:
                totals["stable_target_descendant_survivor_count"] += 1
            if profile.independent_r2_branch_present:
                totals["independent_r2_survivor_count"] += 1
            if profile.target_local_merge_present:
                totals["target_local_merge_survivor_count"] += 1
            if profile.doubled_independent_realization:
                totals["doubled_independent_survivor_count"] += 1

            necessity = necessity_dichotomy(profile)
            if necessity["predicate_no_stable_old_target"]:
                totals["necessity_predicate_survivor_count"] += 1
                if not necessity["required_branch_satisfied"]:
                    totals["necessity_branch_violation_count"] += 1

            bucket = None
            if profile.descendant_structure == "SINGLE_MERGED":
                bucket = "single_merged"
            elif profile.descendant_structure == "MULTI_INDEPENDENT":
                bucket = "multi_independent"
            elif profile.descendant_structure == "MULTI_MIXED":
                bucket = "multi_mixed"
            if profile.independent_r2_branch_present:
                bucket = "independent_r2"
            if profile.d6_stability_type == "NONE_STABLE":
                bucket = "no_stable_survivor"
            if bucket and len(representative[bucket]) < 8:
                representative[bucket].append({
                    "actor_additions": actor.additions,
                    "target_additions": target.additions,
                    "profile": profile.record(),
                })

    for key in (
        "converse_counterexample_count",
        "local_sufficient_violation_count",
        "r0_implies_stable_violation_count",
        "r3_survivor_count",
        "unstable_target_r1_survivor_count",
        "stable_target_descendant_survivor_count",
        "independent_r2_survivor_count",
        "target_local_merge_survivor_count",
        "doubled_independent_survivor_count",
        "necessity_predicate_survivor_count",
        "necessity_r0_exclusion_violation_count",
        "necessity_r3_exclusion_violation_count",
        "necessity_branch_violation_count",
    ):
        totals.setdefault(key, 0)

    return {
        "totals": dict(totals),
        "three_axis_histogram": dict(sorted(profile_hist.items())),
        "descendant_structure_histogram": dict(sorted(descendant_structure_hist.items())),
        "ancestry_type_histogram": dict(sorted(ancestry_hist.items())),
        "d6_stability_histogram": dict(sorted(d6_hist.items())),
        "target_descendant_multiplicity_histogram": dict(sorted(multiplicity_hist.items())),
        "old_target_support_count_histogram": dict(sorted(old_support_hist.items())),
        "stable_old_target_support_count_histogram": dict(sorted(stable_support_hist.items())),
        "rescue_x_three_axis_histogram": {
            f"rescue={'+'.join(rescue)}|{profile_key}": count
            for (rescue, profile_key), count in sorted(rescue_profile_hist.items(), key=lambda kv: (kv[0][0], kv[0][1]))
        },
        "local_direction_histogram": {
            f"local={local},stable={stable},survives={surv}": count
            for (local, stable, surv), count in sorted(local_hist.items())
        },
        "representatives": representative,
    }


def audit_broad(initial_states, api, bridge_api):
    aggregate = Counter()
    hist = Counter()
    desc_hist = Counter()
    ancestry_hist = Counter()
    d6_hist = Counter()
    mult_hist = Counter()
    state_rows = []
    representatives = {k: [] for k in (
        "single_merged", "multi_independent", "multi_mixed", "independent_r2", "no_stable_survivor"
    )}

    for index in DISTRIBUTED_INDICES:
        initial = initial_states[index]
        first = api.atomic_actions(initial)[0]
        state = initial | {tuple(p) for p in first["additions"]}
        actions = canonical_actions(state, api)
        selected = evenly_spaced(actions, EXPANSION_SAMPLE_SIZE)
        n2_actions = tuple(a for a in selected if "N2" in a.roles)
        result = _audit_direction_set(
            state, n2_actions, n2_actions, api, bridge_api,
            f"02C1_broad_first_successor_{index:03d}",
        )
        aggregate.update(result["totals"])
        hist.update(result["three_axis_histogram"])
        desc_hist.update(result["descendant_structure_histogram"])
        ancestry_hist.update(result["ancestry_type_histogram"])
        d6_hist.update(result["d6_stability_histogram"])
        mult_hist.update({int(k): v for k, v in result["target_descendant_multiplicity_histogram"].items()})
        for key, rows in result["representatives"].items():
            for row in rows:
                if len(representatives[key]) < 8:
                    representatives[key].append({"state_index": index, **row})
        state_rows.append({
            "state_index": index,
            "selected_n2_action_count": len(n2_actions),
            "direction_count": result["totals"]["direction_count"],
            "survivor_count": result["totals"]["survivor_count"],
        })
        print(f"[02C3 broad] state={index} directions={result['totals']['direction_count']} survivors={result['totals']['survivor_count']}", flush=True)

    return {
        "state_rows": state_rows,
        "totals": dict(aggregate),
        "three_axis_histogram": dict(sorted(hist.items())),
        "descendant_structure_histogram": dict(sorted(desc_hist.items())),
        "ancestry_type_histogram": dict(sorted(ancestry_hist.items())),
        "d6_stability_histogram": dict(sorted(d6_hist.items())),
        "target_descendant_multiplicity_histogram": dict(sorted(mult_hist.items())),
        "representatives": representatives,
    }


def audit_multi(initial_states, api, bridge_api, state_indices):
    aggregate = Counter()
    hist = Counter()
    desc_hist = Counter()
    ancestry_hist = Counter()
    d6_hist = Counter()
    mult_hist = Counter()
    state_rows = []
    representatives = {k: [] for k in (
        "single_merged", "multi_independent", "multi_mixed", "independent_r2", "no_stable_survivor"
    )}

    for index in state_indices:
        initial = initial_states[index]
        first = api.atomic_actions(initial)[0]
        state = initial | {tuple(p) for p in first["additions"]}
        before = extract_certificates(state, api)
        before_n2_ids = {c.snapshot_id for c in before if c.predicate == "N2_facet_connectivity"}
        actions = canonical_actions(state, api, before)
        targets = tuple(
            action for action in actions
            if "N2" in action.roles
            and sum(sid in before_n2_ids for sid in action.certificate_snapshot_ids) > 1
        )
        result = _audit_direction_set(
            state, targets, actions, api, bridge_api,
            f"02C2_multi_first_successor_{index:03d}",
        )
        aggregate.update(result["totals"])
        hist.update(result["three_axis_histogram"])
        desc_hist.update(result["descendant_structure_histogram"])
        ancestry_hist.update(result["ancestry_type_histogram"])
        d6_hist.update(result["d6_stability_histogram"])
        mult_hist.update({int(k): v for k, v in result["target_descendant_multiplicity_histogram"].items()})
        for key, rows in result["representatives"].items():
            for row in rows:
                if len(representatives[key]) < 8:
                    representatives[key].append({"state_index": index, **row})
        state_rows.append({
            "state_index": index,
            "target_count": len(targets),
            "action_count": len(actions),
            "direction_count": result["totals"]["direction_count"],
            "survivor_count": result["totals"]["survivor_count"],
        })
        print(f"[02C3 multi] state={index} targets={len(targets)} directions={result['totals']['direction_count']} survivors={result['totals']['survivor_count']}", flush=True)

    return {
        "state_rows": state_rows,
        "totals": dict(aggregate),
        "three_axis_histogram": dict(sorted(hist.items())),
        "descendant_structure_histogram": dict(sorted(desc_hist.items())),
        "ancestry_type_histogram": dict(sorted(ancestry_hist.items())),
        "d6_stability_histogram": dict(sorted(d6_hist.items())),
        "target_descendant_multiplicity_histogram": dict(sorted(mult_hist.items())),
        "representatives": representatives,
    }



def _aggregate_worker_results(rows):
    aggregate = Counter()
    hist = Counter(); desc_hist = Counter(); ancestry_hist = Counter(); d6_hist = Counter(); mult_hist = Counter(); rescue_cross = Counter()
    state_rows=[]
    representatives={k:[] for k in ("single_merged","multi_independent","multi_mixed","independent_r2","no_stable_survivor")}
    for result in rows:
        aggregate.update(result["totals"])
        hist.update(result["three_axis_histogram"])
        desc_hist.update(result["descendant_structure_histogram"])
        ancestry_hist.update(result["ancestry_type_histogram"])
        d6_hist.update(result["d6_stability_histogram"])
        mult_hist.update({int(k):v for k,v in result["target_descendant_multiplicity_histogram"].items()})
        rescue_cross.update(result.get("rescue_x_three_axis_histogram", {}))
        meta=dict(result["state_meta"])
        meta["direction_count"]=result["totals"]["direction_count"]
        meta["survivor_count"]=result["totals"]["survivor_count"]
        state_rows.append(meta)
        idx=meta["state_index"]
        for key, items in result["representatives"].items():
            for item in items:
                if len(representatives[key])<8:
                    representatives[key].append({"state_index":idx, **item})
    state_rows.sort(key=lambda r:r["state_index"])
    return {
        "state_rows":state_rows,
        "totals":dict(aggregate),
        "three_axis_histogram":dict(sorted(hist.items())),
        "descendant_structure_histogram":dict(sorted(desc_hist.items())),
        "ancestry_type_histogram":dict(sorted(ancestry_hist.items())),
        "d6_stability_histogram":dict(sorted(d6_hist.items())),
        "target_descendant_multiplicity_histogram":dict(sorted(mult_hist.items())),
        "rescue_x_three_axis_histogram":dict(sorted(rescue_cross.items())),
        "representatives":representatives,
    }


def _run_isolated_workers(domain, indices, temp_root):
    import subprocess, sys
    from concurrent.futures import ThreadPoolExecutor, as_completed
    worker = HERE / "run_s2comp02c3_state_worker.py"

    def run_one(index):
        out=temp_root / f"{domain}_{index:03d}.json"
        cp=subprocess.run(
            [sys.executable, str(worker), "--domain", domain, "--state-index", str(index), "--out", str(out)],
            cwd=HERE, text=True, capture_output=True,
        )
        if cp.returncode != 0:
            raise RuntimeError(f"02C3 worker failed domain={domain} state={index}\nSTDOUT:\n{cp.stdout}\nSTDERR:\n{cp.stderr}")
        return index, cp.stdout.strip().splitlines()[-1] if cp.stdout.strip() else "", json.loads(out.read_text())

    completed=[]
    # Workers are mathematically independent; bounded parallelism removes the
    # legacy generator's cumulative-cache runtime pathology while preserving
    # deterministic per-state JSON and deterministic final aggregation order.
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures={pool.submit(run_one,index):index for index in indices}
        for fut in as_completed(futures):
            completed.append(fut.result())
    completed.sort(key=lambda row:row[0])
    for _index,line,_result in completed:
        print(f"[02C3 isolated] {line}", flush=True)
    return _aggregate_worker_results([row[2] for row in completed])


def main():
    failures=[]
    frozen_c2=json.loads((HERE/"s2comp02c2_audit_results.json").read_text())
    frozen_discovery=frozen_c2["multi_provenance_discovery"]
    discovery={
        "multi_provenance_action_count":frozen_discovery["multi_provenance_action_count"],
        "multi_state_indices":frozen_discovery["multi_state_indices"],
    }
    import subprocess, sys
    gate_cp=subprocess.run([sys.executable, str(HERE/"run_s2comp02c3_targeted_support_gate.py")], cwd=HERE, text=True, capture_output=True)
    if gate_cp.returncode != 0:
        raise RuntimeError(f"targeted support regression gate failed\nSTDOUT:\n{gate_cp.stdout}\nSTDERR:\n{gate_cp.stderr}")
    support_gate=json.loads((HERE/"s2comp02c3_targeted_support_gate_results.json").read_text())
    if support_gate.get("direction_count") != 128 or support_gate.get("mismatch_count") != 0:
        failures.append({"gate":"targeted_support_equivalence","observed":support_gate})
    with tempfile.TemporaryDirectory(prefix="s2comp02c3_workers_") as td:
        td=Path(td)
        broad=_run_isolated_workers("broad", DISTRIBUTED_INDICES, td)
        multi=_run_isolated_workers("multi", discovery["multi_state_indices"], td)

    expected_broad={"direction_count":11156,"survivor_count":3860,"converse_counterexample_count":0,"local_sufficient_violation_count":0}
    for key,value in expected_broad.items():
        if broad["totals"].get(key,0)!=value:
            failures.append({"gate":f"broad_{key}","expected":value,"observed":broad["totals"].get(key,0)})
    expected_multi={"direction_count":2575,"survivor_count":809,"converse_counterexample_count":0,"local_sufficient_violation_count":0}
    for key,value in expected_multi.items():
        if multi["totals"].get(key,0)!=value:
            failures.append({"gate":f"multi_{key}","expected":value,"observed":multi["totals"].get(key,0)})
    for domain_name,domain in (("broad",broad),("multi",multi)):
        if domain["totals"].get("necessity_branch_violation_count",0)!=0:
            failures.append({"gate":f"{domain_name}_necessity_branch_violation_count","observed":domain["totals"].get("necessity_branch_violation_count",0)})
        if domain["totals"].get("independent_r2_survivor_count",0)!=0:
            failures.append({"gate":f"{domain_name}_independent_r2_bounded_zero","observed":domain["totals"].get("independent_r2_survivor_count",0)})

    result={
        "checkpoint":"S2-COMP-02C3 Target-Descendant Necessity Boundary",
        "scope":{
            "broad_domain":"exact 02C1 six-state 64-action deterministic broad domain",
            "multi_domain":"exact 02C2 all-disjoint-actor domain for all 26 multi-provenance targets in 10 discovered states",
            "proved_here":[
                "R0 exact-realization survival implies stable old target d6 for that provenance",
                "using frozen 02C2 R3 exclusion: a surviving N2 target with no stable old target provenance must use changed-realization R1 or independent R2",
            ],
            "bounded_evidence_only":[
                "zero observed no-stable survivor in both audited domains",
                "zero observed independent R2 in both audited domains",
                "three-axis empirical distribution of surviving targets",
            ],
            "not_proved_here":[
                "universal converse survival=>exists stable old target provenance",
                "universal impossibility of independent R2",
                "sufficiency or necessity of target-local merge or doubled-independent multiplicity by itself",
            ],
            "predecessors_modified":[],
        },
        "multi_provenance_discovery_regression":discovery,
        "targeted_support_regression_gate":support_gate,
        "broad_domain":broad,
        "multi_provenance_domain":multi,
        "failure_count":len(failures),
        "failures":failures,
    }
    out=HERE/"s2comp02c3_audit_results.json"
    out.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
    print(json.dumps({
        "broad_direction_count":broad["totals"].get("direction_count",0),
        "broad_survivor_count":broad["totals"].get("survivor_count",0),
        "broad_no_stable_survivor_count":broad["totals"].get("necessity_predicate_survivor_count",0),
        "multi_direction_count":multi["totals"].get("direction_count",0),
        "multi_survivor_count":multi["totals"].get("survivor_count",0),
        "multi_no_stable_survivor_count":multi["totals"].get("necessity_predicate_survivor_count",0),
        "multi_target_local_merge_survivors":multi["totals"].get("target_local_merge_survivor_count",0),
        "multi_doubled_independent_survivors":multi["totals"].get("doubled_independent_survivor_count",0),
        "failure_count":len(failures),
    },indent=2,sort_keys=True))
    if failures:
        raise SystemExit(1)


if __name__=="__main__":
    main()
