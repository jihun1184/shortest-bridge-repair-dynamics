"""S2-COMP-02C0: generator-level provenance/realization tracing and R0-R3 classifier.

This module adds a new observation layer on top of the FROZEN predecessors
(s2comp01b_interface.py, s2comp02b_distance.py) and the frozen C07-D7C
generator package.  No predecessor file is modified.

Motivation (resolves design question #7 from the 02C design review):

    canonical_actions() / api.atomic_actions() deduplicate by addition set and
    only retain a *count* of supporting realizations per certificate
    (witness["realization_count"]).  The actual (endpoint pair, monotone
    path) realizations are computed by certificate_bridge_actions() in the
    frozen c07d4 module but are DISCARDED before they reach atomic_actions().

    Therefore canonical_actions()/atomic_actions() alone are NOT sufficient
    to distinguish R0 (same old endpoint/path realization persists) from R1
    (same old certificate descendant, but only via a different realization).
    This module calls certificate_bridge_actions() directly -- unmodified,
    frozen -- to recover realization identity.

R0-R3 rescue classes (as agreed in the 02C design review), NOT assumed
mutually exclusive at the raw level; `rescue_classes` records every class
that applies, `primary_rescue_class` is a deterministic post-hoc pick
(R0 > R1 > R2 > R3 in strength order) for tabulation only.

    R0: some old N2 certificate c in Prov_before(b) has a distinct-component
        descendant in the after-state, and that descendant's
        certificate_bridge_actions() reproduce b via a realization
        (s, t, path) that is IDENTICAL to one that existed for c before a.
    R1: same as R0's descendant condition, but b is only reproduced by a
        realization (s, t, path) that did NOT exist for c before a.
    R2: a *different* old N2 certificate c' != c (c' also present in the
        before-state's full N2 certificate set) has a distinct-component
        descendant in the after-state whose certificate_bridge_actions()
        reproduce b -- regardless of whether c' was originally in
        Prov_before(b).  (The design note's "pre-existing old supporting
        certificate" is ambiguous between "supported b before" and "existed
        before"; this implementation checks the broader "existed before"
        condition and separately records whether c' was itself in
        Prov_before(b), so both readings are inspectable from the raw
        record.)
    R3: some after-state N2 certificate whose snapshot_id is NOT the
        descendant of ANY before-state N2 certificate (i.e. it is in
        TransitionEffect.created_snapshot_ids) reproduces b.

If none of R0-R3 hold for a literal-surviving b, that is itself a reportable
anomaly (should not occur if canonical_actions()'s own certificate bookkeeping
is complete; see gate G7 in run_s2comp02c0_audit.py).
"""

from __future__ import annotations

import hashlib
import importlib
import json
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

from s2comp01b_interface import (
    Certificate,
    CanonicalAction,
    LegacyAPI,
    canonical_actions,
    extract_certificates,
    transition_effect,
)

Point = tuple[int, int, int]


def _stable(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _stable(value[key]) for key in sorted(value)}
    if isinstance(value, (set, frozenset)):
        return tuple(sorted(_stable(item) for item in value))
    if isinstance(value, (tuple, list)):
        return tuple(_stable(item) for item in value)
    return value


def _identifier(prefix: str, value: Any) -> str:
    payload = json.dumps(_stable(value), sort_keys=True, separators=(",", ":"))
    return f"{prefix}-{hashlib.sha256(payload.encode()).hexdigest()[:16]}"


@dataclass(frozen=True)
class BridgeAPI:
    """Direct, frozen, unmodified access to certificate_bridge_actions().

    01B's LegacyAPI does not expose this frozen function; it is loaded
    separately here from the same source root, without editing 01B.
    """

    certificate_bridge_actions: Any


def load_bridge_api(source_root: str | Path) -> BridgeAPI:
    root = Path(source_root).resolve()
    path = root / "work" / "c07d4"
    if not path.is_dir():
        raise FileNotFoundError(f"not a C07-D7C package root; missing: {path}")
    value = str(path)
    if value not in sys.path:
        sys.path.insert(0, value)
    module = importlib.import_module("c07d4_planning_census")
    return BridgeAPI(certificate_bridge_actions=module.certificate_bridge_actions)


def _realization_key(realization: dict[str, Any]) -> tuple[Any, ...]:
    """Canonical identity for a (endpoint pair, monotone path) realization.

    Path order from gen_all_monotone_paths is deterministic for a given
    (s, t), but we sort the path's point set for identity so that two
    realizations naming the same voxel path are recognised as equal even if
    a future traversal-order change altered listing order (the frozen
    generator's own stable_bridge_audit already strips such order-only
    differences for endpoint pairs; we apply the same discipline here for
    full realizations, which the generator itself does not stabilize).
    """
    s = tuple(realization["s"])
    t = tuple(realization["t"])
    path = tuple(sorted(tuple(p) for p in realization["path"]))
    return (s, t, path)


import functools


@functools.lru_cache(maxsize=None)
def _bridge_action_index_cached(
    bridge_api: BridgeAPI,
    state: frozenset,
    left: tuple[Point, ...],
    right: tuple[Point, ...],
) -> tuple[tuple[frozenset, tuple[dict[str, Any], ...]], ...]:
    """Cache certificate_bridge_actions() per (bridge_api, state, carrier).

    Same state + same certificate carrier is queried repeatedly across many
    (actor, target) pairs sharing a state; this avoids recomputing the full
    bridge-action enumeration for every pair.  Returned as a hashable tuple
    of (frozenset(additions), realizations) entries; converted to a dict by
    the caller.
    """
    actions, _meta = bridge_api.certificate_bridge_actions(state, (frozenset(left), frozenset(right)))
    return tuple((frozenset(a["additions"]), tuple(a["realizations"])) for a in actions)


def _bridge_realizations_for_additions(
    bridge_api: BridgeAPI,
    state: frozenset[Point],
    carrier: tuple[Any, Any],
    additions: tuple[Point, ...],
) -> tuple[dict[str, Any], ...] | None:
    """Return the realizations list for `additions` under this certificate's
    bridge actions, or None if this certificate does not generate `additions`
    at all (i.e. it is not a supporting certificate for that literal action).
    """
    left, right = carrier
    index = _bridge_action_index_cached(bridge_api, state, tuple(sorted(left)), tuple(sorted(right)))
    target = frozenset(additions)
    for key, realizations in index:
        if key == target:
            return realizations
    return None


@dataclass(frozen=True)
class OldProvenanceTrace:
    certificate_snapshot_id: str
    supported_target_before: bool
    before_realization_keys: tuple[tuple[Any, ...], ...]
    descendant_exists: bool
    descendant_snapshot_id: str | None
    descendant_reproduces_target: bool
    after_realization_keys: tuple[tuple[Any, ...], ...]
    matching_realization_keys: tuple[tuple[Any, ...], ...]
    rescue_R0: bool
    rescue_R1: bool

    def record(self) -> dict[str, Any]:
        return _stable(asdict(self))


@dataclass(frozen=True)
class ProvenanceTrace:
    occurrence_id: str
    state_label: str
    actor_action_id: str
    target_action_id: str
    actor_additions: tuple[Point, ...]
    target_additions: tuple[Point, ...]
    target_literal_survives: bool
    before_n2_certificate_count: int
    before_provenance_count_for_target: int
    old_provenance_traces: tuple[OldProvenanceTrace, ...]
    r3_certificate_snapshot_ids: tuple[str, ...]
    rescue_classes: tuple[str, ...]
    primary_rescue_class: str | None
    anomaly_survives_with_no_rescue_class: bool

    def record(self) -> dict[str, Any]:
        value = _stable(asdict(self))
        value["old_provenance_traces"] = tuple(t.record() for t in self.old_provenance_traces)
        return value


_PRIORITY = ("R0", "R1", "R2", "R3")


def trace_provenance(
    state: Iterable[Point],
    actor: CanonicalAction,
    target: CanonicalAction,
    api: LegacyAPI,
    bridge_api: BridgeAPI,
    *,
    state_label: str = "",
    before_certificates: tuple[Certificate, ...] | None = None,
    after_actions: dict[tuple[Point, ...], CanonicalAction] | None = None,
    after_certificates: tuple[Certificate, ...] | None = None,
) -> ProvenanceTrace:
    """Trace how (or whether) `target`'s addition set is regenerated after `actor`.

    Reuses frozen transition_effect() for the before/after certificate
    persistence partition; adds realization-level R0/R1 discrimination via
    the frozen (but previously unexposed at this layer)
    certificate_bridge_actions().
    """
    state = frozenset(tuple(p) for p in state)
    if set(actor.additions) & set(target.additions):
        raise ValueError("provenance trace requires disjoint actor/target edits")
    if "N2" not in target.roles:
        raise ValueError("target must have N2 role for provenance tracing")

    before_certificates = before_certificates or extract_certificates(state, api)
    before_n2 = tuple(c for c in before_certificates if c.predicate == "N2_facet_connectivity")
    before_n2_ids = {c.snapshot_id for c in before_n2}

    effect = transition_effect(state, actor, api)
    persisted_by_before_id = {link.before_snapshot_id: link for link in effect.persisted if link.predicate == "N2_facet_connectivity"}
    created_ids = set(effect.created_snapshot_ids)

    successor = state | set(actor.additions)
    if after_actions is None:
        after_actions = {item.additions: item for item in canonical_actions(successor, api)}
    if after_certificates is None:
        after_certificates = extract_certificates(successor, api)
    after_certificates_by_id = {c.snapshot_id: c for c in after_certificates}
    surviving = after_actions.get(target.additions)
    literal_survives = surviving is not None
    surviving_n2_ids = set(surviving.certificate_snapshot_ids) if surviving is not None else set()

    old_traces: list[OldProvenanceTrace] = []
    for cert in before_n2:
        before_realizations = _bridge_realizations_for_additions(
            bridge_api, state, cert.carrier, target.additions
        )
        supported_before = before_realizations is not None
        before_keys = tuple(sorted(_realization_key(r) for r in (before_realizations or ())))

        link = persisted_by_before_id.get(cert.snapshot_id)
        descendant_exists = link is not None
        descendant_id = link.after_snapshot_id if link is not None else None

        after_keys: tuple[tuple[Any, ...], ...] = ()
        descendant_reproduces = False
        if descendant_exists:
            after_cert = after_certificates_by_id.get(descendant_id)
            if after_cert is None:
                raise AssertionError(f"descendant snapshot_id not found in after-state: {descendant_id}")
            after_realizations = _bridge_realizations_for_additions(
                bridge_api, successor, after_cert.carrier, target.additions
            )
            descendant_reproduces = after_realizations is not None
            after_keys = tuple(sorted(_realization_key(r) for r in (after_realizations or ())))

        matching = tuple(k for k in after_keys if k in set(before_keys))
        rescue_r0 = descendant_reproduces and len(matching) > 0
        rescue_r1 = descendant_reproduces and len(matching) == 0

        old_traces.append(
            OldProvenanceTrace(
                certificate_snapshot_id=cert.snapshot_id,
                supported_target_before=supported_before,
                before_realization_keys=before_keys,
                descendant_exists=descendant_exists,
                descendant_snapshot_id=descendant_id,
                descendant_reproduces_target=descendant_reproduces,
                after_realization_keys=after_keys,
                matching_realization_keys=matching,
                rescue_R0=rescue_r0,
                rescue_R1=rescue_r1,
            )
        )

    # R2: any old-N2-certificate's descendant (other than the ones already
    # marked R0/R1 above by construction, since we scanned ALL before_n2
    # certs, not just Prov_before(b)) that reproduces target is *already*
    # captured in old_traces with rescue_R0/rescue_R1 True for that cert.
    # R2 as its own bucket is reserved for descendants that reproduce target
    # via a certificate that did NOT itself support target before (i.e.
    # supported_target_before is False but descendant_reproduces_target is
    # True) -- a genuine "rescued by a different pre-existing certificate".
    r2_traces = [t for t in old_traces if (not t.supported_target_before) and t.descendant_reproduces_target]

    # R3: surviving certificates with no before-state ancestor at all.
    r3_ids = tuple(sorted(surviving_n2_ids & created_ids))

    rescue_classes: list[str] = []
    if any(t.rescue_R0 for t in old_traces):
        rescue_classes.append("R0")
    if any(t.rescue_R1 for t in old_traces):
        rescue_classes.append("R1")
    if r2_traces:
        rescue_classes.append("R2")
    if r3_ids:
        rescue_classes.append("R3")

    primary = next((cls for cls in _PRIORITY if cls in rescue_classes), None)
    anomaly = literal_survives and primary is None

    occurrence_id = _identifier(
        "occ2c", (state_label, tuple(sorted(state)), actor.additions, target.additions)
    )

    return ProvenanceTrace(
        occurrence_id=occurrence_id,
        state_label=state_label,
        actor_action_id=actor.action_id,
        target_action_id=target.action_id,
        actor_additions=actor.additions,
        target_additions=target.additions,
        target_literal_survives=literal_survives,
        before_n2_certificate_count=len(before_n2),
        before_provenance_count_for_target=sum(t.supported_target_before for t in old_traces),
        old_provenance_traces=tuple(old_traces),
        r3_certificate_snapshot_ids=r3_ids,
        rescue_classes=tuple(rescue_classes),
        primary_rescue_class=primary,
        anomaly_survives_with_no_rescue_class=anomaly,
    )
