첨부한 `S2_COMP_02C4_RESCUE_EXISTENCE_BOUNDARY_20260830.zip`을 먼저 실제로 풀고
`SHA256SUMS.txt`, embedded 02C3 predecessor의 byte identity, 그리고 stored/fresh
search 결과를 검증한 뒤 연구를 이어가 주세요. 이전 대화 기억보다 이 번들의
frozen code/results를 source of truth로 우선하세요.

현재 닫힌 범위:

- 02C3 packaged/reproducible checkpoint는 immutable predecessor.
- 02C4에서 independent R2의 **유한 존재 명제**는 explicit witness로 CLOSED.
- exact-confirmed independent-R2 witnesses: 35 (D7B alternate 29 + state-10 depth2 6).
- 35/35 모두 stable old target provenance를 동시에 가짐.
- 따라서 independent R2는 realizable하지만 R2-only/no-stable rescue는 아직 미관측.
- unstable-target R1도 세 expanded audit domain에서 아직 0.

새 domain 정의는 반드시 코드의 결정론적 규칙을 그대로 사용하세요:

1. D7B alternate: tested source indices 0..29, frozen `atomic_actions(initial)`의
   lexicographic index 1.
2. D6B3: frozen D6B2/D6B3 코드로 17 admitted states를 재생성한 뒤 각 state의
   두 lexicographic initial branches 전부.
3. D7B state 10 alternate depth-2: alternate depth-1 state의 N2-role
   `canonical_actions` 225개를 lexicographic additions 순서로 각각 한 번 적용.

`cell_status_registry.json`은 append-only입니다. 기존 entry를 재작성하지 말고
새 관측 또는 theorem status만 history에 append하세요.

다음 연구 우선순위:

- unstable-target R1 실제 존재 domain 탐색;
- independent R2이면서 stable old target provenance가 하나도 없는 R2-only/no-stable
  사례 탐색;
- 둘 중 하나가 발견된 뒤에만 sufficiency 조건을 연구;
- 계속 0이면 zero-count를 theorem으로 올리지 말고 별도 structural impossibility
  lemma를 시도.
