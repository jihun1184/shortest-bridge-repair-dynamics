"""S2-COMP-02C2: exact N2 certificate quotient under addition-only bridge actions.

Frozen N2 certificates are *all* unordered pairs of distinct 6-components.
For an addition-only transition X -> X^a, every old component has a unique
component descendant.  This module records the induced quotient on component
pairs and checks the exact fiber formula

    multiplicity({D_r,D_s}) = |q^{-1}(D_r)| * |q^{-1}(D_s)|.

For frozen N2 bridge actions, every after-component contains an old component.
Consequently no after N2 certificate is genuinely created.  If the transition
strictly reduces component count while leaving at least two after-components,
the N2 certificate persistence relation is necessarily non-injective.
"""
from __future__ import annotations

import itertools
from collections import Counter
from dataclasses import asdict, dataclass
from typing import Any, Iterable

Point = tuple[int, int, int]


def _points(points: Iterable[Point]) -> tuple[Point, ...]:
    return tuple(sorted(tuple(p) for p in points))


def _pair(i: int, j: int) -> tuple[int, int]:
    return (i, j) if i < j else (j, i)


@dataclass(frozen=True)
class N2Quotient:
    before_component_count: int
    after_component_count: int
    before_certificate_count: int
    after_certificate_count: int
    old_component_to_after_index: tuple[int, ...]
    fiber_sizes: tuple[int, ...]
    resolved_old_certificate_count: int
    persisted_old_certificate_count: int
    after_pair_ancestor_multiplicities: tuple[tuple[tuple[int, int], int], ...]
    expected_after_pair_multiplicities: tuple[tuple[tuple[int, int], int], ...]
    after_pairs_without_old_ancestor: tuple[tuple[int, int], ...]
    after_components_without_old_ancestor: tuple[int, ...]
    persistence_noninjective: bool
    exact_fiber_formula_holds: bool

    def record(self) -> dict[str, Any]:
        return asdict(self)


def n2_certificate_quotient(state: Iterable[Point], additions: Iterable[Point], api) -> N2Quotient:
    """Compute the induced quotient on complete component-pair N2 certificates."""
    state = frozenset(tuple(p) for p in state)
    additions = frozenset(tuple(p) for p in additions)
    if not additions:
        raise ValueError("additions must be nonempty")
    if state & additions:
        raise ValueError("additions must be disjoint from state")

    successor = state | additions
    before = tuple(api.components6(state))
    after = tuple(api.components6(successor))

    after_index_by_key = {_points(component): idx for idx, component in enumerate(after)}
    q = []
    for old in before:
        descendant = api.descendant(frozenset(old), after)
        key = _points(descendant)
        if key not in after_index_by_key:
            raise AssertionError("old component descendant missing from after component list")
        q.append(after_index_by_key[key])
    q = tuple(q)

    fibers = [0] * len(after)
    for idx in q:
        fibers[idx] += 1
    fiber_sizes = tuple(fibers)
    after_components_without_old = tuple(i for i, size in enumerate(fiber_sizes) if size == 0)

    actual = Counter()
    resolved = 0
    for i, j in itertools.combinations(range(len(before)), 2):
        qi, qj = q[i], q[j]
        if qi == qj:
            resolved += 1
        else:
            actual[_pair(qi, qj)] += 1

    expected = {
        (r, s): fiber_sizes[r] * fiber_sizes[s]
        for r, s in itertools.combinations(range(len(after)), 2)
    }
    after_pairs_without_ancestor = tuple(sorted(set(expected) - set(actual)))
    exact = dict(actual) == expected

    return N2Quotient(
        before_component_count=len(before),
        after_component_count=len(after),
        before_certificate_count=len(before) * (len(before) - 1) // 2,
        after_certificate_count=len(after) * (len(after) - 1) // 2,
        old_component_to_after_index=q,
        fiber_sizes=fiber_sizes,
        resolved_old_certificate_count=resolved,
        persisted_old_certificate_count=sum(actual.values()),
        after_pair_ancestor_multiplicities=tuple(sorted(actual.items())),
        expected_after_pair_multiplicities=tuple(sorted(expected.items())),
        after_pairs_without_old_ancestor=after_pairs_without_ancestor,
        after_components_without_old_ancestor=after_components_without_old,
        persistence_noninjective=any(value > 1 for value in actual.values()),
        exact_fiber_formula_holds=exact,
    )


def assert_frozen_n2_bridge_quotient(state: Iterable[Point], action, api) -> N2Quotient:
    """Executable theorem gate for one canonical action with N2 role.

    The frozen bridge generator produces a connected path joining old
    components, so every after-component must contain an old component and
    component count must strictly decrease.  The complete pair-certificate
    quotient then gives exact surjectivity onto all after N2 certificates.
    """
    if "N2" not in action.roles:
        raise ValueError("the frozen N2 bridge quotient gate requires N2 role")
    q = n2_certificate_quotient(state, action.additions, api)
    if not q.exact_fiber_formula_holds:
        raise AssertionError("N2 certificate fiber formula failed")
    if q.after_components_without_old_ancestor:
        raise AssertionError(
            f"N2 bridge created after component(s) with no old ancestor: {q.after_components_without_old_ancestor}"
        )
    if q.after_pairs_without_old_ancestor:
        raise AssertionError(
            f"after N2 certificate(s) lack old ancestor: {q.after_pairs_without_old_ancestor}"
        )
    if not q.after_component_count < q.before_component_count:
        raise AssertionError(
            f"N2 bridge did not reduce component count: {q.before_component_count}->{q.after_component_count}"
        )
    # If an after N2 certificate exists, strict coarsening forces a pair-fiber
    # of size > 1, hence certificate merge is unavoidable.
    if q.after_component_count >= 2 and not q.persistence_noninjective:
        raise AssertionError(
            "strict component coarsening with >=2 after components must induce N2 certificate merge"
        )
    return q
