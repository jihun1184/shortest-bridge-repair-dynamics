# Claim boundary — S2-COMP-02C3

## PROVED in frozen N2 scope

1. The 02C2 exact quotient fiber formula and N2-R3 exclusion are inherited
   unchanged.
2. Exact R0 realization survival for an old target provenance implies stable
   `d6` for that provenance.
3. Therefore a surviving target with **no** stable old target provenance cannot
   use R0.
4. Combining (2) with R3 exclusion gives the 02C3 necessity dichotomy:

   `no-stable survivor => unstable-target R1 OR independent R2`.

5. Equivalently, every surviving frozen N2 target has at least one of:
   stable old target provenance, unstable-target R1, independent R2.

This theorem is source/provenance-level.  It does not say that any particular
target-descendant multiplicity class is necessary or sufficient.

## BOUNDED EXECUTABLE EVIDENCE

02C3 re-audits two frozen domains with the new three-axis classifier:

- exact 02C1 broad domain: 11,156 directed cases, 3,860 survivors;
- exact 02C2 multi-provenance domain: 2,575 directed cases, 809 survivors.

In both domains:

- no-stable surviving target: 0;
- unstable-target R1 branch: 0;
- independent R2 branch: 0;
- necessity-dichotomy violations: 0;
- local sufficient-criterion violations: 0.

These zero counts are evidence only.  They are not promoted to universal
impossibility theorems.

## Three-axis empirical decomposition

### Broad domain survivors (3,860)

- `TARGET_OLD_ONLY × SINGLE_UNMERGED × ALL_STABLE`: 2,174
- `TARGET_WITH_MERGED_NONTARGET × SINGLE_MERGED × ALL_STABLE`: 1,686

### Multi-provenance domain survivors (809)

- `R0 × TARGET_OLD_ONLY × MULTI_INDEPENDENT × ALL_STABLE`: 155
- `R0 × TARGET_OLD_ONLY × SINGLE_UNMERGED × SOME_STABLE`: 75
- `R0+R1+R2 × TARGET_WITH_MERGED_NONTARGET × MULTI_MIXED × ALL_STABLE`: 361
- `R0+R1+R2 × TARGET_WITH_MERGED_NONTARGET × SINGLE_MERGED × SOME_STABLE`: 218

The 75/155 split refines the immediate predecessor documentation: all 230
R0-only multi-domain survivors are target-local merge-free.  The 75 cases are
single-unmerged, not shared-target merges.

## OPEN

- universal converse `survival => exists stable old target provenance`;
- universal impossibility of unstable-target R1;
- universal impossibility of independent R2;
- sufficiency of either alternative rescue branch;
- a complete necessary-and-sufficient characterization of N2 action survival;
- any extension beyond the declared frozen C07 / addition-only / first-successor
  audit scopes.
