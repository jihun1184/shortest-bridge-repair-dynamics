첨부한 `S2_COMP_02C3_TARGET_DESCENDANT_NECESSITY_BOUNDARY_20260830.zip`을
먼저 실제로 풀고 `SHA256SUMS.txt`, embedded predecessor, 코드/raw JSON을 직접
검증한 뒤 연구를 이어가 주세요. 이전 대화 기억보다 이 번들을 source of
truth로 우선하세요.

현재 frozen 상태:

1. **02C2 immediate predecessor는 FREEZE V3**입니다.
   - V3는 documentation-only correction입니다.
   - V2의 핵심 correction(global merge != target-local merge)은 맞았습니다.
   - 추가로 75 R0-only case는 `SINGLE_UNMERGED`임이 정밀하게 확인되었습니다.
     하나의 old target support만 target-reproducing after certificate로 이어지고,
     다른 old target support의 descendant는 target을 재생성하지 않습니다.
   - 155 case는 `MULTI_INDEPENDENT` 그대로입니다.
   - 따라서 R0-only 230건 전부 target-local merge-free입니다.

2. **02C3 새 theorem — necessary rescue dichotomy**

   frozen N2 scope에서

   $$
   b\in A_{N2}(X\cup a),\qquad
   \forall c\in\operatorname{Prov}_{N2}^X(b):
   d_6(c^a)\neq d_6(c)
   $$

   이면 반드시

   $$
   R1_{\mathrm{unstable,target}}\ \lor\ R2_{\mathrm{independent}}
   $$

   입니다.

   이유:
   - exact R0 realization survival이면 d6가 stable이어야 하므로 premise 아래 R0 불가;
   - 02C2 quotient theorem으로 N2-R3 불가;
   - 따라서 surviving after target certificate가 old target ancestry를 가지면
     unstable-target R1, 가지지 않으면 independent R2입니다.

3. **3축 classifier**
   - ancestry type
   - `target_descendant_multiplicity` / descendant structure
   - old-target d6 stability

4. **02C1 exact broad domain 재검증**
   - 11,156 directions
   - 3,860 survivors
   - no-stable survivor 0
   - unstable-target R1 0
   - independent R2 0
   - local sufficient violation 0

5. **02C2 exact multi-provenance domain 재검증**
   - 2,575 directions
   - 809 survivors
   - no-stable survivor 0
   - unstable-target R1 0
   - independent R2 0
   - target-local merge survivor 579
   - doubled-independent survivor 155

   exact cross-table:
   - R0 × TARGET_OLD_ONLY × MULTI_INDEPENDENT × ALL_STABLE = 155
   - R0 × TARGET_OLD_ONLY × SINGLE_UNMERGED × SOME_STABLE = 75
   - R0+R1+R2 × TARGET_WITH_MERGED_NONTARGET × MULTI_MIXED × ALL_STABLE = 361
   - R0+R1+R2 × TARGET_WITH_MERGED_NONTARGET × SINGLE_MERGED × SOME_STABLE = 218

6. **claim boundary**
   - PROVED: necessary rescue dichotomy 위 명제
   - PROVED predecessor: exact quotient fiber formula, N2-R3 exclusion
   - BOUNDED ONLY: no-stable survivor=0, unstable-target R1=0, independent R2=0
   - OPEN: universal converse, unstable-target R1 universal impossibility,
     independent R2 universal impossibility, complete characterization

다음 단계는 S2-COMP-02C4로 잡고, 두 remaining branch를 따로 공격하는 것이
좋습니다:

- C4-A: `unstable-target R1`의 존재 가능성/불가능성 — d6가 변했는데 같은
  addition set이 descendant certificate에서 재생성될 수 있는지 generator-level
  조건을 분석;
- C4-B: `independent R2`의 존재 가능성/불가능성 — target-old ancestry가 전혀
  없는 after target certificate가 어떻게 동일 addition set을 생성할 수 있는지
  carrier/action identity 조건을 분석.

두 branch를 모두 universal하게 배제할 수 있으면 frozen scope의 converse가
즉시 닫힙니다. zero-count를 theorem으로 승격하지 말고 반드시 구조적 증명을
별도로 구성하세요.
