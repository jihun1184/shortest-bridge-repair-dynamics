# S2-COMP-02C3 Report — Target-Descendant Necessity Boundary

## 1. Objective

02C3 asks a sharper question than “can we find an independent R2?”:

> If a target N2 action survives even though **every** old target-supporting
> certificate changes `d6`, what source mechanism must regenerate it?

The answer is now proved at the frozen generator level: such a survivor must use
**unstable-target R1 or independent R2**.  R0 is incompatible with changed
`d6`, and R3 was already excluded by 02C2.

## 2. Immediate predecessor hygiene

The immediate predecessor is
`S2_COMP_02C2_N2_QUOTIENT_RESCUE_EXHAUSTION_FREEZE_V3_20260830.zip`.

V3 is a documentation-only refinement of V2.  It corrects one residual phrase
about the 75 R0-only one-descendant cases: those cases are `SINGLE_UNMERGED`,
not a shared target-local merge.  No 02C2 code, raw JSON, theorem, or stored
numeric result changed.

02C3 does not modify any frozen predecessor file.

## 3. New instrumentation

`s2comp02c3_target_descendants.py` combines only already-frozen interfaces:

- old target witness / descendant / `d6` information from
  `directed_stability()`;
- after N2 support IDs from the frozen bridge generator;
- exact after-certificate ancestor multiplicity from the 02C2 quotient fiber
  formula.

This produces three orthogonal axes:

1. **ancestry type** — target-only, target merged with non-target ancestry, or
   independent non-target ancestry;
2. **target-descendant structure** — single-unmerged, single-merged,
   multi-independent, multi-mixed;
3. **old-target d6 stability** — all, some, or none stable.

The audit uses a targeted N2 successor index rather than rebuilding the entire
successor canonical-action universe.  `run_s2comp02c3_targeted_support_gate.py` compares the targeted support set
with full `canonical_actions()` on the state-1 fixture for all 128 directions:
**128/128 matched, 0 mismatches**.  The gate result is stored in
`s2comp02c3_targeted_support_gate_results.json` and is executed automatically by
the main audit. Aggregate survivor counts are also gated against the frozen
02C1/02C2 results.

For runtime reproducibility, each state is evaluated in an isolated worker
process.  This avoids performance dependence on accumulated caches inside the
legacy frozen generator; aggregation order remains deterministic.

## 4. Frozen-domain regression

### 02C1 broad domain

| quantity | value |
|---|---:|
| directed cases | **11,156** |
| survivors | **3,860** |
| no-stable survivors | **0** |
| local sufficient violations | **0** |
| unstable-target R1 survivors | **0** |
| independent R2 survivors | **0** |
| failure count | **0** |

All 3,860 survivors have at least one stable target descendant; in fact all old
target supports in this single-provenance broad domain are stable.

Three-axis split:

| ancestry × descendant structure × d6 | count |
|---|---:|
| TARGET_OLD_ONLY × SINGLE_UNMERGED × ALL_STABLE | **2,174** |
| TARGET_WITH_MERGED_NONTARGET × SINGLE_MERGED × ALL_STABLE | **1,686** |

### 02C2 multi-provenance domain

| quantity | value |
|---|---:|
| directed cases | **2,575** |
| survivors | **809** |
| no-stable survivors | **0** |
| all-old-supports-stable survivors | **516** |
| some-old-supports-stable survivors | **293** |
| unstable-target R1 survivors | **0** |
| independent R2 survivors | **0** |
| target-local merge survivors | **579** |
| doubled-independent survivors | **155** |
| failure count | **0** |

Exact tracer × three-axis cross-table:

| legacy rescue classes × new target structure | count |
|---|---:|
| R0 × TARGET_OLD_ONLY × MULTI_INDEPENDENT × ALL_STABLE | **155** |
| R0 × TARGET_OLD_ONLY × SINGLE_UNMERGED × SOME_STABLE | **75** |
| R0+R1+R2 × TARGET_WITH_MERGED_NONTARGET × MULTI_MIXED × ALL_STABLE | **361** |
| R0+R1+R2 × TARGET_WITH_MERGED_NONTARGET × SINGLE_MERGED × SOME_STABLE | **218** |

This table resolves the earlier 75-case ambiguity completely.  In the 75
single-unmerged R0-only directions, one old target support continues to generate
the target through a single-ancestor after certificate; the other old target
support has a different descendant that does not regenerate the target.  Thus
all 230 R0-only directions are target-local merge-free.

## 5. New theorem

For any frozen disjoint N2 actor/target pair,

\[
 b\in A_{N2}(X\cup a)\land
 \forall c\in\operatorname{Prov}_{N2}^X(b):d_6(c^a)\ne d_6(c)
 \Longrightarrow
 R1_{\mathrm{unstable,target}}\lor R2_{\mathrm{independent}}.
\]

The proof is structural, not empirical:

- exact R0 realization persistence would force the same shortest realization
  before and after, hence stable `d6`;
- 02C2 proves every after N2 certificate has an old ancestor, excluding R3;
- therefore an after certificate supporting `b` either has an old target
  ancestor (changed-`d6` target R1) or it does not (independent R2).

A useful equivalent necessary decomposition is

\[
 b\text{ survives}
 \Longrightarrow
 (\exists\text{ stable old target provenance})
 \lor R1_{\mathrm{unstable,target}}
 \lor R2_{\mathrm{independent}}.
\]

## 6. Interpretation

02C3 does **not** prove the converse.  It does something more controlled: it
reduces any possible converse counterexample to two generator-level mechanisms.

So the next mathematical debt is no longer “understand all rescue classes.” It
is exactly:

1. can an old target provenance regenerate the same action after its `d6`
   changes? (`unstable-target R1`), or
2. can a genuinely independent old non-target certificate become the sole
   ancestry of an after certificate that generates the target?
   (`independent R2`).

If both mechanisms can be excluded universally in the frozen scope, the
survival converse follows immediately.

## 7. Reproducibility

`run_s2comp02c3_audit.py` was run twice from the final code.  The generated
`s2comp02c3_audit_results.json` files were byte-identical.

Result JSON SHA-256 is recorded in `PROVENANCE.json` and `SHA256SUMS.txt`.
