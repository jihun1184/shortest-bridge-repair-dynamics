# S2-COMP-02C3 — Target-Descendant Necessity Boundary

## Frozen scope

Let `X` be a frozen C07 state and let `a,b` be disjoint frozen canonical N2
actions.  Let

\[
\operatorname{Prov}_{N2}^X(b)
\]

be the old N2 certificates supporting `b` in `X`.  For an old target-supporting
certificate `c`, let `c^a` denote its N2 descendant after applying `a` when the
two carrier components remain distinct.

Define

\[
S_c(a) :\Longleftrightarrow d_6(c^a)=d_6(c).
\]

If the old carrier is resolved by `a`, then `S_c(a)` is false.

For a surviving N2 target `b` after `a`, define the after-target support set

\[
\Delta_a(b)=\{d:\ d\text{ is an after-state N2 certificate supporting the
same literal addition set }b\}.
\]

For `d in Delta_a(b)`, let `Anc_a(d)` be its old N2 ancestors under the frozen
component quotient, and let

\[
Anc_a^b(d)=Anc_a(d)\cap \operatorname{Prov}_{N2}^X(b).
\]

The target-descendant multiplicity is

\[
M_a(b)=|\Delta_a(b)|.
\]

The exact ancestor multiplicity of each `d` is inherited from S2-COMP-02C2:
if `d` joins after components `D_r,D_s`, then

\[
|Anc_a(d)|=|q^{-1}(D_r)|\,|q^{-1}(D_s)|.
\]

## Structural target classes used in 02C3

For a surviving target:

- `SINGLE_UNMERGED`: `M_a(b)=1` and the sole supporting after certificate has
  ancestor multiplicity 1.
- `SINGLE_MERGED`: `M_a(b)=1` and the sole supporting after certificate has
  ancestor multiplicity greater than 1.
- `MULTI_INDEPENDENT`: `M_a(b)>1` and every target-supporting after certificate
  has ancestor multiplicity 1.
- `MULTI_MIXED`: `M_a(b)>1` and at least one target-supporting after certificate
  has ancestor multiplicity greater than 1.

The ancestry axis is independent of this multiplicity axis:

- `TARGET_OLD_ONLY`: every target-supporting after certificate has at least one
  old target-supporting ancestor and no non-target old ancestor.
- `TARGET_WITH_MERGED_NONTARGET`: at least one target-supporting after
  certificate has both target-supporting and non-target old ancestors, while no
  target-supporting after certificate is independent of all old target
  provenance.
- `INDEPENDENT_NONTARGET_PRESENT`: some target-supporting after certificate has
  no old target-supporting ancestor but has a non-target old ancestor.  This is
  the certificate-level independent-R2 branch.

R3 is excluded in this frozen N2 scope by the 02C2 quotient theorem.

## Lemma 1 — exact R0 realization survival implies stable d6

Suppose an old target provenance `c` has an exact R0 realization that survives
under `a`: the same endpoint pair and the same monotone shortest path are still
a generated realization for the descendant certificate after applying `a`.

That path is shortest before and after the transition.  Its endpoint distance
therefore equals both `d6(c)` and `d6(c^a)`.  Hence

\[
R0(c;a,b) \Longrightarrow S_c(a).
\]

Consequently, if every old target-supporting provenance has changed `d6`, no
old target provenance can rescue `b` through R0.

## Lemma 2 — frozen N2 R3 exclusion (inherited from 02C2)

Every after-state N2 certificate has at least one old N2 ancestor under a
frozen N2 bridge transition.  Thus a surviving N2 target cannot be supported
only by a genuinely new N2 certificate.

## Theorem — necessary rescue dichotomy for a no-stable survivor

Assume

\[
b\in A_{N2}(X\cup a)
\]

and

\[
\forall c\in\operatorname{Prov}_{N2}^X(b),\qquad \neg S_c(a).
\]

Then at least one of the following must occur:

1. **unstable-target R1 branch:** an old target-supporting certificate has a
   descendant in `Delta_a(b)`.  Because its `d6` changed, exact R0 realization
   survival is impossible, so the descendant regenerates the same literal via
   a changed realization (R1); or
2. **independent R2 branch:** some `d in Delta_a(b)` has
   `Anc_a^b(d)=emptyset`, so `d` is supported only by one or more old
   certificates that did not support `b` before.

### Proof

Because `b` survives as an N2 action, `Delta_a(b)` is nonempty.  Choose any
`d in Delta_a(b)`.  By the 02C2 R3-exclusion theorem, `Anc_a(d)` is nonempty.

If `Anc_a^b(d)` is nonempty, choose an old target-supporting ancestor `c` of
`d`.  By assumption `S_c(a)` is false.  Since `d` itself generates `b` after
the transition, the old target provenance regenerates `b` through its
descendant despite changed `d6`; Lemma 1 excludes R0, leaving the unstable
R1 branch.

If `Anc_a^b(d)` is empty, all old ancestors of `d` are non-target old
certificates.  Since `d` supports `b` after the transition, this is exactly an
independent R2 rescue.

Therefore

\[
\boxed{
 b\in A_{N2}(X\cup a)\ \land\
 \forall c\in\operatorname{Prov}_{N2}^X(b):\neg S_c(a)
 \Longrightarrow
 R1_{\mathrm{unstable,target}}\ \lor\ R2_{\mathrm{independent}}.
}
\]

## Corollary — necessary source decomposition for every surviving N2 target

Within the same frozen scope,

\[
\boxed{
 b\in A_{N2}(X\cup a)
 \Longrightarrow
 \bigl(\exists c\in\operatorname{Prov}_{N2}^X(b):S_c(a)\bigr)
 \lor R1_{\mathrm{unstable,target}}
 \lor R2_{\mathrm{independent}}.
}
\]

This is a necessary decomposition, not a complete survival characterization.
Neither R1 nor independent R2 is proved sufficient here.

## What is not proved

02C3 does **not** prove the universal converse

\[
b\in A_{N2}(X\cup a)
\Longrightarrow
\exists c\in\operatorname{Prov}_{N2}^X(b):S_c(a).
\]

It narrows any possible counterexample to exactly two source mechanisms in the
frozen N2 semantics: unstable-target R1 or independent R2.
