"""Isolated per-state worker for S2-COMP-02C3.

A fresh process per state prevents runtime from depending on accumulated caches
inside the frozen legacy generator.  Mathematical outputs are identical to the
single-process audit; only execution isolation changes.
"""
from __future__ import annotations
import argparse, contextlib, json, tempfile
from pathlib import Path

from s2comp01b_interface import canonical_actions, extract_certificates, load_legacy
from s2comp02c_provenance import load_bridge_api
from run_s2comp02c1_audit import EXPANSION_SAMPLE_SIZE, evenly_spaced, extract_single_root
from run_s2comp02c3_audit import _audit_direction_set, SOURCE_C07_ZIP


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--domain', choices=('broad','multi'), required=True)
    ap.add_argument('--state-index', type=int, required=True)
    ap.add_argument('--out', type=Path, required=True)
    args=ap.parse_args()

    with contextlib.ExitStack() as stack:
        tmp=Path(stack.enter_context(tempfile.TemporaryDirectory(prefix=f'c3w_{args.state_index}_')))
        root=extract_single_root(SOURCE_C07_ZIP,tmp/'c07')
        api=load_legacy(root); bridge_api=load_bridge_api(root)
        raw=json.loads((root/'work/c07d7/c07d7b_satellite_depth4_attack_results.json').read_text())
        row=raw['tested'][args.state_index]
        initial=frozenset(tuple(p) for p in row['state'])
        first=api.atomic_actions(initial)[0]
        state=initial|{tuple(p) for p in first['additions']}
        if args.domain=='broad':
            actions=canonical_actions(state,api)
            selected=evenly_spaced(actions,EXPANSION_SAMPLE_SIZE)
            n2_actions=tuple(a for a in selected if 'N2' in a.roles)
            result=_audit_direction_set(state,n2_actions,n2_actions,api,bridge_api,f'02C1_broad_first_successor_{args.state_index:03d}')
            meta={'state_index':args.state_index,'selected_n2_action_count':len(n2_actions)}
        else:
            before=extract_certificates(state,api)
            before_n2_ids={c.snapshot_id for c in before if c.predicate=='N2_facet_connectivity'}
            actions=canonical_actions(state,api,before)
            targets=tuple(a for a in actions if 'N2' in a.roles and sum(s in before_n2_ids for s in a.certificate_snapshot_ids)>1)
            result=_audit_direction_set(state,targets,actions,api,bridge_api,f'02C2_multi_first_successor_{args.state_index:03d}', trace_rescue=True)
            meta={'state_index':args.state_index,'target_count':len(targets),'action_count':len(actions)}
        result['state_meta']=meta
        args.out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
        print(json.dumps({'domain':args.domain,'state_index':args.state_index,'directions':result['totals']['direction_count'],'survivors':result['totals']['survivor_count']},sort_keys=True))

if __name__=='__main__': main()
