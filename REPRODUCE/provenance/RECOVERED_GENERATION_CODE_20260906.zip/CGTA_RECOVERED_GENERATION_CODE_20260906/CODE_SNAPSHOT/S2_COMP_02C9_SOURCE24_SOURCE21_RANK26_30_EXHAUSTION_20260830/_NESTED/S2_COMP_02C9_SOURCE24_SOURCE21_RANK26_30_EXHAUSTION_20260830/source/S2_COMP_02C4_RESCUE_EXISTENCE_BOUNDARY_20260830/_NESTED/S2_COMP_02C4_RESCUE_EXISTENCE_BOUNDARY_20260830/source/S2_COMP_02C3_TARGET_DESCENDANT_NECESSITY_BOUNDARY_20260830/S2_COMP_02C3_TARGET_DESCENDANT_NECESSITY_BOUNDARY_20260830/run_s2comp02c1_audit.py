"""S2-COMP-02C1: bounded converse-boundary and multi-provenance search.

Frozen predecessors are imported byte-for-byte and never edited. This audit has
three independent pieces:

B1. Reconstruct the exact six-state 02B deterministic 64-action broad domain
    (local filter removed) and search the 11,156 directed cases for the
    converse-counterexample predicate

        target survives AND no old target-supporting N2 provenance has stable d6.

B2. Explicitly search the deterministic first-successor layer of D7B source
    states 0..49 for canonical N2 actions with |Prov_N2(b)| > 1.

B3. Freeze the lexicographically first discovered multi-provenance fixture
    (state index 1), analyze all three multi-provenance targets against every
    disjoint canonical actor in that state, and use the 02C0 tracer to split
    R2 into merge-induced versus independent R2.

Scope: bounded executable evidence only. A zero counterexample count is not a
universal converse theorem.
"""
from __future__ import annotations

import contextlib
import itertools
import json
import tempfile
import zipfile
from collections import Counter
from pathlib import Path

from s2comp01b_interface import canonical_actions, extract_certificates, load_legacy
from s2comp02b_distance import directed_stability
from s2comp02c_provenance import load_bridge_api, trace_provenance

DISTRIBUTED_INDICES = (0, 29, 59, 89, 119, 149)
EXPANSION_SAMPLE_SIZE = 64
MULTI_SEARCH_INDICES = tuple(range(50))
MULTI_FIXTURE_STATE_INDEX = 1

HERE = Path(__file__).resolve().parent
SOURCE_C07_ZIP = HERE / "source" / "c07d7c_absorption_partition_package.zip"
SOURCE_02B_ZIP = HERE / "source" / "S2_COMP_02B_DESCENDANT_DISTANCE_FREEZE_V2_20260829.zip"


def evenly_spaced(actions, count):
    if len(actions) <= count:
        return tuple(actions)
    indices = sorted({round(i * (len(actions) - 1) / (count - 1)) for i in range(count)})
    return tuple(actions[index] for index in indices)


def is_locally_separated(left, right):
    return (
        not (set(left.edit_region) & set(right.local_affected_region))
        and not (set(right.edit_region) & set(left.local_affected_region))
    )


def extract_single_root(zip_path: Path, destination: Path) -> Path:
    with zipfile.ZipFile(zip_path) as zf:
        zf.extractall(destination)
    roots = [p.parent for p in destination.glob("*/README.md")]
    if len(roots) != 1:
        raise RuntimeError(f"expected one package root in {zip_path}, got {roots}")
    return roots[0]


def read_frozen_02b_summary() -> dict:
    with zipfile.ZipFile(SOURCE_02B_ZIP) as zf:
        names = [n for n in zf.namelist() if n.endswith("/s2comp02b_audit_results.json")]
        if len(names) != 1:
            raise RuntimeError(f"expected one frozen 02B result member, got {names}")
        return json.loads(zf.read(names[0]))["summary"]


def unique_n2_witness_count(legacy_action: dict) -> int:
    certificates = {
        json.dumps(witness["certificate"], sort_keys=True, separators=(",", ":"))
        for witness in legacy_action["witnesses"]
        if "certificate" in witness
    }
    return len(certificates)


def successor_caches(state, actor, api, cache):
    value = cache.get(actor.action_id)
    if value is not None:
        return value
    successor = frozenset(state) | set(actor.additions)
    after_actions = {a.additions: a for a in canonical_actions(successor, api)}
    after_components = api.components6(successor)
    after_certificates_tuple = extract_certificates(successor, api)
    after_certificates_dict = {c.snapshot_id: c for c in after_certificates_tuple}
    value = (after_actions, after_components, after_certificates_tuple, after_certificates_dict)
    cache[actor.action_id] = value
    return value


def broad_converse_search(initial_states, api):
    pair_count = 0
    direction_count = 0
    confusion = Counter()
    existential_confusion = Counter()
    converse_counterexamples = []
    local_sufficient_violations = []
    support_histogram = Counter()
    state_summary = []

    for index in DISTRIBUTED_INDICES:
        initial = initial_states[index]
        first = api.atomic_actions(initial)[0]
        state = initial | {tuple(p) for p in first["additions"]}
        all_actions = canonical_actions(state, api)
        selected = evenly_spaced(all_actions, EXPANSION_SAMPLE_SIZE)
        n2_actions = tuple(a for a in selected if "N2" in a.roles)
        before_certificates_tuple = extract_certificates(state, api)
        before_certificates = {c.snapshot_id: c for c in before_certificates_tuple}
        before_n2_ids = {
            c.snapshot_id for c in before_certificates_tuple
            if c.predicate == "N2_facet_connectivity"
        }
        for action in all_actions:
            if "N2" in action.roles:
                support_histogram[sum(sid in before_n2_ids for sid in action.certificate_snapshot_ids)] += 1

        cache = {}
        state_pairs = 0
        for left, right in itertools.combinations(n2_actions, 2):
            if set(left.additions) & set(right.additions):
                continue
            pair_count += 1
            state_pairs += 1
            for actor, target in ((left, right), (right, left)):
                direction_count += 1
                aa, ac, aft, afd = successor_caches(state, actor, api, cache)
                ds = directed_stability(
                    state, actor, target, api,
                    successor_actions=aa,
                    source_certificates=before_certificates,
                    after_components=ac,
                    after_certificates=afd,
                )
                stable_count = sum(w.distance_stable for w in ds.witnesses)
                any_stable = stable_count > 0
                confusion[(ds.all_distance_stable, ds.target_literal_survives)] += 1
                existential_confusion[(any_stable, ds.target_literal_survives)] += 1
                if ds.target_literal_survives and not any_stable:
                    converse_counterexamples.append(ds.record())
                if is_locally_separated(actor, target) and any_stable and not ds.target_literal_survives:
                    local_sufficient_violations.append(ds.record())
        state_summary.append({
            "state_index": index,
            "selected_n2_action_count": len(n2_actions),
            "broad_disjoint_pair_count": state_pairs,
        })

    return {
        "pair_count": pair_count,
        "direction_count": direction_count,
        "all_distance_confusion": {
            f"stable={stable},survives={surv}": count
            for (stable, surv), count in sorted(confusion.items())
        },
        "existential_distance_confusion": {
            f"any_stable={stable},survives={surv}": count
            for (stable, surv), count in sorted(existential_confusion.items())
        },
        "converse_counterexample_count": len(converse_counterexamples),
        "converse_counterexamples": converse_counterexamples[:20],
        "local_sufficient_violation_count": len(local_sufficient_violations),
        "local_sufficient_violations": local_sufficient_violations[:20],
        "full_action_n2_support_count_histogram": dict(sorted(support_histogram.items())),
        "state_summary": state_summary,
    }


def multi_provenance_search(initial_states, api):
    histogram = Counter()
    records = []
    state_summary = []
    for index in MULTI_SEARCH_INDICES:
        initial = initial_states[index]
        first = api.atomic_actions(initial)[0]
        state = initial | {tuple(p) for p in first["additions"]}
        actions = api.atomic_actions(state)
        n2_count = 0
        multi_count = 0
        for action in actions:
            if "N2" not in action["roles"]:
                continue
            n2_count += 1
            k = unique_n2_witness_count(action)
            histogram[k] += 1
            if k > 1:
                multi_count += 1
                records.append({
                    "state_index": index,
                    "first_additions": first["additions"],
                    "target_additions": action["additions"],
                    "n2_provenance_count": k,
                })
        state_summary.append({
            "state_index": index,
            "canonical_action_count": len(actions),
            "n2_action_count": n2_count,
            "multi_provenance_action_count": multi_count,
        })
    records.sort(key=lambda row: (row["state_index"], row["target_additions"]))
    return {
        "searched_state_indices": list(MULTI_SEARCH_INDICES),
        "n2_support_count_histogram": dict(sorted(histogram.items())),
        "multi_provenance_action_count": len(records),
        "records": records,
        "state_summary": state_summary,
    }


def classify_r2(trace_record):
    supported_descendants = {
        row["descendant_snapshot_id"]
        for row in trace_record["old_provenance_traces"]
        if row["supported_target_before"] and row["descendant_exists"]
    }
    r2_rows = [
        row for row in trace_record["old_provenance_traces"]
        if (not row["supported_target_before"]) and row["descendant_reproduces_target"]
    ]
    merge_rows = [row for row in r2_rows if row["descendant_snapshot_id"] in supported_descendants]
    independent_rows = [row for row in r2_rows if row["descendant_snapshot_id"] not in supported_descendants]
    return r2_rows, merge_rows, independent_rows


def multi_fixture_audit(initial_states, api, bridge_api):
    index = MULTI_FIXTURE_STATE_INDEX
    initial = initial_states[index]
    first = api.atomic_actions(initial)[0]
    state = initial | {tuple(p) for p in first["additions"]}
    before_certificates_tuple = extract_certificates(state, api)
    before_certificates = {c.snapshot_id: c for c in before_certificates_tuple}
    before_n2_ids = {
        c.snapshot_id for c in before_certificates_tuple
        if c.predicate == "N2_facet_connectivity"
    }
    actions = canonical_actions(state, api, before_certificates_tuple)
    multi_targets = tuple(
        action for action in actions
        if "N2" in action.roles
        and sum(sid in before_n2_ids for sid in action.certificate_snapshot_ids) > 1
    )

    direction_histogram = Counter()
    local_direction_histogram = Counter()
    rescue_combination_histogram = Counter()
    primary_rescue_histogram = Counter()
    converse_counterexamples = []
    local_sufficient_violations = []
    merge_r2_direction_count = 0
    independent_r2_direction_count = 0
    r3_direction_count = 0
    r2_trace_count = 0
    merge_r2_trace_count = 0
    independent_r2_trace_count = 0
    direction_count = 0
    survivor_count = 0
    cache = {}
    representative_merge = []
    representative_independent = []

    for target in multi_targets:
        for actor in actions:
            if actor.action_id == target.action_id or set(actor.additions) & set(target.additions):
                continue
            direction_count += 1
            aa, ac, aft, afd = successor_caches(state, actor, api, cache)
            ds = directed_stability(
                state, actor, target, api,
                successor_actions=aa,
                source_certificates=before_certificates,
                after_components=ac,
                after_certificates=afd,
            )
            stable_count = sum(w.distance_stable for w in ds.witnesses)
            local = is_locally_separated(actor, target)
            direction_histogram[(stable_count, ds.target_literal_survives)] += 1
            local_direction_histogram[(local, stable_count, ds.target_literal_survives)] += 1
            if ds.target_literal_survives and stable_count == 0:
                converse_counterexamples.append(ds.record())
            if local and stable_count > 0 and not ds.target_literal_survives:
                local_sufficient_violations.append(ds.record())
            if not ds.target_literal_survives:
                continue

            survivor_count += 1
            trace = trace_provenance(
                state, actor, target, api, bridge_api,
                state_label=f"D7B_first_successor_{index:03d}",
                before_certificates=before_certificates_tuple,
                after_actions=aa,
                after_certificates=aft,
            )
            tr = trace.record()
            rescue_combination_histogram[tuple(tr["rescue_classes"])] += 1
            primary_rescue_histogram[tr["primary_rescue_class"]] += 1
            if tr["r3_certificate_snapshot_ids"]:
                r3_direction_count += 1

            r2_rows, merge_rows, independent_rows = classify_r2(tr)
            r2_trace_count += len(r2_rows)
            merge_r2_trace_count += len(merge_rows)
            independent_r2_trace_count += len(independent_rows)
            if merge_rows:
                merge_r2_direction_count += 1
                if len(representative_merge) < 5:
                    representative_merge.append({
                        "actor_additions": actor.additions,
                        "target_additions": target.additions,
                        "stable_support_count": stable_count,
                        "rescue_classes": tr["rescue_classes"],
                        "merge_r2_descendants": sorted({row["descendant_snapshot_id"] for row in merge_rows}),
                    })
            if independent_rows:
                independent_r2_direction_count += 1
                if len(representative_independent) < 5:
                    representative_independent.append({
                        "actor_additions": actor.additions,
                        "target_additions": target.additions,
                        "independent_r2_descendants": sorted({row["descendant_snapshot_id"] for row in independent_rows}),
                    })

    return {
        "state_index": index,
        "first_additions": first["additions"],
        "canonical_action_count": len(actions),
        "before_n2_certificate_count": len(before_n2_ids),
        "multi_target_count": len(multi_targets),
        "multi_targets": [
            {
                "additions": target.additions,
                "n2_provenance_count": sum(sid in before_n2_ids for sid in target.certificate_snapshot_ids),
                "n2_provenance_snapshot_ids": [sid for sid in target.certificate_snapshot_ids if sid in before_n2_ids],
            }
            for target in multi_targets
        ],
        "direction_count": direction_count,
        "survivor_count": survivor_count,
        "direction_histogram": {
            f"stable_supports={stable},survives={surv}": count
            for (stable, surv), count in sorted(direction_histogram.items())
        },
        "local_direction_histogram": {
            f"local={local},stable_supports={stable},survives={surv}": count
            for (local, stable, surv), count in sorted(local_direction_histogram.items())
        },
        "converse_counterexample_count": len(converse_counterexamples),
        "converse_counterexamples": converse_counterexamples[:20],
        "local_sufficient_violation_count": len(local_sufficient_violations),
        "local_sufficient_violations": local_sufficient_violations[:20],
        "rescue_combination_histogram_among_survivors": {
            "+".join(key): value for key, value in sorted(rescue_combination_histogram.items())
        },
        "primary_rescue_histogram_among_survivors": dict(sorted(primary_rescue_histogram.items())),
        "r2_direction_count": sum(
            count for key, count in rescue_combination_histogram.items() if "R2" in key
        ),
        "merge_induced_r2_direction_count": merge_r2_direction_count,
        "independent_r2_direction_count": independent_r2_direction_count,
        "r3_direction_count": r3_direction_count,
        "r2_trace_count": r2_trace_count,
        "merge_induced_r2_trace_count": merge_r2_trace_count,
        "independent_r2_trace_count": independent_r2_trace_count,
        "representative_merge_induced_r2": representative_merge,
        "representative_independent_r2": representative_independent,
    }


def main():
    failures = []
    with contextlib.ExitStack() as stack:
        tmp = Path(stack.enter_context(tempfile.TemporaryDirectory(prefix="s2comp02c1_")))
        root = extract_single_root(SOURCE_C07_ZIP, tmp / "c07")
        api = load_legacy(root)
        bridge_api = load_bridge_api(root)
        raw = json.loads((root / "work" / "c07d7" / "c07d7b_satellite_depth4_attack_results.json").read_text())
        rows = raw["tested"] if isinstance(raw, dict) else raw
        initial_states = [
            frozenset(tuple(point) for point in (row["state"] if isinstance(row, dict) else row))
            for row in rows
        ]

        broad = broad_converse_search(initial_states, api)
        multi = multi_provenance_search(initial_states, api)
        fixture = multi_fixture_audit(initial_states, api, bridge_api)
        frozen = read_frozen_02b_summary()

    # B1 exact reconstruction / frozen cross-check gates.
    if broad["pair_count"] != 5578:
        failures.append({"gate": "B1_pair_count", "observed": broad["pair_count"], "expected": 5578})
    if broad["direction_count"] != 11156:
        failures.append({"gate": "B1_direction_count", "observed": broad["direction_count"], "expected": 11156})
    if broad["all_distance_confusion"] != frozen["broad_directional_confusion_without_local_filter"]:
        failures.append({
            "gate": "B1_confusion_vs_frozen_02B",
            "observed": broad["all_distance_confusion"],
            "expected": frozen["broad_directional_confusion_without_local_filter"],
        })
    if broad["converse_counterexample_count"] != 0:
        failures.append({"gate": "B1_converse_counterexample", "count": broad["converse_counterexample_count"]})
    if broad["local_sufficient_violation_count"] != 0:
        failures.append({"gate": "B1_local_sufficient_violation", "count": broad["local_sufficient_violation_count"]})

    # B2 explicit multi-provenance discovery gates.
    if multi["multi_provenance_action_count"] <= 0:
        failures.append({"gate": "B2_multi_provenance_not_found"})
    if multi["n2_support_count_histogram"] != {1: 8894, 2: 18}:
        failures.append({
            "gate": "B2_support_histogram",
            "observed": multi["n2_support_count_histogram"],
            "expected": {1: 8894, 2: 18},
        })
    if not multi["records"] or multi["records"][0]["state_index"] != MULTI_FIXTURE_STATE_INDEX:
        failures.append({"gate": "B2_fixture_identity", "first_record": multi["records"][0] if multi["records"] else None})

    # B3 fixture closure gates.
    expected_hist = {
        "stable_supports=0,survives=False": 38,
        "stable_supports=1,survives=False": 5,
        "stable_supports=1,survives=True": 46,
        "stable_supports=2,survives=True": 39,
    }
    if fixture["multi_target_count"] != 3:
        failures.append({"gate": "B3_multi_target_count", "observed": fixture["multi_target_count"], "expected": 3})
    if fixture["direction_count"] != 128:
        failures.append({"gate": "B3_direction_count", "observed": fixture["direction_count"], "expected": 128})
    if fixture["direction_histogram"] != expected_hist:
        failures.append({"gate": "B3_direction_histogram", "observed": fixture["direction_histogram"], "expected": expected_hist})
    if fixture["converse_counterexample_count"] != 0:
        failures.append({"gate": "B3_converse_counterexample", "count": fixture["converse_counterexample_count"]})
    if fixture["local_sufficient_violation_count"] != 0:
        failures.append({"gate": "B3_local_sufficient_violation", "count": fixture["local_sufficient_violation_count"]})
    if fixture["merge_induced_r2_direction_count"] != 67:
        failures.append({"gate": "B3_merge_r2_direction_count", "observed": fixture["merge_induced_r2_direction_count"], "expected": 67})
    if fixture["independent_r2_direction_count"] != 0:
        failures.append({"gate": "B3_independent_r2_direction_count", "observed": fixture["independent_r2_direction_count"]})
    if fixture["r3_direction_count"] != 0:
        failures.append({"gate": "B3_r3_direction_count", "observed": fixture["r3_direction_count"]})
    if fixture["r2_trace_count"] != 113 or fixture["merge_induced_r2_trace_count"] != 113 or fixture["independent_r2_trace_count"] != 0:
        failures.append({
            "gate": "B3_r2_trace_partition",
            "observed": [fixture["r2_trace_count"], fixture["merge_induced_r2_trace_count"], fixture["independent_r2_trace_count"]],
            "expected": [113, 113, 0],
        })

    result = {
        "checkpoint": "S2-COMP-02C1 converse boundary search",
        "scope": {
            "claim": "bounded executable search only; no universal converse theorem",
            "broad_domain": "exact six 02B first-successor states, deterministic evenly-spaced 64-action domains, local filter removed",
            "multi_search": "deterministic D7B first-successor states with source indices 0..49",
            "multi_fixture": "all disjoint actor->target directions for all multi-provenance N2 targets in first-successor state index 1",
            "predecessors_modified": [],
        },
        "broad_converse_search": broad,
        "multi_provenance_search": multi,
        "multi_fixture_audit": fixture,
        "failure_count": len(failures),
        "failures": failures,
    }
    (HERE / "s2comp02c1_audit_results.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "broad_pair_count": broad["pair_count"],
        "broad_direction_count": broad["direction_count"],
        "broad_converse_counterexample_count": broad["converse_counterexample_count"],
        "multi_provenance_action_count_first_50": multi["multi_provenance_action_count"],
        "multi_fixture_direction_count": fixture["direction_count"],
        "multi_fixture_converse_counterexample_count": fixture["converse_counterexample_count"],
        "merge_induced_r2_direction_count": fixture["merge_induced_r2_direction_count"],
        "independent_r2_direction_count": fixture["independent_r2_direction_count"],
        "failure_count": len(failures),
    }, indent=2, sort_keys=True))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
