"""Directed descendant-distance diagnostics for S2-COMP-02B."""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from typing import Any, Iterable

from s2comp01b_interface import CanonicalAction, LegacyAPI, canonical_actions, extract_certificates

Point = tuple[int, int, int]


def _stable(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _stable(value[key]) for key in sorted(value)}
    if isinstance(value, (set, frozenset)):
        return tuple(sorted(_stable(item) for item in value))
    if isinstance(value, (tuple, list)):
        return tuple(_stable(item) for item in value)
    return value


def _identifier(prefix: str, value: Any) -> str:
    payload = json.dumps(_stable(value), sort_keys=True, separators=(",", ":"))
    return f"{prefix}-{hashlib.sha256(payload.encode()).hexdigest()[:16]}"


def d6(left: Iterable[Point], right: Iterable[Point]) -> int:
    """Frozen C07 d6: minimum L1 distance between component voxels."""
    left = tuple(left)
    right = tuple(right)
    if not left or not right or set(left) & set(right):
        raise ValueError("d6 requires nonempty disjoint components")
    return min(sum(abs(a - b) for a, b in zip(s, t)) for s in left for t in right)


def shortest_endpoint_pairs(left: Iterable[Point], right: Iterable[Point]):
    left = tuple(left)
    right = tuple(right)
    distance = d6(left, right)
    return tuple(sorted(
        (tuple(s), tuple(t))
        for s in left for t in right
        if sum(abs(a - b) for a, b in zip(s, t)) == distance
    ))


@dataclass(frozen=True)
class WitnessDistance:
    source_snapshot_id: str
    source_obligation_id: str
    before_distance: int
    after_distance: int | None
    distance_stable: bool
    resolved_by_actor: bool
    carrier_unchanged: bool
    endpoint_pairs_unchanged: bool
    before_endpoint_pair_count: int
    after_endpoint_pair_count: int | None
    descendant_snapshot_id: str | None
    target_descendant_provenance_survives: bool
    distance_prediction_matches_descendant_provenance: bool

    def record(self):
        return _stable(asdict(self))


@dataclass(frozen=True)
class DirectedStability:
    occurrence_id: str
    pattern_id: str
    actor_action_id: str
    target_action_id: str
    actor_additions: tuple[Point, ...]
    target_additions: tuple[Point, ...]
    supporting_witness_count: int
    all_distance_stable: bool
    any_distance_stable: bool
    all_carriers_unchanged: bool
    all_endpoint_pairs_unchanged: bool
    target_literal_survives: bool
    target_n2_role_survives: bool
    prediction_matches_literal_survival: bool
    prediction_matches_n2_role_survival: bool
    any_prediction_matches_literal_survival: bool
    any_prediction_matches_n2_role_survival: bool
    all_descendant_provenances_survive: bool
    any_descendant_provenance_survives: bool
    witness_provenance_prediction_mismatch_count: int
    witnesses: tuple[WitnessDistance, ...]

    def record(self):
        value = _stable(asdict(self))
        value["witnesses"] = tuple(item.record() for item in self.witnesses)
        return value


def pair_pattern_id(action_a: CanonicalAction, action_b: CanonicalAction) -> str:
    additions = tuple(sorted((action_a.additions, action_b.additions)))
    return _identifier("pair-pattern", additions)


def pair_occurrence_id(state: Iterable[Point], action_a: CanonicalAction, action_b: CanonicalAction) -> str:
    additions = tuple(sorted((action_a.additions, action_b.additions)))
    return _identifier("pair-occ", (tuple(sorted(state)), additions))


def directed_stability(
    state: Iterable[Point],
    actor: CanonicalAction,
    target: CanonicalAction,
    api: LegacyAPI,
    successor_actions: dict[tuple[Point, ...], CanonicalAction] | None = None,
    source_certificates: dict[str, Any] | None = None,
    after_components: tuple[Any, ...] | None = None,
    after_certificates: dict[str, Any] | None = None,
) -> DirectedStability:
    """Test whether actor preserves d6 for every N2 witness supporting target."""
    state = frozenset(tuple(point) for point in state)
    if set(actor.additions) & set(target.additions):
        raise ValueError("directed literal-survival diagnostic requires disjoint edits")
    certificates = source_certificates
    if certificates is None:
        certificates = {item.snapshot_id: item for item in extract_certificates(state, api)}
    supports = tuple(
        certificates[snapshot_id]
        for snapshot_id in target.certificate_snapshot_ids
        if snapshot_id in certificates
        and certificates[snapshot_id].predicate == "N2_facet_connectivity"
    )
    if not supports or "N2" not in target.roles:
        raise ValueError("target must have at least one supporting N2 certificate")

    successor = state | set(actor.additions)
    if after_components is None:
        after_components = api.components6(successor)
    if successor_actions is None:
        successor_actions = {item.additions: item for item in canonical_actions(successor, api)}
    surviving = successor_actions.get(target.additions)
    literal_survives = surviving is not None
    n2_survives = literal_survives and "N2" in surviving.roles
    if after_certificates is None:
        after_certificates = {
            item.snapshot_id: item for item in extract_certificates(successor, api)
        }
    after_n2_by_carrier = {
        tuple(sorted((tuple(certificate.carrier[0]), tuple(certificate.carrier[1])))): certificate
        for certificate in after_certificates.values()
        if certificate.predicate == "N2_facet_connectivity"
    }
    witness_rows = []
    for certificate in supports:
        left, right = certificate.carrier
        left_desc = api.descendant(frozenset(left), after_components)
        right_desc = api.descendant(frozenset(right), after_components)
        before_pairs = shortest_endpoint_pairs(left, right)
        resolved = left_desc == right_desc
        if resolved:
            after_distance = None
            after_pairs = None
            descendant_certificate = None
        else:
            after_distance = d6(left_desc, right_desc)
            after_pairs = shortest_endpoint_pairs(left_desc, right_desc)
            descendant_certificate = after_n2_by_carrier.get(
                tuple(sorted((tuple(sorted(left_desc)), tuple(sorted(right_desc)))))
            )
            if descendant_certificate is None:
                raise AssertionError("missing descendant N2 certificate")
        provenance_survives = (
            surviving is not None
            and descendant_certificate is not None
            and descendant_certificate.snapshot_id in surviving.certificate_snapshot_ids
        )
        distance_stable = after_distance == d6(left, right)
        witness_rows.append(
            WitnessDistance(
                source_snapshot_id=certificate.snapshot_id,
                source_obligation_id=certificate.obligation_id,
                before_distance=d6(left, right),
                after_distance=after_distance,
                distance_stable=distance_stable,
                resolved_by_actor=resolved,
                carrier_unchanged=(frozenset(left) == left_desc and frozenset(right) == right_desc),
                endpoint_pairs_unchanged=(after_pairs == before_pairs),
                before_endpoint_pair_count=len(before_pairs),
                after_endpoint_pair_count=None if after_pairs is None else len(after_pairs),
                descendant_snapshot_id=None if descendant_certificate is None else descendant_certificate.snapshot_id,
                target_descendant_provenance_survives=provenance_survives,
                distance_prediction_matches_descendant_provenance=(distance_stable == provenance_survives),
            )
        )

    all_distance = all(row.distance_stable for row in witness_rows)
    any_distance = any(row.distance_stable for row in witness_rows)
    all_carriers = all(row.carrier_unchanged for row in witness_rows)
    all_endpoints = all(row.endpoint_pairs_unchanged for row in witness_rows)
    return DirectedStability(
        occurrence_id=_identifier("directed-occ", (tuple(sorted(state)), actor.additions, target.additions)),
        pattern_id=_identifier("directed-pattern", (actor.additions, target.additions)),
        actor_action_id=actor.action_id,
        target_action_id=target.action_id,
        actor_additions=actor.additions,
        target_additions=target.additions,
        supporting_witness_count=len(witness_rows),
        all_distance_stable=all_distance,
        any_distance_stable=any_distance,
        all_carriers_unchanged=all_carriers,
        all_endpoint_pairs_unchanged=all_endpoints,
        target_literal_survives=literal_survives,
        target_n2_role_survives=n2_survives,
        prediction_matches_literal_survival=(all_distance == literal_survives),
        prediction_matches_n2_role_survival=(all_distance == n2_survives),
        any_prediction_matches_literal_survival=(any_distance == literal_survives),
        any_prediction_matches_n2_role_survival=(any_distance == n2_survives),
        all_descendant_provenances_survive=all(row.target_descendant_provenance_survives for row in witness_rows),
        any_descendant_provenance_survives=any(row.target_descendant_provenance_survives for row in witness_rows),
        witness_provenance_prediction_mismatch_count=sum(
            not row.distance_prediction_matches_descendant_provenance for row in witness_rows
        ),
        witnesses=tuple(witness_rows),
    )
