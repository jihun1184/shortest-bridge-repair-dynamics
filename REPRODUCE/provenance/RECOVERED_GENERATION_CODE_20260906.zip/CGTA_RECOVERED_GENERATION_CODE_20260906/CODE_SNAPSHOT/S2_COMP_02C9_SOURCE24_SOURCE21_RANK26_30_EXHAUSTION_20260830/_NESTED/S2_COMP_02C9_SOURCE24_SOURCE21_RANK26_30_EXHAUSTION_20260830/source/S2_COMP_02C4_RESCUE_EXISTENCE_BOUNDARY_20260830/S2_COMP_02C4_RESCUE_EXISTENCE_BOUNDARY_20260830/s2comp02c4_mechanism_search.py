from __future__ import annotations

from collections import defaultdict


def carrier_key(certificate):
    left, right = certificate.carrier
    return tuple(sorted((tuple(sorted(tuple(p) for p in left)), tuple(sorted(tuple(p) for p in right)))))


def bridge_literal_sets(state, certificates, bridge):
    out = {}
    for cert in certificates:
        actions, _ = bridge.certificate_bridge_actions(
            state, (frozenset(cert.carrier[0]), frozenset(cert.carrier[1]))
        )
        out[cert.snapshot_id] = {
            tuple(sorted(tuple(p) for p in action["additions"])) for action in actions
        }
    return out


def search_state(state, api, bridge, *, rep_limit=10000):
    """Fast mechanism-level search; candidates require exact 02C3 confirmation.

    R1 candidate: an old target-support certificate changes d6, persists to a
    descendant certificate, and the same literal belongs to both certificates'
    frozen bridge-action sets.

    Independent-R2 candidate: an after target-support certificate generates an
    old target literal, but none of its old ancestors supported that literal.
    The no-stable flag additionally requires every old target support to have
    unstable d6 under the actor.
    """
    from s2comp01b_interface import canonical_actions, extract_certificates
    from s2comp02b_distance import d6

    state = frozenset(tuple(p) for p in state)
    before = extract_certificates(state, api)
    n2 = [c for c in before if c.predicate == "N2_facet_connectivity"]
    old_sets = bridge_literal_sets(state, n2, bridge)
    old_support = defaultdict(set)
    for sid, literals in old_sets.items():
        for literal in literals:
            old_support[literal].add(sid)

    actors = [a for a in canonical_actions(state, api, before) if "N2" in a.roles]
    reps = {"r1": [], "r2": [], "r2_no_stable": []}
    counts = {
        "actors": len(actors),
        "old_certs": len(n2),
        "old_literals": len(old_support),
        "changed_cert_actor_pairs": 0,
        "r1_candidates": 0,
        "r2_candidates": 0,
        "r2_no_stable_candidates": 0,
    }

    for actor in actors:
        actor_set = set(actor.additions)
        successor = state | actor_set
        after_components = api.components6(successor)
        after = extract_certificates(successor, api)
        after_n2 = [c for c in after if c.predicate == "N2_facet_connectivity"]
        after_by_carrier = {carrier_key(c): c for c in after_n2}
        after_sets = bridge_literal_sets(successor, after_n2, bridge)
        descendants = {}
        stable = {}
        ancestors = {c.snapshot_id: set() for c in after_n2}

        for cert in n2:
            left, right = cert.carrier
            ld = api.descendant(frozenset(left), after_components)
            rd = api.descendant(frozenset(right), after_components)
            if ld == rd:
                descendants[cert.snapshot_id] = None
                stable[cert.snapshot_id] = False
                continue
            dc = after_by_carrier[
                tuple(sorted((tuple(sorted(ld)), tuple(sorted(rd)))))
            ]
            descendants[cert.snapshot_id] = dc.snapshot_id
            stable[cert.snapshot_id] = d6(ld, rd) == d6(left, right)
            ancestors[dc.snapshot_id].add(cert.snapshot_id)
            if not stable[cert.snapshot_id]:
                counts["changed_cert_actor_pairs"] += 1
                for literal in old_sets[cert.snapshot_id] & after_sets[dc.snapshot_id]:
                    if not actor_set.isdisjoint(literal):
                        continue
                    counts["r1_candidates"] += 1
                    if len(reps["r1"]) < rep_limit:
                        reps["r1"].append(
                            {
                                "actor": actor.additions,
                                "literal": literal,
                                "old_cert": cert.snapshot_id,
                                "after_cert": dc.snapshot_id,
                                "before_d6": d6(left, right),
                                "after_d6": d6(ld, rd),
                            }
                        )

        for after_sid, literals in after_sets.items():
            ancestor_set = ancestors.get(after_sid, set())
            for literal in literals.intersection(old_support):
                if not actor_set.isdisjoint(literal):
                    continue
                old_target = old_support[literal]
                if old_target.isdisjoint(ancestor_set):
                    counts["r2_candidates"] += 1
                    no_stable = not any(stable[sid] for sid in old_target)
                    if no_stable:
                        counts["r2_no_stable_candidates"] += 1
                    rec = {
                        "actor": actor.additions,
                        "literal": literal,
                        "after_cert": after_sid,
                        "after_ancestors": sorted(ancestor_set),
                        "old_target_support": sorted(old_target),
                        "old_target_stability": {
                            sid: stable[sid] for sid in sorted(old_target)
                        },
                    }
                    key = "r2_no_stable" if no_stable else "r2"
                    if len(reps[key]) < rep_limit:
                        reps[key].append(rec)
    return counts, reps
