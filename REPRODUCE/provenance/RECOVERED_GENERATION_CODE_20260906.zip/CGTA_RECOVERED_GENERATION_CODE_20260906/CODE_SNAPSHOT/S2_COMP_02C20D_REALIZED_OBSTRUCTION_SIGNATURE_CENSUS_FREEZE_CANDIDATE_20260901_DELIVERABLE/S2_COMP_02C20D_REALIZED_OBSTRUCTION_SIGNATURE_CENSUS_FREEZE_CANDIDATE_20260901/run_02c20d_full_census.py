from __future__ import annotations
import argparse, json, sys
sys.dont_write_bytecode=True
from pathlib import Path
import orjson
from obstruction_signature_core import analyze_source_data
from merge_02c20d_census import merge_rows, SOURCES
from s2comp02c20d_env import env02c20d


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--02c20c',required=True)
    ap.add_argument('--02c20b',required=True)
    ap.add_argument('--02c20a',required=True)
    ap.add_argument('--02c19',required=True)
    ap.add_argument('--02c18',required=True)
    ap.add_argument('--02c9',required=True)
    ap.add_argument('--out-dir',required=True)
    ap.add_argument('--max-witness',type=int,default=3)
    ap.add_argument('--parent-mode',choices=['strict','trusted'],default='strict')
    a=ap.parse_args()
    out=Path(a.out_dir); out.mkdir(parents=True,exist_ok=True)
    results=[]

    with env02c20d(a.__dict__['02c20c'],a.__dict__['02c20b'],a.__dict__['02c20a'],a.__dict__['02c19'],a.__dict__['02c18'],a.__dict__['02c9']) as D:
        C=D['parent_env']
        with C.env02c20c(D['p20b'],D['p20a'],D['p19'],D['p18'],D['p9']) as P20C:
            B=P20C['parent_env']
            with B.env02c20b(P20C['p20a'],P20C['p19'],P20C['p18'],P20C['p9']) as P20B:
                P20A=P20B['parent_env']
                with P20A.env02c20a(P20B['p19'],P20B['p18'],P20B['p9']) as E:
                    shared=orjson.loads((E['root']/'02C19_D1_ORACLE_1_113.json').read_bytes())
                    d114=orjson.loads((E['root']/'02C19_D1_ORACLE_114.json').read_bytes())
                    d115=orjson.loads((E['root']/'02C19_D1_ORACLE_115.json').read_bytes())
                    source_rows={int(s['source_state_index']):s for s in shared['sources']}
                    source_rows.update({int(s['source_state_index']):s for s in d114['sources']})
                    source_rows.update({int(s['source_state_index']):s for s in d115['sources']})
                    if sorted(source_rows)!=SOURCES:
                        raise AssertionError(f'exact source set required: got {sorted(source_rows)}')
                    with E['parent_env'].env02c19_d1(E['p18'],E['p9']) as pe:
                        with pe['env02c12']() as (frozen_env,_,_):
                            with frozen_env() as outer:
                                with outer.frozen.frozen_env() as env:
                                    import finite_window_classification as fw
                                    for sid in SOURCES:
                                        r=analyze_source_data(source_rows[sid],pe['decider'],fw,max_witness=a.max_witness,parent_mode=a.parent_mode)
                                        p=out/f'02C20D_SOURCE_{sid}.json'
                                        p.write_bytes(orjson.dumps(r,option=orjson.OPT_SORT_KEYS|orjson.OPT_INDENT_2)+b'\n')
                                        results.append(r)
                                        print(json.dumps({'source':sid,'totals':r['totals']},sort_keys=True),flush=True)

    agg=merge_rows(results)
    apath=out/'02C20D_REALIZED_OBSTRUCTION_SIGNATURE_CENSUS.json'
    apath.write_bytes(orjson.dumps(agg,option=orjson.OPT_SORT_KEYS|orjson.OPT_INDENT_2)+b'\n')
    print(json.dumps({'aggregate':str(apath),'totals':agg['totals']},indent=2,sort_keys=True))
    print('PASS: 02C20D-A full 10-source census completed')

if __name__=='__main__':
    main()
