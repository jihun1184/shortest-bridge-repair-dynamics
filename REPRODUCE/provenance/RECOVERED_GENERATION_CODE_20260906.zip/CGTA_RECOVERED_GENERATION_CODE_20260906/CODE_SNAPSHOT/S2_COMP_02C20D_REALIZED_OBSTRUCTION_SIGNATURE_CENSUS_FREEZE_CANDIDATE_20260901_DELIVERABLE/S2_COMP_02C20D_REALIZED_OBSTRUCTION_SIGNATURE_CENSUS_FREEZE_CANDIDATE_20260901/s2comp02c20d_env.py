from __future__ import annotations
import hashlib, importlib.util, sys, tempfile, zipfile
from contextlib import contextmanager
from pathlib import Path

P20C_SHA256='4d3db6165490d21f70e1fbeff409957111223dad0d8587becfd3162ff8e8f1c6'
P20C_ROOT='S2_COMP_02C20C_COMMON_CRITICAL_MASK_CENSUS_FREEZE_CANDIDATE_20260901'
P20C_AGG_SHA256='0b8153df6b6d11b901337f6366847893d488cd8a69b54eddb0d13c0ffec4e615'
P20B_SHA256='d2c988914b278e1099516b3a072a43b85b9203e240d7f7479ab41bba6a171caa'
P20A_SHA256='38e8fda72f99bdd43e99b6191a3381f789ed29e0b95cd45d140ce9d1bc17c3e2'
P19_SHA256='47a3cabdeb2300de96906415c7cee21b8a731da3d3cdb7bf7fee78e38804f20b'
P18_SHA256='623b1a639b4549001c9b0091b5d3cb0dee4401d2b3afa54706f307c0508c521b'
P9_SHA256='4ce99f3bb724b5da3b2731d3c60c82d8103713768e715e855585ea5d7c2f7a19'


def sha256(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):
            h.update(b)
    return h.hexdigest()


def checked(p,h,label):
    p=Path(p).expanduser().resolve()
    if not p.is_file():
        raise FileNotFoundError(f'{label} not found: {p}')
    got=sha256(p)
    if got!=h:
        raise AssertionError(f'{label} hash mismatch: expected {h}, got {got}')
    return p


@contextmanager
def env02c20d(p20c,p20b,p20a,p19,p18,p9):
    p20c=checked(p20c,P20C_SHA256,'02C20C')
    p20b=checked(p20b,P20B_SHA256,'02C20B')
    p20a=checked(p20a,P20A_SHA256,'02C20A')
    p19=checked(p19,P19_SHA256,'02C19')
    p18=checked(p18,P18_SHA256,'02C18')
    p9=checked(p9,P9_SHA256,'02C9')
    old=sys.dont_write_bytecode
    sys.dont_write_bytecode=True
    try:
        with tempfile.TemporaryDirectory(prefix='s2comp02c20d_') as td:
            td=Path(td)
            with zipfile.ZipFile(p20c) as z:
                z.extractall(td/'p20c')
            root=td/'p20c'/P20C_ROOT
            if not root.is_dir():
                raise RuntimeError('02C20C extraction root missing')
            agg=root/'02C20C_COMMON_CRITICAL_MASK_CENSUS.json'
            if sha256(agg)!=P20C_AGG_SHA256:
                raise AssertionError('02C20C aggregate hash mismatch')
            spec=importlib.util.spec_from_file_location('_s2comp02c20c_env_20d',root/'s2comp02c20c_env.py')
            mod=importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            yield {
                'p20c_root':root,
                'parent_env':mod,
                'p20b':p20b,'p20a':p20a,'p19':p19,'p18':p18,'p9':p9,
            }
    finally:
        sys.dont_write_bytecode=old
