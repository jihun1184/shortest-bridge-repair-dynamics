#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
if [[ $# -lt 6 || $# -gt 7 ]]; then
  echo "usage: $0 02C20C.zip 02C20B.zip 02C20A.zip 02C19.zip 02C18.zip 02C9.zip [OUTDIR]" >&2
  exit 2
fi
ROOT=$(cd "$(dirname "$0")" && pwd)
OUT=${7:-$(mktemp -d)}
mkdir -p "$OUT"
python "$ROOT/run_02c20d_full_census.py" \
  --02c20c "$1" --02c20b "$2" --02c20a "$3" --02c19 "$4" --02c18 "$5" --02c9 "$6" \
  --out-dir "$OUT" --parent-mode strict
for s in 1 2 4 7 40 41 112 113 114 115; do
  cmp "$OUT/02C20D_SOURCE_${s}.json" "$ROOT/02C20D_SOURCE_${s}.json"
done
cmp "$OUT/02C20D_REALIZED_OBSTRUCTION_SIGNATURE_CENSUS.json" "$ROOT/02C20D_REALIZED_OBSTRUCTION_SIGNATURE_CENSUS.json"
echo "PASS: full 02C20D-A strict 10-source rebuild byte-identical to frozen source shards and aggregate"
