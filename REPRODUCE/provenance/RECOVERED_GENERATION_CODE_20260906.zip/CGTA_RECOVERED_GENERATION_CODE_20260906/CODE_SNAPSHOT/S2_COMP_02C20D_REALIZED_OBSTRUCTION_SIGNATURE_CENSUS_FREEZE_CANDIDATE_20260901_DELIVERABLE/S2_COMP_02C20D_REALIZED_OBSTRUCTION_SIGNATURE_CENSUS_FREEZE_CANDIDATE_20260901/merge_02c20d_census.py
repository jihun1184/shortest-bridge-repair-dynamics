from __future__ import annotations
import argparse, json
from collections import Counter, defaultdict
from pathlib import Path
import orjson

SOURCES=[1,2,4,7,40,41,112,113,114,115]


def add_hist(dst, src):
    for k,v in src.items():
        dst[k]+=int(v)


def merge_rows(rows):
    by={int(r['source_state_index']):r for r in rows}
    if sorted(by)!=SOURCES:
        raise AssertionError(f'exact source set required: got {sorted(by)}')

    theory=rows[0]['theoretical_bad_signatures']
    theory_counts=rows[0]['theoretical_bad_pattern_counts']
    for r in rows[1:]:
        if r['theoretical_bad_signatures']!=theory:
            raise AssertionError('theoretical BAD signature table differs across sources')

    totals=Counter()
    badtype=Counter(); badsize=Counter(); classdist=Counter()
    occsize={'Q2':Counter(),'Q3':Counter()}
    classmulti=Counter()
    patterns={}
    source_support=defaultdict(set)

    nonadditive={
        'realized_unique_bad_signatures','realized_unique_q2_signatures','realized_unique_q3_signatures',
        'unrealized_q2_signatures','unrealized_q3_signatures',
        'mean_distinct_signatures_per_class','mean_obstruction_masks_per_class',
    }
    for sid in SOURCES:
        r=by[sid]
        for k,v in r['totals'].items():
            if k not in nonadditive:
                totals[k]+=v
        add_hist(badtype,r['badset_type_histogram'])
        add_hist(badsize,r['badset_size_histogram'])
        add_hist(classdist,r['class_distinct_signature_count_histogram'])
        for tag in ('Q2','Q3'):
            add_hist(occsize[tag],r['occupancy_size_histogram'][tag])
        add_hist(classmulti,r['class_signature_multiset_histogram'])
        for p in r['realized_patterns']:
            sig=p['signature_id']; source_support[sig].add(sid)
            if sig not in patterns:
                patterns[sig]={
                    'signature_id':sig,
                    'mask_type':p['mask_type'],
                    'occupancy_labels':p['occupancy_labels'],
                    'obstruction_mask_occurrences':0,
                    'class_presence':0,
                    'sources':[],
                    'example':p['example'],
                }
            q=patterns[sig]
            if q['mask_type']!=p['mask_type'] or q['occupancy_labels']!=p['occupancy_labels']:
                raise AssertionError(f'signature payload mismatch: {sig}')
            q['obstruction_mask_occurrences']+=int(p['obstruction_mask_occurrences'])
            q['class_presence']+=int(p['class_presence'])

    for sig,q in patterns.items():
        q['sources']=sorted(source_support[sig])
        q['source_support_count']=len(q['sources'])

    realized=set(patterns)
    q2ids=set(theory['Q2']); q3ids=set(theory['Q3'])
    totals['realized_unique_bad_signatures']=len(realized)
    totals['realized_unique_q2_signatures']=len(realized&q2ids)
    totals['realized_unique_q3_signatures']=len(realized&q3ids)
    totals['unrealized_q2_signatures']=len(q2ids-realized)
    totals['unrealized_q3_signatures']=len(q3ids-realized)
    n=totals['incompatible_multi_incidence_classes']
    if n:
        totals['mean_distinct_signatures_per_class']=totals['sum_distinct_signatures_per_class']/n
        totals['mean_obstruction_masks_per_class']=totals['total_obstruction_mask_occurrences']/n

    return {
        'checkpoint':'S2-COMP-02C20D-A realized obstruction signature aggregate census',
        'scope_sources':SOURCES,
        'logic_note':rows[0]['logic_note'],
        'theoretical_bad_pattern_counts':theory_counts,
        'theoretical_bad_signatures':theory,
        'totals':dict(totals),
        'badset_type_histogram':{k:badtype[k] for k in ('Q2-only','Q3-only','mixed')},
        'badset_size_histogram':{k:badsize[k] for k in sorted(badsize,key=int)},
        'class_distinct_signature_count_histogram':{k:classdist[k] for k in sorted(classdist,key=int)},
        'occupancy_size_histogram':{tag:{k:occsize[tag][k] for k in sorted(occsize[tag],key=int)} for tag in ('Q2','Q3')},
        'realized_signature_ids':{'Q2':sorted(realized&q2ids),'Q3':sorted(realized&q3ids)},
        'unrealized_signature_ids':{'Q2':sorted(q2ids-realized),'Q3':sorted(q3ids-realized)},
        'realized_patterns':sorted(patterns.values(),key=lambda x:x['signature_id']),
        'class_signature_multiset_histogram':{k:classmulti[k] for k in sorted(classmulti)},
        'source_summaries':{str(sid):{
            'totals':by[sid]['totals'],
            'badset_type_histogram':by[sid]['badset_type_histogram'],
            'realized_signature_ids':by[sid]['realized_signature_ids'],
        } for sid in SOURCES},
    }


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--inputs',nargs='+',required=True)
    ap.add_argument('--output',required=True)
    a=ap.parse_args()
    rows=[orjson.loads(Path(p).read_bytes()) for p in a.inputs]
    out=merge_rows(rows)
    Path(a.output).write_bytes(orjson.dumps(out,option=orjson.OPT_SORT_KEYS|orjson.OPT_INDENT_2)+b'\n')
    print(json.dumps({'output':a.output,'totals':out['totals']},indent=2,sort_keys=True))

if __name__=='__main__':
    main()
