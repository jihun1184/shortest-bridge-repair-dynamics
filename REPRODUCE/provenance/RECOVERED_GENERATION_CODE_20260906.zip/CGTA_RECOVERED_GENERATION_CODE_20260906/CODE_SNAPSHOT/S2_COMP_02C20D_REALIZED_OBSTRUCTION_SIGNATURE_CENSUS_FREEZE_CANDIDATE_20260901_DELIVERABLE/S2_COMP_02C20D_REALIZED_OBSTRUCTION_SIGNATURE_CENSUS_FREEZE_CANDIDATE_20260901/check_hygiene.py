from __future__ import annotations
from pathlib import Path
import sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
bad=[]
for p in ROOT.rglob('*'):
    if p.is_dir():
        if p.name=='__pycache__': bad.append(str(p.relative_to(ROOT)))
        continue
    rel=str(p.relative_to(ROOT))
    if p.suffix=='.pyc': bad.append(rel)
    if p.name=='SHA256SUMS.txt': continue
    if p.suffix.lower() in {'.py','.md','.sh','.json','.txt'}:
        s=p.read_text(errors='ignore')
        # Split literals so this checker does not self-match.
        for token in ('/mnt' + '/data/', '/home' + '/'):
            if token in s: bad.append(f'{rel}: absolute-path token {token}')
if bad:
    raise SystemExit('HYGIENE FAIL\n'+'\n'.join(bad))
print('PASS: hygiene (no pycache/pyc, no machine-specific absolute-path tokens)')
