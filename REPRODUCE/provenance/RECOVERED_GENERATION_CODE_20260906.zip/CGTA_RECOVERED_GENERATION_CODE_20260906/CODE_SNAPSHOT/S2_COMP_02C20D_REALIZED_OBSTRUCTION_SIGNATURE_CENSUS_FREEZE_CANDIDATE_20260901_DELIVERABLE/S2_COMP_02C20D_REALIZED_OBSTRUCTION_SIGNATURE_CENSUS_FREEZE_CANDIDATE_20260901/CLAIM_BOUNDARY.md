# Claim boundary

Status: `FREEZE_CANDIDATE` pending independent clean full-scope rebuild acceptance.

The frozen statement is limited to the exact 10-source 02C19-D1 domain and its 37,058 incompatible multi-incidence `(Y,R)` classes.

Supported bounded statements:

1. The strict 02C20B parent literal-badset regression passes on 37,058 / 37,058 classes.
2. The frozen D1 reachable domain realizes 51 of the 90 theoretically bad local occupancy signatures: all 2 Q2 patterns and 49 of 88 Q3 patterns.
3. There are 47,445 literal obstruction-mask occurrences and 45,429 distinct-signature presences summed over classes.
4. Thirty-nine theoretically bad Q3 signatures are not realized anywhere in this frozen scope.

Not claimed:

- no D2 or unrestricted-state theorem;
- no global impossibility theorem for the 39 unrealized Q3 signatures;
- no minimal sufficient statistic claim;
- no relative-position/ChainGap archetype theorem;
- no claim that the realized 51 signatures form a universally complete obstruction basis.
