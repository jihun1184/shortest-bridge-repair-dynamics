from __future__ import annotations
import sys
sys.dont_write_bytecode = True
from collections import Counter, defaultdict


def ser_points(s):
    return [list(p) for p in sorted(s)]


def ser_masks(s):
    return [[k[0], list(k[1])] for k in sorted(s, key=str)]


def ser_labels(labels):
    return [list(x) for x in sorted(labels)]


def signature_id(mask_type, occ):
    # Canonical local combinatorial signature. Absolute site coordinates are
    # deliberately excluded: 02C20D-A measures realized local BAD patterns.
    return mask_type + ':' + '|'.join(','.join(map(str, x)) for x in sorted(occ))


def theoretical_bad_signatures(fw):
    out = {'Q2': {}, 'Q3': {}}
    for tag, table in [('Q2', fw.BAD_Q2), ('Q3', fw.BAD_Q3)]:
        for occ in table:
            sid = signature_id(tag, occ)
            out[tag][sid] = ser_labels(occ)
    return out


def mask_local_signature(F, mask, fw):
    tag, site = mask
    if tag == 'Q2':
        candidates, labels = fw.edge_cands(tuple(site))
        bad_table = fw.BAD_Q2
    elif tag == 'Q3':
        candidates, labels = fw.vertex_cands(tuple(site))
        bad_table = fw.BAD_Q3
    else:
        raise AssertionError(f'unexpected mask type: {tag}')

    Fset = F if isinstance(F, (set, frozenset)) else set(F)
    occ = frozenset(lab for lab, v in zip(labels, candidates) if tuple(v) in Fset)
    is_bad = len(occ) >= 2 and occ in bad_table
    return {
        'signature_id': signature_id(tag, occ),
        'mask_type': tag,
        'occupancy_labels': ser_labels(occ),
        'occupancy_size': len(occ),
        'is_bad_by_table': is_bad,
        'site': list(site),
        'candidate_voxels': [list(v) for v in candidates],
        'candidate_labels': [list(x) for x in labels],
        'candidate_occupancy': [tuple(v) in Fset for v in candidates],
    }


def _badset_type(B):
    kinds = {m[0] for m in B}
    if kinds == {'Q2'}:
        return 'Q2-only'
    if kinds == {'Q3'}:
        return 'Q3-only'
    if kinds == {'Q2', 'Q3'}:
        return 'mixed'
    raise AssertionError(f'unexpected bad-set mask types: {kinds}')


def analyze_source_data(src, decider, fw, max_witness=3, parent_mode='strict'):
    if parent_mode not in {'strict', 'trusted'}:
        raise ValueError("parent_mode must be strict or trusted")
    """02C20D-A realized obstruction signature census for one frozen D1 source.

    Scientific object:
      For each incompatible multi-incidence (Y,R) class g, recompute the
      invariant literal bad set B_g and map every m in B_g to the local
      combinatorial occupancy signature

          sigma_F(m) = (Q2/Q3, occ_F(S(m))).

    `mask_bad` factorization through this local signature is a CODE DEFINITION,
    not a scientific discovery. The new outputs are which of the 2+88
    theoretical BAD signatures are ACTUALLY REALIZED in the frozen D1 scope,
    their frequencies/source support, and within-class signature diversity.
    """
    sid = int(src['source_state_index'])

    pts = set()
    for h in src['histories']:
        pts.update(map(tuple, h['node']))
        for a in h['actions']:
            pts.update(map(tuple, a))
    ordered = sorted(pts)
    idx = {p: i for i, p in enumerate(ordered)}

    def bm(seq):
        x = 0
        for p in seq:
            x |= 1 << idx[tuple(p)]
        return x

    def points(x):
        out = []
        while x:
            low = x & -x
            i = low.bit_length() - 1
            out.append(ordered[i])
            x ^= low
        return frozenset(out)

    prepared = []
    groups = {}
    for h in src['histories']:
        n = bm(h['node'])
        aa = [bm(a) for a in h['actions']]
        yy = [n | a for a in aa]
        prepared.append((h, n, aa, yy))
        for ai, ti, code in h['directions']:
            r = aa[ti] & ~aa[ai]
            if not r:
                continue
            k = (yy[ai], r)
            v = groups.get(k, 0)
            occ = min(2, (v & 3) + 1)
            v = (v & ~3) | occ
            # Frozen oracle-compatible encoding inherited from 02C20A/B/C.
            v |= 1 << (2 + ((code >> 2) & 1))
            groups[k] = v

    collisions = {k for k, v in groups.items() if (v & 3) > 1}
    incompatible_collisions = {k for k in collisions if (groups[k] & 12) == 4}

    delta_map = {}
    delta_points = {}
    for h, n, aa, yy in prepared:
        for ai, ti, code in h['directions']:
            r = aa[ti] & ~aa[ai]
            k = (yy[ai], r)
            if not r or k not in incompatible_collisions:
                continue
            d = aa[ai] & ~(n | aa[ti])
            delta_map.setdefault(k, set()).add(d)
            delta_points.setdefault(d, points(d))

    incidence = {
        d: frozenset(decider.incident_mask_keys(ds, fw))
        for d, ds in delta_points.items()
    }

    st = Counter()
    signature_occurrences = Counter()
    signature_class_presence = Counter()
    occupancy_size_hist = {'Q2': Counter(), 'Q3': Counter()}
    class_distinct_signature_hist = Counter()
    class_signature_multiset_hist = Counter()
    badset_size_hist = Counter()
    badset_type_hist = Counter()
    pattern_examples = {}
    class_witnesses = []

    theory = theoretical_bad_signatures(fw)
    theoretical_ids = set(theory['Q2']) | set(theory['Q3'])

    for k, dset in delta_map.items():
        incs = {incidence[d] for d in dset}
        if len(incs) <= 1:
            continue

        st['incompatible_multi_incidence_classes'] += 1
        F = points(k[0] | k[1])

        # 02C20C is a canonical parent. The D-specific object can therefore be
        # reconstructed efficiently from the literal common incidence. In
        # strict mode we additionally re-run the stronger 02C20B all-incidence
        # literal-stability regression before using it.
        common = frozenset.intersection(*incs)
        Fset = set(F)
        common_details = {m: mask_local_signature(Fset, m, fw) for m in common}
        B = frozenset(m for m, d in common_details.items() if d['is_bad_by_table'])
        if not B:
            raise AssertionError(f'incompatible class has empty bad-set on common incidence: source={sid}')
        st['parent_common_incidence_exact_object_classes'] += 1

        if parent_mode == 'strict':
            badsets = {
                inc: frozenset(m for m in inc if decider.mask_bad(F, m[0], m[1], fw))
                for inc in incs
            }
            if any(not b for b in badsets.values()):
                raise AssertionError(f'incompatible class has empty bad-set: source={sid}')
            distinct_badsets = set(badsets.values())
            if len(distinct_badsets) != 1 or next(iter(distinct_badsets)) != B:
                raise AssertionError(
                    f'02C20B/20C parent literal bad-set regression failed: source={sid}'
                )
            st['parent_literal_badset_strict_regression_classes'] += 1

        sigs = []
        class_seen = set()
        details_for_class = []
        for m in sorted(B, key=str):
            detail = common_details[m]
            if not detail['is_bad_by_table']:
                raise AssertionError(
                    f'B_g mask does not map to BAD table under local occupancy: source={sid}, mask={m}'
                )
            sig = detail['signature_id']
            if sig not in theoretical_ids:
                raise AssertionError(f'realized signature absent from theoretical BAD table: {sig}')
            sigs.append(sig)
            class_seen.add(sig)
            signature_occurrences[sig] += 1
            occupancy_size_hist[detail['mask_type']][detail['occupancy_size']] += 1
            if sig not in pattern_examples:
                pattern_examples[sig] = {
                    'source_state_index': sid,
                    'Y': ser_points(points(k[0])),
                    'R': ser_points(points(k[1])),
                    'F': ser_points(F),
                    'mask': [m[0], list(m[1])],
                    **detail,
                }
            details_for_class.append({'mask': [m[0], list(m[1])], **detail})

        for sig in class_seen:
            signature_class_presence[sig] += 1

        badset_size_hist[len(B)] += 1
        class_distinct_signature_hist[len(class_seen)] += 1
        multiset_key = ';'.join(sorted(sigs))
        class_signature_multiset_hist[multiset_key] += 1
        btype = _badset_type(B)
        badset_type_hist[btype] += 1
        st['total_obstruction_mask_occurrences'] += len(B)
        st['sum_distinct_signatures_per_class'] += len(class_seen)
        st['classes_with_repeated_signature_within_badset'] += int(len(B) > len(class_seen))

        if len(class_witnesses) < max_witness:
            class_witnesses.append({
                'source_state_index': sid,
                'Y': ser_points(points(k[0])),
                'R': ser_points(points(k[1])),
                'F': ser_points(F),
                'distinct_delta_count': len(dset),
                'distinct_incidence_count': len(incs),
                'common_incidence_size': len(common),
                'badset_size': len(B),
                'badset_type': btype,
                'distinct_realized_signature_count': len(class_seen),
                'bad_set': ser_masks(B),
                'obstruction_signatures': details_for_class,
            })

    realized = set(signature_occurrences)
    q2_realized = sorted(realized & set(theory['Q2']))
    q3_realized = sorted(realized & set(theory['Q3']))
    st['realized_unique_bad_signatures'] = len(realized)
    st['realized_unique_q2_signatures'] = len(q2_realized)
    st['realized_unique_q3_signatures'] = len(q3_realized)
    st['unrealized_q2_signatures'] = len(theory['Q2']) - len(q2_realized)
    st['unrealized_q3_signatures'] = len(theory['Q3']) - len(q3_realized)
    ncls = st['incompatible_multi_incidence_classes']
    if ncls:
        st['mean_distinct_signatures_per_class'] = st['sum_distinct_signatures_per_class'] / ncls
        st['mean_obstruction_masks_per_class'] = st['total_obstruction_mask_occurrences'] / ncls

    pattern_rows = []
    for sig in sorted(realized):
        tag = sig.split(':', 1)[0]
        pattern_rows.append({
            'signature_id': sig,
            'mask_type': tag,
            'occupancy_labels': theory[tag][sig],
            'obstruction_mask_occurrences': signature_occurrences[sig],
            'class_presence': signature_class_presence[sig],
            'example': pattern_examples[sig],
        })

    return {
        'checkpoint': 'S2-COMP-02C20D-A realized obstruction signature source census',
        'source_state_index': sid,
        'definitions': {
            'Y': 'node union actor',
            'R': 'target minus actor',
            'F': 'Y union R',
            'B_g': '02C20B invariant literal bad-mask set for one incompatible multi-incidence (Y,R) class',
            'local_signature': '(mask_type, occ_F(S(m))) using canonical Q2/Q3 local labels; absolute site coordinate excluded',
            'occ_F_S_m': 'frozenset of canonical local labels whose candidate voxels lie in F',
        },
        'logic_note': (
            'mask_bad factorization through (mask type, local occupancy labels) is definitional in the frozen code. '
            'The scientific outputs here are realized BAD-pattern diversity/frequency in frozen D1, not that factorization itself.'
        ),
        'parent_regression_mode': parent_mode,
        'parent_regression_note': (
            'trusted mode uses canonical 02C20C common-incidence exactness as the parent contract; strict mode additionally recomputes 02C20B literal bad-set stability across every observed incidence set.'
        ),
        'theoretical_bad_pattern_counts': {'Q2': len(theory['Q2']), 'Q3': len(theory['Q3']), 'total': len(theoretical_ids)},
        'theoretical_bad_signatures': theory,
        'totals': dict(st),
        'badset_type_histogram': {k: badset_type_hist[k] for k in ('Q2-only', 'Q3-only', 'mixed')},
        'badset_size_histogram': {str(k): badset_size_hist[k] for k in sorted(badset_size_hist)},
        'class_distinct_signature_count_histogram': {str(k): class_distinct_signature_hist[k] for k in sorted(class_distinct_signature_hist)},
        'occupancy_size_histogram': {
            tag: {str(k): occupancy_size_hist[tag][k] for k in sorted(occupancy_size_hist[tag])}
            for tag in ('Q2', 'Q3')
        },
        'realized_signature_ids': {'Q2': q2_realized, 'Q3': q3_realized},
        'unrealized_signature_ids': {
            'Q2': sorted(set(theory['Q2']) - realized),
            'Q3': sorted(set(theory['Q3']) - realized),
        },
        'realized_patterns': pattern_rows,
        'class_signature_multiset_histogram': {k: class_signature_multiset_hist[k] for k in sorted(class_signature_multiset_hist)},
        'witnesses': {'first_classes': class_witnesses},
    }
