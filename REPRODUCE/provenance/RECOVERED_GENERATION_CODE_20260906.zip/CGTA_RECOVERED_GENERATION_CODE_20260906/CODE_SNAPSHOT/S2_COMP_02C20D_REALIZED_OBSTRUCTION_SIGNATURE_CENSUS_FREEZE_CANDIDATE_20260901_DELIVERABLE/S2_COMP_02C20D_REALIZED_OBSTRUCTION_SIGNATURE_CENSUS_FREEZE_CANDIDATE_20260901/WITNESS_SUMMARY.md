# Witness summary

The aggregate already contains one literal audit example for every realized signature. This file surfaces five most prevalent and five rarest realized signatures for quick manual checking.

## Most prevalent
- `Q2:0,1|1,0` — class presence 23,792; mask occurrences 25,171; source support 10/10; example source 1
- `Q2:0,0|1,1` — class presence 15,107; mask occurrences 15,742; source support 8/10; example source 1
- `Q3:0,0,0|0,1,0|0,1,1|1,0,1` — class presence 814; mask occurrences 814; source support 4/10; example source 41
- `Q3:0,1,0|0,1,1|1,0,0|1,0,1` — class presence 698; mask occurrences 698; source support 1/10; example source 115
- `Q3:0,0,1|1,0,0|1,1,0|1,1,1` — class presence 490; mask occurrences 490; source support 4/10; example source 41

## Rarest realized
- `Q3:0,0,0|0,1,1|1,1,0|1,1,1` — class presence 1; mask occurrences 1; source support 1/10; example source 4
- `Q3:0,0,1|0,1,1|1,0,0` — class presence 1; mask occurrences 1; source support 1/10; example source 4
- `Q3:0,1,0|0,1,1|1,0,0` — class presence 1; mask occurrences 1; source support 1/10; example source 1
- `Q3:0,1,0|1,0,0` — class presence 1; mask occurrences 1; source support 1/10; example source 1
- `Q3:0,1,1|1,1,0` — class presence 1; mask occurrences 1; source support 1/10; example source 115

For hand verification, use the corresponding `example` object in `WITNESS_SUMMARY.json`, which preserves `F`, mask type/site, candidate voxels, canonical labels, occupancy booleans, and the local `is_bad_by_table` result.
