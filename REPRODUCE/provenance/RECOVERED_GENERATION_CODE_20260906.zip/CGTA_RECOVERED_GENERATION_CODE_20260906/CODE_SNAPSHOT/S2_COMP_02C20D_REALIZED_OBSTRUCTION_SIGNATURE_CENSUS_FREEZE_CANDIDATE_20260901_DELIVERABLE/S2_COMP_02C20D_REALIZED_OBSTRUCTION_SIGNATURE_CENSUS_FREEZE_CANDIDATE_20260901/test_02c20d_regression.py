from __future__ import annotations
from pathlib import Path
import hashlib, json, subprocess, sys, tempfile
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
SOURCES=[1,2,4,7,40,41,112,113,114,115]

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):
            h.update(b)
    return h.hexdigest()

expected=json.loads((ROOT/'FROZEN_HASHES.json').read_text())
for name,h in expected.items():
    got=sha(ROOT/name)
    assert got==h,(name,h,got)

d=json.loads((ROOT/'02C20D_REALIZED_OBSTRUCTION_SIGNATURE_CENSUS.json').read_text())
t=d['totals']
assert d['theoretical_bad_pattern_counts']=={'Q2':2,'Q3':88,'total':90}
assert t['incompatible_multi_incidence_classes']==37058
assert t['parent_common_incidence_exact_object_classes']==37058
assert t['parent_literal_badset_strict_regression_classes']==37058
assert t['realized_unique_bad_signatures']==51
assert t['realized_unique_q2_signatures']==2
assert t['realized_unique_q3_signatures']==49
assert t['unrealized_q2_signatures']==0
assert t['unrealized_q3_signatures']==39
assert t['total_obstruction_mask_occurrences']==47445
assert t['sum_distinct_signatures_per_class']==45429
assert t['classes_with_repeated_signature_within_badset']==1988
assert len(d['realized_signature_ids']['Q2'])==2
assert len(d['realized_signature_ids']['Q3'])==49
assert len(d['unrealized_signature_ids']['Q3'])==39
assert set(d['realized_signature_ids']['Q2'])==set(d['theoretical_bad_signatures']['Q2'])
assert set(d['realized_signature_ids']['Q3']).isdisjoint(d['unrealized_signature_ids']['Q3'])
assert set(d['realized_signature_ids']['Q3'])|set(d['unrealized_signature_ids']['Q3'])==set(d['theoretical_bad_signatures']['Q3'])
assert d['scope_sources']==SOURCES
assert sum(int(v) for v in d['badset_size_histogram'].values())==37058
assert sum(int(v) for v in d['class_distinct_signature_count_histogram'].values())==37058
assert sum(int(v) for v in d['occupancy_size_histogram']['Q2'].values())+sum(int(v) for v in d['occupancy_size_histogram']['Q3'].values())==47445
for sid in SOURCES:
    s=json.loads((ROOT/f'02C20D_SOURCE_{sid}.json').read_text())
    assert s['source_state_index']==sid
    assert s['parent_regression_mode']=='strict'
    assert s['totals']['parent_literal_badset_strict_regression_classes']==s['totals']['incompatible_multi_incidence_classes']

with tempfile.TemporaryDirectory() as td:
    out=Path(td)/'agg.json'
    inputs=[str(ROOT/f'02C20D_SOURCE_{s}.json') for s in SOURCES]
    subprocess.run([sys.executable,str(ROOT/'merge_02c20d_census.py'),'--inputs',*inputs,'--output',str(out)],check=True,stdout=subprocess.DEVNULL)
    assert out.read_bytes()==(ROOT/'02C20D_REALIZED_OBSTRUCTION_SIGNATURE_CENSUS.json').read_bytes()

subprocess.run([sys.executable,str(ROOT/'check_hygiene.py')],check=True)
print('PASS: frozen hashes, 37,058 strict parent regressions, 51/90 realized signatures, 47,445 occurrences, deterministic merge, and hygiene')
