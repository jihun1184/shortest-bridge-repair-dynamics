from __future__ import annotations
import argparse, subprocess, sys, tempfile
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--02c20c',required=True)
    ap.add_argument('--02c20b',required=True)
    ap.add_argument('--02c20a',required=True)
    ap.add_argument('--02c19',required=True)
    ap.add_argument('--02c18',required=True)
    ap.add_argument('--02c9',required=True)
    a=ap.parse_args()
    with tempfile.TemporaryDirectory() as td:
        out=Path(td)/'source1.json'
        cmd=[sys.executable,str(ROOT/'analyze_02c20d_source.py'),
             '--02c20c',a.__dict__['02c20c'],'--02c20b',a.__dict__['02c20b'],'--02c20a',a.__dict__['02c20a'],
             '--02c19',a.__dict__['02c19'],'--02c18',a.__dict__['02c18'],'--02c9',a.__dict__['02c9'],
             '--source','1','--parent-mode','strict','--output',str(out)]
        subprocess.run(cmd,check=True)
        if out.read_bytes()!=(ROOT/'02C20D_SOURCE_1.json').read_bytes():
            raise AssertionError('live source-1 strict output is not byte-identical to frozen source shard')
    print('PASS: live source-1 strict output byte-identical to frozen 02C20D-A source shard')

if __name__=='__main__':
    main()
