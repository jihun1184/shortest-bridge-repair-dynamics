# S2-COMP-02C20D-A — Realized Obstruction Signature Census

This package freezes the full 10-source realized-obstruction-signature census over the canonical frozen D1 incompatible multi-incidence `(Y,R)` scope.

## Scientific object

For every invariant literal obstruction mask `m in B_g`, define the canonical local signature

`signature(m) = (Q2/Q3 mask type, occ_F(S(m)))`, with `F = Y union R`.

Absolute site coordinates are deliberately excluded from the signature. They are retained only inside examples/witnesses for auditability.

`mask_bad` factorization through `(mask type, local occupancy labels)` is definitional in the frozen code. The new scientific information is which theoretically bad local patterns are actually realized in the frozen D1 reachable domain, how frequently they occur, and how many distinct signatures appear per class.

## Frozen full-scope result

Across all 37,058 incompatible multi-incidence `(Y,R)` classes:

- parent 02C20B literal-badset strict regression: 37,058 / 37,058
- total obstruction-mask occurrences: 47,445
- theoretical bad signatures: 90 = 2 Q2 + 88 Q3
- realized signatures: 51 / 90
- realized Q2: 2 / 2
- realized Q3: 49 / 88
- unrealized Q3: 39 / 88
- mean distinct signatures per class: 1.2258891467429436
- classes with a repeated signature within the literal bad set: 1,988 / 37,058

This is a bounded reachability restriction, not a claim that the 90-pattern table itself is reducible in general.

## Rebuild

`run_full_rebuild.sh` accepts the six exact parent ZIPs in order: 02C20C, 02C20B, 02C20A, 02C19-D1, 02C18, 02C9. It recomputes all ten source shards in `strict` mode, deterministically merges the aggregate, and byte-compares every generated JSON to the frozen package copies.

The strict run rechecks the parent literal bad-set stability on all 37,058 classes instead of merely trusting the canonical parent contract.
