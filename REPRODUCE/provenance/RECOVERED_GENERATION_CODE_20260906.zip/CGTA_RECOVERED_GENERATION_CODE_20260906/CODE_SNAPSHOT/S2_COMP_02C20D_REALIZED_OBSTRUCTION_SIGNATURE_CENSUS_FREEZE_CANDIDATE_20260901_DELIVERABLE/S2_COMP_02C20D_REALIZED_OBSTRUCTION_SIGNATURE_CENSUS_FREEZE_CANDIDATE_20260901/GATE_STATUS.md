# Gate status

- exact parent ZIP hash chain enforced: PASS
- exact source set `{1,2,4,7,40,41,112,113,114,115}`: PASS
- strict parent literal-badset regression classes: 37,058 / 37,058
- parent common-incidence exact-object classes: 37,058 / 37,058
- theoretical signatures: Q2 2, Q3 88, total 90
- realized signatures: Q2 2, Q3 49, total 51
- unrealized signatures: Q2 0, Q3 39
- total obstruction-mask occurrences: 47,445
- repeated-signature classes: 1,988
- deterministic aggregate merge: PASS
- fast frozen regression: PASS
- hygiene: PASS
- full strict 10-source byte-identical rebuild: included as external acceptance gate
