# Result summary

The frozen D1 domain realizes a proper subset of the theoretical local bad-pattern table:

- Q2: 2 / 2 realized
- Q3: 49 / 88 realized
- total: 51 / 90 realized
- Q3 unrealized: 39

This is a moderate reachability restriction rather than a collapse to only a handful of signatures.

The two most prevalent signatures by class presence are:

1. `Q2:0,1|1,0` — 23,792 classes, 25,171 mask occurrences, source support 10 / 10.
2. `Q2:0,0|1,1` — 15,107 classes, 15,742 mask occurrences, source support 8 / 10.

Several realized Q3 signatures occur in exactly one class, so rare local obstruction patterns are present and are retained in the aggregate with literal witness examples.

The mean number of distinct realized signatures per incompatible class is 1.2258891467429436. Exactly 1,988 classes contain at least one repeated local signature on multiple physical obstruction masks.
