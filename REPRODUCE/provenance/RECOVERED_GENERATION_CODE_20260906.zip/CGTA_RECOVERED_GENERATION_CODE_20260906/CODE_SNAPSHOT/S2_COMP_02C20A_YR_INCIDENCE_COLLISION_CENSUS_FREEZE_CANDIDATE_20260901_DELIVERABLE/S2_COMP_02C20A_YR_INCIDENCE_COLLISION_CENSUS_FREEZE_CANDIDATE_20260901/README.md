# S2-COMP-02C20A — YR / incidence collision census

Parent: canonical `S2_COMP_02C19_D1_DEEP_HISTORY_DECISION_CENSUS_FREEZE_20260831.zip` (`47a3cabd...f20b`). Exact 02C18 and 02C9 hashes are enforced by `s2comp02c20a_env.py`.

## Question

Does fixing physical child state `Y` and residual `R` already determine the frozen D1 support outcome, or can different last-step provenance `Delta` / incident-mask sets change compatibility?

The analyzer uses the **exact set key** `frozenset(incident_mask_keys(delta, fw))`; it never substitutes incidence cardinality.

## Result

Across all 3,916,557 partial directions:

| measure | count |
|---|---:|
| distinct `(Y,R)` classes | 3,381,730 |
| multi-direction `(Y,R)` classes | 399,268 |
| multi-Delta classes | 373,356 |
| multi-incidence classes | 373,356 |
| different-Delta / same-incidence classes | 0 |
| different-incidence / same-compatible classes | 373,356 |
| ... always compatible | 336,298 |
| ... always incompatible | 37,058 |
| mixed compatibility classes | **0** |
| mixed support classes | **0** |
| same-incidence / mixed-compatibility classes | **0** |

This is the opposite of the initial counterexample expectation: substantial provenance and incidence variation exists, but it does not flip `C` or support once `(Y,R)` is fixed in this D1 census.

Representative witnesses retain `node, actor, target, Y, R, F, Delta, incident_mask_keys, bad_incident_masks, compatible, supported`. Compatible witnesses have empty `bad_incident_masks`; incompatible witnesses retain nonempty bad-mask lists and allow direct `mask_bad` / BAD_Q2 / BAD_Q3 audit.

## Verification

Fast frozen regression:

`python test_02c20a_regression.py`

Strong source-1 raw gate (requires exact 02C19/02C18/02C9 zips):

`python test_02c20a_regression.py --live-source1 --02c19 <02C19.zip> --02c18 <02C18.zip> --02c9 <02C9.zip>`

The live gate rebuilds source-1 oracle from 02C18/02C9, recomputes geometry on all 3,402 collision directions, regenerates exact incidence/bad masks, and requires the resulting source-1 collision census to be byte-identical to the frozen file.

`run_full_rebuild.sh` regenerates all ten source collision shards, reruns source-1 with live geometry, merges deterministically, and `cmp`s all frozen outputs.

## Source-1 witness regression fixtures

`WITNESS_FIXTURES_SOURCE1.json` freezes one independently auditable representative of each observed source-1 class:

- `diff_I_same_C_true`
- `diff_I_same_C_false`

`test_02c20a_witness_fixtures.py` requires each pair to have the same exact `(Y,R)`, different exact incident-mask sets, and identical compatibility. The stronger live source-1 rebuild regenerates the complete source-1 JSON, including direct `mask_bad(F,key)` bad-mask lists.

## Freeze status

This package is a **canonical freeze candidate**, not yet a user-independent canonical freeze. Frozen 10-source outputs, deterministic merge, hard regression gates, source-1 live/raw verification path, full 10-source raw rebuild runner, witness fixtures, and packaging hygiene are included. Independent full-scope reproduction remains the external acceptance step.
