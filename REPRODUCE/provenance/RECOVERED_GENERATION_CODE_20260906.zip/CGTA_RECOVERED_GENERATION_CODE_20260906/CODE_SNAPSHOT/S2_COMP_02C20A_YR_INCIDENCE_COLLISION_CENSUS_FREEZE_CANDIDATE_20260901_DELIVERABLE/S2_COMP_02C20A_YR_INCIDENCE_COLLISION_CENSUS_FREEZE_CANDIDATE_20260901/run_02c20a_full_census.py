from __future__ import annotations
import sys
sys.dont_write_bytecode=True
import argparse, json
from pathlib import Path
import orjson
from collision_core import analyze_source_data
from s2comp02c20a_env import env02c20a
IDS=[1,2,4,7,40,41,112,113,114,115]
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--02c19',required=True); ap.add_argument('--02c18',required=True); ap.add_argument('--02c9',required=True); ap.add_argument('--out-dir',required=True); a=ap.parse_args(); out=Path(a.out_dir); out.mkdir(parents=True,exist_ok=True)
 with env02c20a(a.__dict__['02c19'],a.__dict__['02c18'],a.__dict__['02c9']) as E:
  shards={}
  for name in ('02C19_D1_ORACLE_1_113.json','02C19_D1_ORACLE_114.json','02C19_D1_ORACLE_115.json'):
   d=orjson.loads((E['root']/name).read_bytes())
   for s in d['sources']: shards[int(s['source_state_index'])]=s
  with E['parent_env'].env02c19_d1(E['p18'],E['p9']) as pe:
   with pe['env02c12']() as (frozen_env,_,_):
    with frozen_env() as outer:
     with outer.frozen.frozen_env() as env:
      import finite_window_classification as fw
      for sid in IDS:
       r=analyze_source_data(shards[sid],pe['decider'],fw,verify_geometry_live=False)
       p=out/f'02C20A_SOURCE_{sid}.json'; p.write_bytes(orjson.dumps(r,option=orjson.OPT_SORT_KEYS|orjson.OPT_INDENT_2)+b'\n'); print(json.dumps({'source':sid,'output':str(p),'totals':r['totals']},sort_keys=True),flush=True)
if __name__=='__main__': main()
