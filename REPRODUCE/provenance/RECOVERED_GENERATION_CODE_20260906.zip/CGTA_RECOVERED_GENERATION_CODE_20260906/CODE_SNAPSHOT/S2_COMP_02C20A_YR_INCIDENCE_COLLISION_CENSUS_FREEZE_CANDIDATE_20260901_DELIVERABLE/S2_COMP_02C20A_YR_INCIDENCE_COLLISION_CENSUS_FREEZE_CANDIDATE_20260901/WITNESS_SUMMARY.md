# Representative witness summary

The observed mechanism is **not** a compatibility flip. Instead, the census contains many same-`(Y,R)` classes where literal `Delta` and the exact incident-mask set differ while the compatibility bit remains fixed.

Two source-1 witness types are frozen in `02C20A_SOURCE_1.json` and the aggregate census:

1. `diff_I_same_C_true`: both incident sets have zero bad incident masks, despite different `Delta` and different exact incidence sets.
2. `diff_I_same_C_false`: both incident sets contain bad masks, so compatibility remains false despite incidence variation.

For example, the first compatible witness has incidence-set cardinalities 20 and 61 and zero bad masks on both sides. The first incompatible witness has incidence-set cardinalities 44 and 52 and two bad masks on both sides.

These examples are for auditability only. The scientific count is class-based and uses exact frozenset equality, not cardinality equality.
