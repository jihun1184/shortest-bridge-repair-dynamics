from __future__ import annotations
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
src=json.loads((HERE/'02C20A_SOURCE_1.json').read_text())
fx=json.loads((HERE/'WITNESS_FIXTURES_SOURCE1.json').read_text())
by_kind={}
for w in src['witnesses']:
    by_kind.setdefault(w['kind'],[]).append(w)
for w in fx['fixtures']:
    k=w['kind']
    if k not in by_kind: raise AssertionError(f'missing witness kind {k}')
    if w not in by_kind[k]: raise AssertionError(f'fixture not present among frozen source-1 witnesses {k}')
    pair=w['pair']
    if len(pair)!=2: raise AssertionError(k)
    if pair[0]['Y']!=pair[1]['Y'] or pair[0]['R']!=pair[1]['R']: raise AssertionError(f'{k}: pair is not same (Y,R)')
    if pair[0]['incident_mask_keys']==pair[1]['incident_mask_keys']: raise AssertionError(f'{k}: incidence did not differ')
    if pair[0]['compatible']!=pair[1]['compatible']: raise AssertionError(f'{k}: compatibility unexpectedly differs')
    if k=='diff_I_same_C_true' and not pair[0]['compatible']: raise AssertionError(k)
    if k=='diff_I_same_C_false' and pair[0]['compatible']: raise AssertionError(k)
print('PASS: frozen source-1 witness fixtures match exact same-(Y,R), different-incidence, same-compatibility records')
