from __future__ import annotations
import functools
from collections import Counter, defaultdict
import orjson

def ser_points(s): return [list(p) for p in sorted(s)]
def ser_masks(s): return [[k[0],list(k[1])] for k in sorted(s,key=str)]

def row_payload(sid,h,ai,ti,node,acts,code,delta,inc,decider,fw):
    actor=acts[ai]; target=acts[ti]; Y=frozenset(node|actor); R=frozenset(target-actor); F=frozenset(Y|R)
    if F != frozenset(node|actor|target): raise AssertionError('F != Y union R')
    bad=tuple(sorted((m for m in inc if decider.mask_bad(F,m[0],m[1],fw)),key=str))
    return {'source_state_index':sid,'history_key':h['history_key'],'actor_index':ai,'target_index':ti,
            'node':ser_points(node),'actor':ser_points(actor),'target':ser_points(target),'Y':ser_points(Y),'R':ser_points(R),'F':ser_points(F),
            'delta':ser_points(delta),'incident_mask_keys':ser_masks(inc),'bad_incident_masks':ser_masks(bad),
            'compatible':bool(code&4),'supported':bool(code&2)}

def analyze_source_data(src, decider, fw, env=None, cv=None, verify_geometry_live=False):
    sid=int(src['source_state_index']); pts=set()
    for h in src['histories']:
        pts.update(map(tuple,h['node']))
        for a in h['actions']: pts.update(map(tuple,a))
    ordered=sorted(pts); idx={p:i for i,p in enumerate(ordered)}
    def bm(seq):
        x=0
        for p in seq: x |= 1<<idx[tuple(p)]
        return x
    def points(x):
        out=[]
        while x:
            low=x&-x; i=low.bit_length()-1; out.append(ordered[i]); x^=low
        return frozenset(out)
    prepared=[]; groups={}; st=Counter()
    for h in src['histories']:
        n=bm(h['node']); aa=[bm(a) for a in h['actions']]; yy=[n|a for a in aa]; prepared.append((h,n,aa,yy))
        for ai,ti,code in h['directions']:
            r=aa[ti]&~aa[ai]
            if not r: continue
            st['partial_directions']+=1; k=(yy[ai],r); v=groups.get(k,0); occ=min(2,(v&3)+1); v=(v&~3)|occ
            v |= 1<<(2+((code>>2)&1)); v |= 1<<(4+((code>>1)&1)); groups[k]=v
    collisions={k for k,v in groups.items() if (v&3)>1}
    st['yr_groups']=len(groups); st['multi_direction_yr_groups']=len(collisions)
    st['mixed_compatibility_yr_groups']=sum((v&12)==12 for v in groups.values())
    st['mixed_support_yr_groups']=sum((v&48)==48 for v in groups.values())
    delta_map={}; delta_points={}
    for h,n,aa,yy in prepared:
        for ai,ti,code in h['directions']:
            r=aa[ti]&~aa[ai]; k=(yy[ai],r)
            if not r or k not in collisions: continue
            d=aa[ai]&~(n|aa[ti]); rec=delta_map.setdefault(k,{})
            rec[d]=rec.get(d,0)|(1<<((code>>2)&1)); delta_points.setdefault(d,points(d))
    incidence={d:frozenset(decider.incident_mask_keys(ds,fw)) for d,ds in delta_points.items()}
    witness_specs=[]
    for k,dmap in delta_map.items():
        inv=defaultdict(list); overall=0
        for d,cb in dmap.items(): inv[incidence[d]].append((d,cb)); overall|=cb
        nd=len(dmap); ni=len(inv)
        st['multi_delta_yr_groups']+=nd>1; st['multi_incidence_yr_groups']+=ni>1
        st['multi_delta_single_incidence_yr_groups']+=nd>1 and ni==1
        sameI_multiD=any(len(xs)>1 for xs in inv.values()); st['diff_delta_same_incidence_groups']+=sameI_multiD
        sameI_mixedC=False
        for xs in inv.values():
            bits=functools.reduce(lambda a,b:a|b,(cb for _,cb in xs),0); sameI_mixedC |= bits==3
        st['same_incidence_mixed_compatibility_groups']+=sameI_mixedC
        if ni>1 and overall!=3:
            st['diff_incidence_same_compatibility_groups']+=1
            st['diff_incidence_same_compatibility_true_groups']+=overall==2
            st['diff_incidence_same_compatibility_false_groups']+=overall==1
        if ni>1 and overall==3: st['diff_incidence_mixed_compatibility_groups']+=1
        kind=None
        if ni>1 and overall==2 and st.get('_wit_true',0)<3: kind='diff_I_same_C_true'; st['_wit_true']+=1
        if ni>1 and overall==1 and st.get('_wit_false',0)<3: kind='diff_I_same_C_false'; st['_wit_false']+=1
        if kind:
            i1,i2=list(inv)[:2]; witness_specs.append((kind,k,inv[i1][0][0],inv[i2][0][0]))
    st.pop('_wit_true',None); st.pop('_wit_false',None)
    mixed_geometry=0; geometry_rows=0
    if verify_geometry_live:
        if env is None or cv is None: raise ValueError('verify_geometry_live requires env and cv')
        endpoint_cache={}; geom_sets=defaultdict(set)
        for h,n,aa,yy in prepared:
            for ai,ti,code in h['directions']:
                r=aa[ti]&~aa[ai]; k=(yy[ai],r)
                if not r or k not in collisions: continue
                child=points(yy[ai]); residual=points(r); ck=yy[ai]
                if ck not in endpoint_cache:
                    certs=tuple(c for c in env.pred['extract_certificates'](child,env.api) if c.predicate=='N2_facet_connectivity')
                    endpoint_cache[ck]=decider.compile_child_geometry(certs,cv)
                g,_=decider.chain_gap_exists_compiled(child,residual,endpoint_cache[ck]); geom_sets[k].add(bool(g)); geometry_rows+=1
        mixed_geometry=sum(len(v)>1 for v in geom_sets.values())
    st['mixed_geometry_yr_groups']=mixed_geometry; st['geometry_rows_recomputed_live']=geometry_rows
    witnesses=[]; need={(kind,k,d1,d2) for kind,k,d1,d2 in witness_specs}; reps={}
    if need:
        for h,n,aa,yy in prepared:
            node=points(n); acts=[points(a) for a in aa]
            for ai,ti,code in h['directions']:
                r=aa[ti]&~aa[ai]
                if not r: continue
                k=(yy[ai],r); d=aa[ai]&~(n|aa[ti])
                for spec in list(need):
                    kind,kk,d1,d2=spec
                    if k==kk and d in (d1,d2):
                        reps[(spec,d)]=(h,ai,ti,node,acts,code,delta_points[d],incidence[d])
                        if (spec,d1) in reps and (spec,d2) in reps: need.remove(spec)
                if not need: break
            if not need: break
        for spec in witness_specs:
            kind,k,d1,d2=spec; pair=[row_payload(sid,*reps[(spec,d)],decider,fw) for d in (d1,d2)]
            witnesses.append({'kind':kind,'pair':pair})
    return {'checkpoint':'S2-COMP-02C20A YR-incidence collision source census','source_state_index':sid,
            'definitions':{'Y':'node union actor','R':'target minus actor','delta':'actor minus (node union target)','incidence_key':'exact frozenset(incident_mask_keys(delta, fw))'},
            'outcome_source':'02C19 canonical oracle bits; parent theorem census independently established generator_mismatch=0 and local/global compatibility_mismatch=0',
            'totals':dict(st),'witnesses':witnesses}
