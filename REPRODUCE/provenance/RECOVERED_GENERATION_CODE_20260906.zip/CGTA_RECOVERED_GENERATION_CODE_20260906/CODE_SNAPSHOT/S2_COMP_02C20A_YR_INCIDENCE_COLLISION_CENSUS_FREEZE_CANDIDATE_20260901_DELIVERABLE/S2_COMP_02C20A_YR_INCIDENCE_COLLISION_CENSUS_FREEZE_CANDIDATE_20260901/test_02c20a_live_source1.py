from __future__ import annotations
import sys
sys.dont_write_bytecode=True
import argparse, hashlib, json, subprocess, sys, tempfile
from pathlib import Path
import orjson
from collision_core import analyze_source_data
from s2comp02c20a_env import env02c20a

EXPECTED_ORACLE1='6e51ac07c30cf552b96de02ae5d81669d09556db69b448e7b484ed60dd647d0a'
def sha(p):
 h=hashlib.sha256();
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--02c19',required=True); ap.add_argument('--02c18',required=True); ap.add_argument('--02c9',required=True); a=ap.parse_args()
 here=Path(__file__).resolve().parent
 with env02c20a(a.__dict__['02c19'],a.__dict__['02c18'],a.__dict__['02c9']) as E:
  with tempfile.TemporaryDirectory(prefix='02c20a_live1_') as td:
   td=Path(td); fresh_oracle=td/'oracle1.json'
   cmd=[sys.executable,str(E['root']/'build_02c19_d1_oracle_shard.py'),'--02c18',str(E['p18']),'--02c9',str(E['p9']),'--sources','1','--output',str(fresh_oracle)]
   subprocess.run(cmd,cwd=E['root'],check=True)
   if sha(fresh_oracle)!=EXPECTED_ORACLE1: raise AssertionError('fresh source-1 oracle hash mismatch')
   d=orjson.loads(fresh_oracle.read_bytes()); src=d['sources'][0]
   with E['parent_env'].env02c19_d1(E['p18'],E['p9']) as pe:
    with pe['env02c12']() as (frozen_env,_,_):
     with frozen_env() as outer:
      with outer.frozen.frozen_env() as env:
       import finite_window_classification as fw
       import c07d3e_component_viability as cv
       result=analyze_source_data(src,pe['decider'],fw,env,cv,True)
   fresh=orjson.dumps(result,option=orjson.OPT_SORT_KEYS|orjson.OPT_INDENT_2)+b'\n'
   frozen=(here/'02C20A_SOURCE_1.json').read_bytes()
   if fresh!=frozen: raise AssertionError('fresh source-1 collision census is not byte-identical')
   t=result['totals']
   assert t['partial_directions']==11743 and t['yr_groups']==9745 and t['multi_direction_yr_groups']==1404
   assert t['multi_delta_yr_groups']==1303 and t['multi_incidence_yr_groups']==1303
   assert t['mixed_geometry_yr_groups']==0 and t['mixed_compatibility_yr_groups']==0 and t['same_incidence_mixed_compatibility_groups']==0 and t['mixed_support_yr_groups']==0
   assert t['geometry_rows_recomputed_live']==3402
   for w in result['witnesses']:
    for r in w['pair']:
     assert r['compatible'] == (len(r['bad_incident_masks'])==0)
   print('PASS: fresh source-1 oracle rebuilt from 02C18/02C9; 3,402 collision directions geometry-recomputed; collision census byte-identical; witness bad-mask emptiness agrees with C')
if __name__=='__main__': main()
