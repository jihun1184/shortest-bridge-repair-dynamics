from pathlib import Path
ROOT=Path(__file__).resolve().parent
bad=[]
needles=("/mnt"+"/data/", "/ho"+"me/")
for p in ROOT.rglob("*"):
 if p.is_dir() and p.name=="__pycache__": bad.append(str(p.relative_to(ROOT)))
 if p.is_file() and p.suffix==".pyc": bad.append(str(p.relative_to(ROOT)))
 if p.is_file() and p.name!="SHA256SUMS.txt" and p.suffix.lower() in {".py",".md",".sh",".json",".txt"}:
  s=p.read_text(errors="ignore")
  if any(n in s for n in needles): bad.append(f"absolute-path:{p.relative_to(ROOT)}")
if bad: raise SystemExit("FAIL hygiene: "+repr(bad))
print("PASS: no pycache/pyc or machine-specific absolute-path leaks")
