from __future__ import annotations
import sys
sys.dont_write_bytecode=True
import argparse, json
from pathlib import Path
import orjson
from collision_core import analyze_source_data
from s2comp02c20a_env import env02c20a

def pick_source(root,sid,oracle_override=None):
    if oracle_override: d=orjson.loads(Path(oracle_override).read_bytes())
    else:
        name='02C19_D1_ORACLE_1_113.json' if sid in {1,2,4,7,40,41,112,113} else f'02C19_D1_ORACLE_{sid}.json'; d=orjson.loads((root/name).read_bytes())
    m=[s for s in d['sources'] if int(s['source_state_index'])==sid]
    if len(m)!=1: raise AssertionError(f'exactly one source {sid} required')
    return m[0]

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--02c19',required=True); ap.add_argument('--02c18',required=True); ap.add_argument('--02c9',required=True); ap.add_argument('--source',required=True,type=int); ap.add_argument('--output',required=True); ap.add_argument('--oracle'); ap.add_argument('--verify-geometry-live',action='store_true'); a=ap.parse_args()
    with env02c20a(a.__dict__['02c19'],a.__dict__['02c18'],a.__dict__['02c9']) as E:
        src=pick_source(E['root'],a.source,a.oracle)
        with E['parent_env'].env02c19_d1(E['p18'],E['p9']) as pe:
            with pe['env02c12']() as (frozen_env,_,_):
                with frozen_env() as outer:
                    with outer.frozen.frozen_env() as env:
                        import finite_window_classification as fw
                        import c07d3e_component_viability as cv
                        r=analyze_source_data(src,pe['decider'],fw,env,cv,a.verify_geometry_live)
    Path(a.output).write_bytes(orjson.dumps(r,option=orjson.OPT_SORT_KEYS|orjson.OPT_INDENT_2)+b'\n'); print(json.dumps({'output':a.output,'source':a.source,'totals':r['totals']},indent=2,sort_keys=True))
    t=r['totals']
    if t['mixed_compatibility_yr_groups'] or t['mixed_support_yr_groups'] or t['same_incidence_mixed_compatibility_groups'] or t['mixed_geometry_yr_groups']: raise SystemExit(1)
if __name__=='__main__': main()
