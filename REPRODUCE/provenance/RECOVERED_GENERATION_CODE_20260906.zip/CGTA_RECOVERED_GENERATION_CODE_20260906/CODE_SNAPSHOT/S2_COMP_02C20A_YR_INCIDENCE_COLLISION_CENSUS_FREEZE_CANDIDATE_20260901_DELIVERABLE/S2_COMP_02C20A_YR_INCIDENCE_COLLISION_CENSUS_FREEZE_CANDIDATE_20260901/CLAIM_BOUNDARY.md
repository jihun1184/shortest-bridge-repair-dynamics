# Claim boundary

Status: **BOUNDED_EXHAUSTIVE_COLLISION_CENSUS_CLOSED** for the frozen 02C19-D1 partial domain only.

The census exhausts all 3,916,557 partial ordered-overlap directions and groups them by the exact pair `(Y,R)`, where `Y=node union actor` and `R=target minus actor`.

Observed within this frozen scope:

- 3,381,730 distinct `(Y,R)` classes;
- 399,268 classes contain multiple directions;
- 373,356 collision classes contain multiple literal `Delta` values;
- all 373,356 also contain multiple **exact** `frozenset(incident_mask_keys(Delta,fw))` values;
- 0 classes show mixed compatibility;
- 0 classes show mixed support;
- 0 classes show same-incidence / mixed-compatibility;
- no observed `different Delta / same I(Delta)` collision in this scope.

Therefore `(Y,R)` is an **empirically sufficient outcome key on the frozen D1 domain**. This package does not claim that `(Y,R)` is minimal, does not prove the result for D2/deeper histories or arbitrary states, and does not claim global injectivity of `Delta -> I(Delta)`.

Geometry is structurally a function of `(Y,R)` in the frozen decider. In addition, source 1 recomputes all 3,402 directions belonging to same-`(Y,R)` collision classes through `chain_gap_exists_compiled` and obtains zero mixed-geometry classes.
