#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
if [ "$#" -ne 4 ]; then echo "usage: $0 02C19.zip 02C18.zip 02C9.zip OUTDIR" >&2; exit 2; fi
P19="$1"; P18="$2"; P9="$3"; OUT="$4"; HERE="$(cd "$(dirname "$0")" && pwd)"
rm -rf "$OUT"; mkdir -p "$OUT"
python "$HERE/run_02c20a_full_census.py" --02c19 "$P19" --02c18 "$P18" --02c9 "$P9" --out-dir "$OUT"
# overwrite source 1 with the stronger live-geometry variant used by the freeze
python "$HERE/analyze_02c20a_source.py" --02c19 "$P19" --02c18 "$P18" --02c9 "$P9" --source 1 --verify-geometry-live --output "$OUT/02C20A_SOURCE_1.json"
python "$HERE/merge_02c20a_collision_census.py" --inputs "$OUT"/02C20A_SOURCE_1.json "$OUT"/02C20A_SOURCE_2.json "$OUT"/02C20A_SOURCE_4.json "$OUT"/02C20A_SOURCE_7.json "$OUT"/02C20A_SOURCE_40.json "$OUT"/02C20A_SOURCE_41.json "$OUT"/02C20A_SOURCE_112.json "$OUT"/02C20A_SOURCE_113.json "$OUT"/02C20A_SOURCE_114.json "$OUT"/02C20A_SOURCE_115.json --output "$OUT/02C20A_YR_INCIDENCE_COLLISION_CENSUS.json"
for s in 1 2 4 7 40 41 112 113 114 115; do cmp "$OUT/02C20A_SOURCE_${s}.json" "$HERE/02C20A_SOURCE_${s}.json"; done
cmp "$OUT/02C20A_YR_INCIDENCE_COLLISION_CENSUS.json" "$HERE/02C20A_YR_INCIDENCE_COLLISION_CENSUS.json"
echo 'PASS: full 02C20A collision census rebuild byte-identical to frozen source shards and aggregate'
