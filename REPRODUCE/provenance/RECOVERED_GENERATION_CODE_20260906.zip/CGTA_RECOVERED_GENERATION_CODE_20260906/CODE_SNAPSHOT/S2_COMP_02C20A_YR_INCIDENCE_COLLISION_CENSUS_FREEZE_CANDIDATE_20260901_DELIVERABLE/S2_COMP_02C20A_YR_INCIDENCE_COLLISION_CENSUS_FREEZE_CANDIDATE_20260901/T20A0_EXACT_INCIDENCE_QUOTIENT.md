# T20A.0 — Exact incidence quotient (frozen semantics)

For a voxel set `Delta`, the frozen implementation satisfies

`incident_mask_keys(Delta, fw) = I(Delta) = {m : S(m) intersects Delta}`.

The equivalence follows from the exact inverse pairs already audited in the predecessor semantics:

- `edge_cands(m)` <-> `edge_sites_for_voxel(v)` for Q2 edge masks;
- `vertex_cands(m)` <-> `voxel_corners(v)` for Q3 vertex masks.

Hence local final compatibility factorizes exactly as

`C(F, Delta) = 1[ Bad(F) intersect I(Delta) is empty ]`.

This is a code/geometry fact, not a new empirical claim of 02C20A-1. It does **not** imply that `I(Delta)` is minimal, nor that the map `Delta -> I(Delta)` is globally injective.
