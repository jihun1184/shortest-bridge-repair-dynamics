from __future__ import annotations
import hashlib, importlib.util, os, sys, tempfile, zipfile
from contextlib import contextmanager
from pathlib import Path

P19_NAME='S2_COMP_02C19_D1_DEEP_HISTORY_DECISION_CENSUS_FREEZE_20260831.zip'
P19_SHA256='47a3cabdeb2300de96906415c7cee21b8a731da3d3cdb7bf7fee78e38804f20b'
P19_ROOT='S2_COMP_02C19_D1_DEEP_HISTORY_DECISION_CENSUS_FREEZE_20260831'
P18_SHA256='623b1a639b4549001c9b0091b5d3cb0dee4401d2b3afa54706f307c0508c521b'
P9_SHA256='4ce99f3bb724b5da3b2731d3c60c82d8103713768e715e855585ea5d7c2f7a19'
ORACLE_ALL_SHA256='740c00611ba1b408f8c9e97fc90264961b5381c357139c9b7b66e2d55be6d9ca'
FULL_CENSUS_SHA256='6961e9782a0db3bf76e80242ecde2b173e0fcda0a40712eba6e40191360c1d09'
REGISTRY_SHA256='ef3a60d9f1cce0d5bddcaa6fe8c74e84bb5347c0edfd9c28afb3d51d429f4b92'


def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()


def _checked(path, expected, label):
    p=Path(path).expanduser().resolve()
    if not p.is_file(): raise FileNotFoundError(f'{label} not found: {p}')
    got=sha256(p)
    if got!=expected: raise AssertionError(f'{label} hash mismatch: expected {expected}, got {got}')
    return p

@contextmanager
def env02c20a(p19, p18, p9):
    p19=_checked(p19,P19_SHA256,'02C19'); p18=_checked(p18,P18_SHA256,'02C18'); p9=_checked(p9,P9_SHA256,'02C9')
    old=sys.dont_write_bytecode; sys.dont_write_bytecode=True
    with tempfile.TemporaryDirectory(prefix='s2comp02c20a_') as td:
        td=Path(td)
        with zipfile.ZipFile(p19) as z: z.extractall(td/'p19')
        root=td/'p19'/P19_ROOT
        if not root.is_dir(): raise RuntimeError('02C19 extraction root missing')
        checks={'oracle_all.json':ORACLE_ALL_SHA256,'02C19_D1_FULL_DECISION_CENSUS.json':FULL_CENSUS_SHA256,'02C19_D1_SCOPE_REGISTRY.json':REGISTRY_SHA256}
        for name,expected in checks.items():
            got=sha256(root/name)
            if got!=expected: raise AssertionError(f'02C19 embedded {name} hash mismatch')
        sys.path.insert(0,str(root))
        try:
            spec=importlib.util.spec_from_file_location('_s2comp02c19_d1_env_20a',root/'s2comp02c19_d1_env.py')
            mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
            yield {'root':root,'parent_env':mod,'p18':p18,'p9':p9}
        finally:
            try: sys.path.remove(str(root))
            except ValueError: pass
            sys.dont_write_bytecode=old
