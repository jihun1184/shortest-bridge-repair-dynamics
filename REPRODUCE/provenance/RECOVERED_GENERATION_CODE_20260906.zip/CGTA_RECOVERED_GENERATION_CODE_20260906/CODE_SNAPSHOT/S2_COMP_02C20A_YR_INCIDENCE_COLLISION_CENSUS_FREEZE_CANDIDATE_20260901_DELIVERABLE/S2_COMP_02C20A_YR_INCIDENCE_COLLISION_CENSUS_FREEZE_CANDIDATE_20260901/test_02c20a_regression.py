from __future__ import annotations
import sys
sys.dont_write_bytecode=True
import argparse, hashlib, json, subprocess, sys, tempfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
EXPECTED_TOTALS={'partial_directions':3916557,'yr_groups':3381730,'multi_direction_yr_groups':399268,'multi_delta_yr_groups':373356,'multi_incidence_yr_groups':373356,'multi_delta_single_incidence_yr_groups':0,'diff_delta_same_incidence_groups':0,'diff_incidence_same_compatibility_groups':373356,'diff_incidence_same_compatibility_true_groups':336298,'diff_incidence_same_compatibility_false_groups':37058,'diff_incidence_mixed_compatibility_groups':0,'mixed_compatibility_yr_groups':0,'mixed_support_yr_groups':0,'same_incidence_mixed_compatibility_groups':0,'mixed_geometry_yr_groups':0,'geometry_rows_recomputed_live':3402}
EXPECTED_HASHES={}
def sha(p):
 h=hashlib.sha256();
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--live-source1',action='store_true'); ap.add_argument('--02c19'); ap.add_argument('--02c18'); ap.add_argument('--02c9'); a=ap.parse_args()
 # hashes populated in FROZEN_HASHES.json so the test is readable and externally inspectable
 exp=json.loads((HERE/'FROZEN_HASHES.json').read_text())
 for name,h in exp.items():
  got=sha(HERE/name)
  if got!=h: raise AssertionError(f'hash mismatch {name}: {got}')
 d=json.loads((HERE/'02C20A_YR_INCIDENCE_COLLISION_CENSUS.json').read_text())
 for k,v in EXPECTED_TOTALS.items():
  if int(d['totals'].get(k,0))!=v: raise AssertionError((k,d['totals'].get(k),v))
 for k in ('mixed_geometry_yr_groups','mixed_compatibility_yr_groups','mixed_support_yr_groups','same_incidence_mixed_compatibility_groups'):
  if int(d['hard_regression_gates'][k])!=0: raise AssertionError(k)
 with tempfile.TemporaryDirectory(prefix='02c20a_merge_') as td:
  out=Path(td)/'merged.json'; inputs=[str(HERE/f'02C20A_SOURCE_{s}.json') for s in (1,2,4,7,40,41,112,113,114,115)]
  subprocess.run([sys.executable,str(HERE/'merge_02c20a_collision_census.py'),'--inputs',*inputs,'--output',str(out)],check=True)
  if out.read_bytes()!=(HERE/'02C20A_YR_INCIDENCE_COLLISION_CENSUS.json').read_bytes(): raise AssertionError('deterministic merge not byte-identical')
 subprocess.run([sys.executable,str(HERE/'check_hygiene.py')],check=True)
 if a.live_source1:
  if not (a.__dict__['02c19'] and a.__dict__['02c18'] and a.__dict__['02c9']): raise SystemExit('--live-source1 requires --02c19 --02c18 --02c9')
  subprocess.run([sys.executable,str(HERE/'test_02c20a_live_source1.py'),'--02c19',a.__dict__['02c19'],'--02c18',a.__dict__['02c18'],'--02c9',a.__dict__['02c9']],check=True)
 print('PASS: frozen hashes, exact totals, hard gates, deterministic merge, hygiene'+(' + live source-1 raw gate' if a.live_source1 else ''))
if __name__=='__main__': main()
