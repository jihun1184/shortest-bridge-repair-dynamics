from __future__ import annotations
import sys
sys.dont_write_bytecode=True
import argparse, json
from collections import Counter
from pathlib import Path
import orjson
EXPECTED={1,2,4,7,40,41,112,113,114,115}
SUM_FIELDS={'partial_directions','yr_groups','multi_direction_yr_groups','mixed_compatibility_yr_groups','mixed_support_yr_groups','multi_delta_yr_groups','multi_incidence_yr_groups','multi_delta_single_incidence_yr_groups','diff_delta_same_incidence_groups','same_incidence_mixed_compatibility_groups','diff_incidence_same_compatibility_groups','diff_incidence_same_compatibility_true_groups','diff_incidence_same_compatibility_false_groups','diff_incidence_mixed_compatibility_groups','mixed_geometry_yr_groups','geometry_rows_recomputed_live'}
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--inputs',nargs='+',required=True); ap.add_argument('--output',required=True); a=ap.parse_args()
 rows=[orjson.loads(Path(p).read_bytes()) for p in a.inputs]; ids={int(r['source_state_index']) for r in rows}
 if ids!=EXPECTED: raise AssertionError(f'source set mismatch: {ids}')
 rows.sort(key=lambda r:int(r['source_state_index'])); total=Counter(); witnesses=[]
 for r in rows:
  for k,v in r['totals'].items():
   if k in SUM_FIELDS: total[k]+=int(v)
  witnesses.extend(r.get('witnesses',[]))
 if total['partial_directions']!=3916557: raise AssertionError(total)
 hard={'mixed_geometry_yr_groups':total['mixed_geometry_yr_groups'],'mixed_compatibility_yr_groups':total['mixed_compatibility_yr_groups'],'mixed_support_yr_groups':total['mixed_support_yr_groups'],'same_incidence_mixed_compatibility_groups':total['same_incidence_mixed_compatibility_groups']}
 # full-scope geometry gate is structural from exact (Y,R) input identity; only source 1 is live recomputed in the frozen package.
 hard['mixed_geometry_full_scope_basis']='chain_gap_exists_compiled inputs are exactly (child=Y,residual=R); source 1 additionally recomputed every collision direction live'
 selected=[]; counts=Counter()
 for w in witnesses:
  kind=w.get('kind','unknown')
  if counts[kind]<3: selected.append(w); counts[kind]+=1
 out={'checkpoint':'S2-COMP-02C20A YR-incidence collision census','status':'BOUNDED_EXHAUSTIVE_COLLISION_CENSUS_CLOSED','scope':'all 3,916,557 partial directions of frozen 02C19-D1; no minimal sufficient statistic theorem','sources':rows,'totals':dict(total),'hard_regression_gates':hard,'witnesses':selected,'witness_policy':'up to 3 deterministic representatives per observed kind; full source files retain source-local representatives'}
 Path(a.output).write_bytes(orjson.dumps(out,option=orjson.OPT_SORT_KEYS|orjson.OPT_INDENT_2)+b'\n')
 print(json.dumps({'output':a.output,'totals':dict(total),'hard_regression_gates':hard},indent=2,sort_keys=True))
 if any(hard[k] for k in ('mixed_geometry_yr_groups','mixed_compatibility_yr_groups','mixed_support_yr_groups','same_incidence_mixed_compatibility_groups')): raise SystemExit(1)
if __name__=='__main__': main()
