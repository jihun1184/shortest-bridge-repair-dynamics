#!/usr/bin/env python3
from pathlib import Path
bad=[]
needles=[b'/' + b'home/' + b'jihun', b'/' + b'home/' + b'claude', b'/' + b'workspace/' + b'scratch']
for p in Path('.').rglob('*'):
    if p.is_dir() and p.name in {'__pycache__','.cache'}: bad.append(str(p))
    if p.is_file() and p.suffix=='.pyc': bad.append(str(p))
    if p.is_file() and p.name not in {'SHA256SUMS.txt','check_hygiene.py'}:
        b=p.read_bytes()
        for needle in needles:
            if needle in b: bad.append(f'{p}: absolute-path leak')
assert not bad,bad
print('PASS: package hygiene')
