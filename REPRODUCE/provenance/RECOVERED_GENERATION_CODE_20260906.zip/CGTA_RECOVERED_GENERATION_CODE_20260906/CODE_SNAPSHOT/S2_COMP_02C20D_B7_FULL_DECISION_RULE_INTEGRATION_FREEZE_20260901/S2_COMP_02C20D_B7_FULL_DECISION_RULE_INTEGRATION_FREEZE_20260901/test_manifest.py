#!/usr/bin/env python3
import hashlib
from pathlib import Path
root=Path('.')
rows=[]
for line in (root/'SHA256SUMS.txt').read_text().splitlines():
    if not line.strip(): continue
    h,name=line.split('  ',1); p=root/name
    assert p.is_file(),name
    assert hashlib.sha256(p.read_bytes()).hexdigest()==h,name
    rows.append(name)
print(f'PASS: manifest {len(rows)}/{len(rows)}')
