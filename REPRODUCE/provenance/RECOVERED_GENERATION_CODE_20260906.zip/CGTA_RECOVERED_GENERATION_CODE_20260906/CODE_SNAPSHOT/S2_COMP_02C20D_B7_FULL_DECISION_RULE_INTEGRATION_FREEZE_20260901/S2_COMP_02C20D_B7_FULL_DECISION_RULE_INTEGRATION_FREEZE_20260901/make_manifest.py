#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
root=Path('.')
exclude={'SHA256SUMS.txt','MANIFEST.json'}
files=sorted(p for p in root.rglob('*') if p.is_file() and p.name not in exclude)
rows=[]
for p in files:
    rel=p.relative_to(root).as_posix(); h=hashlib.sha256(p.read_bytes()).hexdigest(); rows.append((h,rel,p.stat().st_size))
Path('SHA256SUMS.txt').write_text(''.join(f'{h}  {n}\n' for h,n,_ in rows))
Path('MANIFEST.json').write_text(json.dumps({'payload_count':len(rows),'files':[{'path':n,'sha256':h,'size_bytes':s} for h,n,s in rows]},indent=2,sort_keys=True)+'\n')
print(f'wrote manifest for {len(rows)} payload files')
