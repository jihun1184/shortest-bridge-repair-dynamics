# S2-COMP-02C20D-B7 full decision-rule integration

This package closes the 02C20D-B frozen-D1 geometry line by integrating B4, B5,
and B6 into a single dispatch rule.

Recompute the result from the embedded parent snapshots:

```bash
python run_b7_integration.py \
  --b4 PARENT_B4_AGGREGATE.json \
  --b5 PARENT_B5_AGGREGATE.json \
  --b6 PARENT_B6_RESULT.json \
  --b5-source-dir . \
  --output 02C20D_B7_FULL_DECISION_RULE.json
python test_b7_regression.py
python check_hygiene.py
```

The package does not claim a universal geometry theorem outside frozen D1.
