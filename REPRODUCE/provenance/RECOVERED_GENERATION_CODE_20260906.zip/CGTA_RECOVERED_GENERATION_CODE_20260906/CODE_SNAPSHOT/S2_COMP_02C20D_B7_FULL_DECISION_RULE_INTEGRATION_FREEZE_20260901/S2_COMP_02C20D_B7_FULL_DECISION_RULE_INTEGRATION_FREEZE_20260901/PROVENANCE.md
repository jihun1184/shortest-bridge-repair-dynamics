# Provenance

B7 integrates three frozen parents without changing their semantics:

- B4 full rho_R collision/ChainGap census: all 37,058 incompatible classes and 117 buckets.
- B5 canonical quotient gate: all 293 classes in the only four B4 mixed buckets.
- B6 theorem gate: adjacency-saturation lemma and complete B5-scope saturation audit.

The package embeds exact copies of the three parent result JSONs and all ten B5
source shards.  `run_b7_integration.py` verifies the parent result hashes before
constructing the decision table and independently re-evaluates adjacency
saturation on every one of the 293 dynamic-branch classes.
