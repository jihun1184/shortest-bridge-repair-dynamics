from __future__ import annotations

import hashlib
import sys
import tempfile
import zipfile
from pathlib import Path


HERE = Path(__file__).resolve().parent
P17_NAME = "S2_COMP_02C17_COMBINED_TARGET_OVERLAP_DECISION_FREEZE_20260831.zip"
P17_SHA256 = "06ab1ea847686cc07c8cea9ddd9b52259bb316c4e2fec90460b67a2ee7dc42d2"
P17_ROOT = "S2_COMP_02C17_COMBINED_TARGET_OVERLAP_DECISION_FREEZE_20260831"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


P17_ZIP = HERE / "source" / P17_NAME
if sha256(P17_ZIP) != P17_SHA256:
    raise AssertionError("02C17 predecessor hash mismatch")

_TEMP = tempfile.TemporaryDirectory(prefix="s2comp02c18_")
_ROOT = Path(_TEMP.name)
with zipfile.ZipFile(P17_ZIP) as archive:
    archive.extractall(_ROOT)
_P17 = _ROOT / P17_ROOT
if not _P17.is_dir():
    raise RuntimeError("02C17 extraction failed")

sys.dont_write_bytecode = True
sys.path.insert(0, str(_P17))

from s2comp02c17_env import env02c12  # noqa: E402
from combined_decider import (  # noqa: E402
    incident_mask_keys,
    mask_bad,
    monotone_segment_reachable,
    residual_chain,
)
