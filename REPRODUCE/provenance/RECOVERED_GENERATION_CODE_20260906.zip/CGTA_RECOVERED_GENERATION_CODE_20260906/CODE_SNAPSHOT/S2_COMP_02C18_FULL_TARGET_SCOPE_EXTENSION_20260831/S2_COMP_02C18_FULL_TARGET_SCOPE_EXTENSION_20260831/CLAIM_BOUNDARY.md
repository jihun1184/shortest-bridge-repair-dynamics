# Claim Boundary

## Closed

- Every parent-supported canonical N2 target in the same ten frozen one-step
  parent states is included.
- Every ordered overlap direction between distinct parent actions is included.
- Full supply and partial residual are exhaustive branches.
- The 02C17 combined law matches the child canonical generator in 300,638 of
  300,638 directions.
- Local incident-mask compatibility matches global `has_fail` in every partial
  direction.
- The old 26-target / 1,639-direction 02C17 scope is reproduced exactly.

## Not claimed

- Exhaustion of all possible source states or ranks.
- Validity at deeper natural-closure histories beyond the frozen one-step
  parents.
- Extension to non-N2 predicates.
- A new mechanism theorem beyond the inherited 02C15--02C17 results.
- Stability of `action_id`, certificate snapshot ID, or exact carrier key as a
  target identity across states.

## Identity and cache discipline

Targets are compared by addition set and transported by residual literal.
Generator results are scoped per child. Geometry caches are scoped per child
and keyed by the residual addition set; compatibility caches are keyed by the
final union state. No cache is shared across unresolved target identities.
