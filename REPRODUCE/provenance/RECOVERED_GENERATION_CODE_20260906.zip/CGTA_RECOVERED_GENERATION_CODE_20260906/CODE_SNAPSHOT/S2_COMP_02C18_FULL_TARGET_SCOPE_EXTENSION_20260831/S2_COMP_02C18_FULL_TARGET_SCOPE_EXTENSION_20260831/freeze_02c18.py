from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path


HERE = Path(__file__).resolve().parent
OUTPUT = HERE.parent / f"{HERE.name}.zip"
FIXED_TIME = (2026, 8, 31, 0, 0, 0)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def payload_files(root):
    return sorted(
        path
        for path in root.rglob("*")
        if path.is_file() and path.name != "SHA256SUMS.txt"
    )


def write_manifest():
    rows = []
    for path in payload_files(HERE):
        rows.append(f"{sha256(path)}  {path.relative_to(HERE).as_posix()}")
    (HERE / "SHA256SUMS.txt").write_text("\n".join(rows) + "\n")


def verify_manifest(root):
    for line in (root / "SHA256SUMS.txt").read_text().splitlines():
        expected, relative = line.split("  ", 1)
        actual = sha256(root / relative)
        if actual != expected:
            raise AssertionError((relative, expected, actual))


def build_zip():
    if OUTPUT.exists():
        OUTPUT.unlink()
    with zipfile.ZipFile(OUTPUT, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(p for p in HERE.rglob("*") if p.is_file()):
            relative = Path(HERE.name) / path.relative_to(HERE)
            info = zipfile.ZipInfo(relative.as_posix(), FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())


def main():
    forbidden = list(HERE.rglob("*.pyc")) + list(HERE.rglob("__pycache__"))
    if forbidden:
        raise AssertionError(forbidden)
    for path in payload_files(HERE):
        if path.suffix in {".py", ".md", ".json", ".txt"}:
            data = path.read_bytes()
            workspace_marker = b"/" + b"workspace/"
            home_marker = b"/" + b"home/"
            if workspace_marker in data or home_marker in data:
                raise AssertionError(f"absolute-path leak: {path}")

    write_manifest()
    verify_manifest(HERE)
    build_zip()

    with tempfile.TemporaryDirectory(prefix="s2comp02c18_freeze_") as temp:
        root = Path(temp)
        with zipfile.ZipFile(OUTPUT) as archive:
            archive.extractall(root)
        extracted = root / HERE.name
        verify_manifest(extracted)
        process = subprocess.run(
            [sys.executable, "test_02c18_regression.py"],
            cwd=extracted,
            env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
            text=True,
            capture_output=True,
        )
        if process.returncode:
            print(process.stdout)
            print(process.stderr, file=sys.stderr)
            raise SystemExit(process.returncode)
        verify_manifest(extracted)
        if list(extracted.rglob("*.pyc")) or list(extracted.rglob("__pycache__")):
            raise AssertionError("cache artifact created during fresh regression")
        print(process.stdout.strip())

    print(f"payload_files={len(payload_files(HERE))}")
    print(f"physical_files={len(payload_files(HERE)) + 1}")
    print(f"zip={OUTPUT.name}")
    print(f"zip_sha256={sha256(OUTPUT)}")
    print(f"zip_bytes={OUTPUT.stat().st_size}")


if __name__ == "__main__":
    main()
