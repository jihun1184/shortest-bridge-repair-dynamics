# Recommended 02C19 Boundary

The one-step full-target scope is closed. The next boundary should extend depth,
not mechanism:

> Does the combined residual decision law remain exact along deeper natural-
> closure histories when targets are tracked by addition-set/residual lineage?

Recommended order:

1. Start from the same ten one-step parents and enumerate the next natural
   closure layer.
2. Store path identity separately from state identity; do not deduplicate
   distinct parent-actor histories merely because they reach the same state.
3. At each history node, enumerate all parent-supported N2 targets and all
   overlapping actors.
4. Track each target by its current addition set and transported residual, not
   by action or certificate IDs.
5. Reuse the 02C18 oracle/decider separation and record the first mismatch by
   full-supply, geometry, or compatibility gate.
6. Freeze depth 1 before increasing the depth cap. Only after the N2 depth audit
   closes should non-N2 predicates be considered.
