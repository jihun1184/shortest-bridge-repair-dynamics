from __future__ import annotations

import json
import os
from collections import Counter
from pathlib import Path

from full_scope_decider import (
    compile_child_geometry,
    decide_partial,
)
from s2comp02c18_env import env02c12


HERE = Path(__file__).resolve().parent


def decode_oracle(code):
    return {
        "partial": bool(code & 1),
        "supported": bool(code & 2),
        "compatible": bool(code & 4),
    }


def main():
    fixture = json.loads((HERE / "02C18_FULL_SCOPE_INPUT_ORACLE.json").read_text())
    result = {
        "checkpoint": "S2-COMP-02C18 full-target combined decision census",
        "scope": fixture["scope"],
        "decision_path": (
            "full supply or compiled ChainGap plus delta-incident Q2/Q3 update"
        ),
        "forbidden_decision_calls": {
            "canonical_actions": False,
            "n2_target_index": False,
            "raw_target_realizations": False,
            "global_has_fail": False,
        },
        "source_summaries": [],
        "first_mismatches": [],
    }
    totals = Counter()
    legacy_slice_totals = Counter()

    with env02c12() as (frozen_env, _, _):
        with frozen_env() as outer:
            with outer.frozen.frozen_env() as env:
                import finite_window_classification as fw
                import c07d3e_component_viability as cv

                if os.environ.get("S2COMP_02C18_FORBIDDEN_CALL_TRAPS") == "1":
                    def forbidden(*args, **kwargs):
                        raise AssertionError(
                            "forbidden generator/global compatibility call in theorem path"
                        )

                    env.pred["canonical_actions"] = forbidden
                    fw.has_fail = forbidden

                for source in fixture["sources"]:
                    source_index = source["source_state_index"]
                    parent = frozenset(tuple(p) for p in source["parent"])
                    actions = tuple(
                        frozenset(tuple(p) for p in action)
                        for action in source["actions"]
                    )
                    provenance_counts = source["action_certificate_snapshot_counts"]
                    by_actor = {}
                    for actor_index, target_index, code in source["directions"]:
                        by_actor.setdefault(actor_index, []).append((target_index, code))

                    source_totals = Counter()
                    for actor_index, actor_rows in by_actor.items():
                        actor = actions[actor_index]
                        child = frozenset(parent | actor)
                        child_certs = tuple(
                            c
                            for c in env.pred["extract_certificates"](child, env.api)
                            if c.predicate == "N2_facet_connectivity"
                        )
                        endpoint_records = compile_child_geometry(child_certs, cv)
                        geometry_cache = {}
                        compatibility_cache = {}

                        for target_index, code in actor_rows:
                            target = actions[target_index]
                            oracle = decode_oracle(code)
                            source_totals["directions"] += 1
                            if not oracle["partial"]:
                                source_totals["fully_supplied"] += 1
                                source_totals["support_or_fulfilled"] += 1
                                if provenance_counts[target_index] > 1:
                                    legacy_slice_totals["fully_supplied"] += 1
                                    legacy_slice_totals["directions"] += 1
                                continue

                            residual_key = tuple(sorted(target - actor))
                            final_key = tuple(sorted(actor | target))
                            if residual_key not in geometry_cache:
                                got = decide_partial(
                                    parent,
                                    actor,
                                    target,
                                    child,
                                    endpoint_records,
                                    fw,
                                )
                                geometry_cache[residual_key] = (
                                    got["geometry"],
                                    got["geometry_witness"],
                                )
                            else:
                                geometry, witness = geometry_cache[residual_key]
                                got = decide_partial(
                                    parent,
                                    actor,
                                    target,
                                    child,
                                    (),
                                    fw,
                                )
                                got["geometry"] = geometry
                                got["geometry_witness"] = witness
                                got["supported_action"] = (
                                    geometry and got["local_compatible"]
                                )
                                if got["supported_action"]:
                                    got["decision"] = "supported_residual"
                                elif geometry:
                                    got["decision"] = "local_incompatible"

                            compatibility_cache.setdefault(
                                final_key, got["local_compatible"]
                            )
                            if compatibility_cache[final_key] != got["local_compatible"]:
                                raise AssertionError("local compatibility cache conflict")

                            source_totals["partial"] += 1
                            source_totals[got["decision"]] += 1
                            source_totals["geometry_positive"] += int(got["geometry"])
                            source_totals["local_compatible"] += int(
                                got["local_compatible"]
                            )
                            source_totals["support_or_fulfilled"] += int(
                                got["supported_action"]
                            )
                            source_totals["generator_mismatch"] += int(
                                got["supported_action"] != oracle["supported"]
                            )
                            source_totals["compatibility_mismatch"] += int(
                                got["local_compatible"] != oracle["compatible"]
                            )
                            if (
                                got["supported_action"] != oracle["supported"]
                                or got["local_compatible"] != oracle["compatible"]
                            ) and len(result["first_mismatches"]) < 10:
                                result["first_mismatches"].append(
                                    {
                                        "source_state_index": source_index,
                                        "actor_index": actor_index,
                                        "target_index": target_index,
                                        "actor": tuple(sorted(actor)),
                                        "target": tuple(sorted(target)),
                                        "oracle": oracle,
                                        "got": got,
                                    }
                                )
                            if provenance_counts[target_index] > 1:
                                legacy_slice_totals["directions"] += 1
                                legacy_slice_totals[got["decision"]] += 1

                    result["source_summaries"].append(
                        {
                            "source_state_index": source_index,
                            "totals": dict(source_totals),
                        }
                    )
                    totals.update(source_totals)
                    print(
                        json.dumps(
                            {
                                "source": source_index,
                                "totals": dict(source_totals),
                            },
                            sort_keys=True,
                        ),
                        flush=True,
                    )

    result["totals"] = dict(totals)
    result["legacy_26_multi_provenance_target_slice"] = dict(
        legacy_slice_totals
    )
    result["mismatch_count"] = totals["generator_mismatch"]
    result["compatibility_mismatch_count"] = totals["compatibility_mismatch"]
    output = HERE / "02C18_FULL_SCOPE_DECISION_CENSUS.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "output": output.name,
                "totals": result["totals"],
                "first_mismatch_count": len(result["first_mismatches"]),
            },
            indent=2,
            sort_keys=True,
        )
    )
    if totals["generator_mismatch"] or totals["compatibility_mismatch"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
