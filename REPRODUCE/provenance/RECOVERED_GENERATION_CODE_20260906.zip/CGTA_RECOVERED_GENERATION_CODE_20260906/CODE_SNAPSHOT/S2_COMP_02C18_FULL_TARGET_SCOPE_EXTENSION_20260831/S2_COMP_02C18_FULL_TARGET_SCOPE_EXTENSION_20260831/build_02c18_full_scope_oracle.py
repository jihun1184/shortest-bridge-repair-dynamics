from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

from s2comp02c18_env import env02c12


HERE = Path(__file__).resolve().parent
SOURCES = (1, 2, 4, 7, 40, 41, 112, 113, 114, 115)


def additions(action):
    return tuple(sorted(tuple(p) for p in action.additions))


def main():
    result = {
        "checkpoint": "S2-COMP-02C18 full-target input/oracle fixture",
        "scope": (
            "all ordered target-overlap directions among every parent-supported "
            "canonical N2 action in the frozen 10 source states"
        ),
        "oracle_boundary": (
            "parent and child canonical_actions plus global has_fail are used only "
            "to construct the frozen oracle, never in the theorem decision path"
        ),
        "sources": [],
    }
    totals = Counter()

    with env02c12() as (frozen_env, _, _):
        with frozen_env() as outer:
            with outer.frozen.frozen_env() as env:
                import finite_window_classification as fw

                rows = outer.domains.load_d7b_rows(env)
                for source_index in SOURCES:
                    initial = frozenset(tuple(p) for p in rows[source_index]["state"])
                    first = env.api.atomic_actions(initial)[0]
                    parent = frozenset(
                        initial | {tuple(p) for p in first["additions"]}
                    )
                    parent_certs = tuple(
                        c
                        for c in env.pred["extract_certificates"](parent, env.api)
                        if c.predicate == "N2_facet_connectivity"
                    )
                    parent_actions = tuple(
                        a
                        for a in env.pred["canonical_actions"](
                            parent, env.api, parent_certs
                        )
                        if "N2" in a.roles
                    )
                    action_sets = tuple(frozenset(additions(a)) for a in parent_actions)
                    if len(action_sets) != len(set(action_sets)):
                        raise AssertionError(
                            (source_index, "duplicate parent N2 addition sets")
                        )

                    child_supported = []
                    child_certificate_counts = []
                    for actor_index, actor in enumerate(action_sets):
                        child = frozenset(parent | actor)
                        child_certs = tuple(
                            c
                            for c in env.pred["extract_certificates"](child, env.api)
                            if c.predicate == "N2_facet_connectivity"
                        )
                        child_actions = tuple(
                            a
                            for a in env.pred["canonical_actions"](
                                child, env.api, child_certs
                            )
                            if "N2" in a.roles
                        )
                        supported_sets = sorted({additions(a) for a in child_actions})
                        child_supported.append(supported_sets)
                        child_certificate_counts.append(len(child_certs))

                    compatible_cache = {}
                    directions = []
                    source_totals = Counter()
                    for actor_index, actor in enumerate(action_sets):
                        supported_lookup = {
                            tuple(row) for row in child_supported[actor_index]
                        }
                        for target_index, target in enumerate(action_sets):
                            if actor_index == target_index or not (actor & target):
                                continue
                            residual = frozenset(target - actor)
                            source_totals["directions"] += 1
                            if not residual:
                                directions.append([actor_index, target_index, 0])
                                source_totals["fully_supplied"] += 1
                                continue

                            final_key = tuple(sorted(actor | target))
                            if final_key not in compatible_cache:
                                compatible_cache[final_key] = not fw.has_fail(
                                    parent | actor | target
                                )
                            compatible = compatible_cache[final_key]
                            supported = tuple(sorted(residual)) in supported_lookup
                            code = 1 | (int(supported) << 1) | (int(compatible) << 2)
                            directions.append([actor_index, target_index, code])
                            source_totals["partial"] += 1
                            source_totals["oracle_supported"] += int(supported)
                            source_totals["oracle_compatible"] += int(compatible)

                    source_record = {
                        "source_state_index": source_index,
                        "parent": tuple(sorted(parent)),
                        "parent_certificate_count": len(parent_certs),
                        "actions": [tuple(sorted(a)) for a in action_sets],
                        "action_certificate_snapshot_counts": [
                            len(action.certificate_snapshot_ids)
                            for action in parent_actions
                        ],
                        "child_certificate_counts": child_certificate_counts,
                        "directions": directions,
                        "totals": dict(source_totals),
                    }
                    result["sources"].append(source_record)
                    totals.update(source_totals)
                    totals["parent_actions"] += len(action_sets)
                    totals["child_generator_calls"] += len(action_sets)
                    print(
                        json.dumps(
                            {
                                "source": source_index,
                                "actions": len(action_sets),
                                "directions": len(directions),
                                "totals": dict(source_totals),
                            },
                            sort_keys=True,
                        ),
                        flush=True,
                    )

    result["totals"] = dict(totals)
    output = HERE / "02C18_FULL_SCOPE_INPUT_ORACLE.json"
    output.write_text(json.dumps(result, separators=(",", ":")) + "\n")
    print(json.dumps({"output": output.name, "totals": result["totals"]}, indent=2))


if __name__ == "__main__":
    main()
