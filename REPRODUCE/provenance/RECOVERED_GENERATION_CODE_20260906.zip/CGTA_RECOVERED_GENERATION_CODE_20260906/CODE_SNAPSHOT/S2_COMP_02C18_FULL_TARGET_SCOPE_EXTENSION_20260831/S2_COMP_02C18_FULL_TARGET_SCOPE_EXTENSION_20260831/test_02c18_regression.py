from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path


HERE = Path(__file__).resolve().parent
EXPECTED_TOTALS = {
    "directions": 300638,
    "fully_supplied": 3188,
    "partial": 297450,
    "supported_residual": 13404,
    "local_incompatible": 903,
    "no_geometry": 223638,
    "no_geometry_and_local_incompatible": 59505,
    "geometry_positive": 14307,
    "local_compatible": 237042,
    "support_or_fulfilled": 16592,
    "generator_mismatch": 0,
    "compatibility_mismatch": 0,
}
EXPECTED_LEGACY = {
    "directions": 1639,
    "fully_supplied": 351,
    "supported_residual": 337,
    "no_geometry": 831,
    "no_geometry_and_local_incompatible": 111,
    "local_incompatible": 9,
}


def run(name, traps=False):
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
    if traps:
        env["S2COMP_02C18_FORBIDDEN_CALL_TRAPS"] = "1"
    process = subprocess.run(
        [sys.executable, name],
        cwd=HERE,
        env=env,
        capture_output=True,
        text=True,
    )
    if process.returncode:
        print(process.stdout)
        print(process.stderr, file=sys.stderr)
        raise SystemExit(process.returncode)
    return process.stdout


def main():
    oracle_path = HERE / "02C18_FULL_SCOPE_INPUT_ORACLE.json"
    census_path = HERE / "02C18_FULL_SCOPE_DECISION_CENSUS.json"
    analysis_path = HERE / "02C18_FULL_SCOPE_ANALYSIS.json"
    frozen_oracle = oracle_path.read_bytes()
    frozen_census = census_path.read_bytes()
    frozen_analysis = analysis_path.read_bytes()

    run("build_02c18_full_scope_oracle.py")
    assert oracle_path.read_bytes() == frozen_oracle
    run("run_02c18_full_scope_decider.py", traps=True)
    assert census_path.read_bytes() == frozen_census
    run("analyze_02c18_full_scope.py")
    assert analysis_path.read_bytes() == frozen_analysis

    census = json.loads(census_path.read_text())
    assert census["totals"] == EXPECTED_TOTALS
    assert census["legacy_26_multi_provenance_target_slice"] == EXPECTED_LEGACY
    assert census["first_mismatches"] == []

    # Deliberately incomplete one-gate controls must overaccept.
    assert EXPECTED_TOTALS["geometry_positive"] - EXPECTED_TOTALS[
        "supported_residual"
    ] == 903
    assert EXPECTED_TOTALS["local_compatible"] - EXPECTED_TOTALS[
        "supported_residual"
    ] == 223638
    assert EXPECTED_TOTALS["fully_supplied"] == 3188

    forbidden_names = (
        "canonical_actions(",
        "n2_target_index(",
        "raw_target_realizations(",
        "has_fail(",
    )
    decision_source = (HERE / "full_scope_decider.py").read_text()
    assert all(name not in decision_source for name in forbidden_names)
    assert not list(HERE.rglob("*.pyc"))
    assert not list(HERE.rglob("__pycache__"))
    print(
        "PASS: 300638-direction full-target reconstruction, legacy slice, "
        "byte-identical rebuild, forbidden-call traps, and negative controls"
    )


if __name__ == "__main__":
    main()
