from __future__ import annotations

import json
from pathlib import Path


HERE = Path(__file__).resolve().parent


def main():
    oracle = json.loads((HERE / "02C18_FULL_SCOPE_INPUT_ORACLE.json").read_text())
    census = json.loads((HERE / "02C18_FULL_SCOPE_DECISION_CENSUS.json").read_text())
    totals = census["totals"]
    partial = totals["partial"]
    analysis = {
        "checkpoint": "S2-COMP-02C18 full-target scope analysis",
        "scope": {
            "source_states": len(oracle["sources"]),
            "parent_supported_n2_actions": oracle["totals"]["parent_actions"],
            "ordered_overlap_directions": totals["directions"],
            "fully_supplied": totals["fully_supplied"],
            "partial_residual": partial,
        },
        "partial_two_gate": {
            "geometry_positive": totals["geometry_positive"],
            "local_compatible": totals["local_compatible"],
            "supported_residual": totals["supported_residual"],
            "geometry_only_false_positives": totals["local_incompatible"],
            "compatibility_only_false_positives": totals["no_geometry"],
            "both_gates_false": totals["no_geometry_and_local_incompatible"],
        },
        "exact_reconstruction": {
            "generator_mismatch_count": census["mismatch_count"],
            "local_vs_global_compatibility_mismatch_count": census[
                "compatibility_mismatch_count"
            ],
            "matched_directions": totals["directions"],
        },
        "legacy_02c17_slice": census[
            "legacy_26_multi_provenance_target_slice"
        ],
        "rates": {
            "fully_supplied_over_all": totals["fully_supplied"]
            / totals["directions"],
            "supported_over_partial": totals["supported_residual"] / partial,
            "geometry_positive_over_partial": totals["geometry_positive"]
            / partial,
            "local_compatible_over_partial": totals["local_compatible"]
            / partial,
        },
        "claim_status": (
            "BOUNDED_EXHAUSTIVE_CLOSED for all parent-supported N2 targets in "
            "the frozen 10 one-step parent states; no new mechanism theorem"
        ),
    }
    expected_legacy = {
        "directions": 1639,
        "fully_supplied": 351,
        "supported_residual": 337,
        "no_geometry": 831,
        "no_geometry_and_local_incompatible": 111,
        "local_incompatible": 9,
    }
    assert analysis["legacy_02c17_slice"] == expected_legacy
    assert analysis["exact_reconstruction"] == {
        "generator_mismatch_count": 0,
        "local_vs_global_compatibility_mismatch_count": 0,
        "matched_directions": 300638,
    }
    assert sum(
        analysis["partial_two_gate"][key]
        for key in (
            "supported_residual",
            "geometry_only_false_positives",
            "compatibility_only_false_positives",
            "both_gates_false",
        )
    ) == partial
    output = HERE / "02C18_FULL_SCOPE_ANALYSIS.json"
    output.write_text(json.dumps(analysis, indent=2) + "\n")
    print(json.dumps(analysis, indent=2))


if __name__ == "__main__":
    main()
