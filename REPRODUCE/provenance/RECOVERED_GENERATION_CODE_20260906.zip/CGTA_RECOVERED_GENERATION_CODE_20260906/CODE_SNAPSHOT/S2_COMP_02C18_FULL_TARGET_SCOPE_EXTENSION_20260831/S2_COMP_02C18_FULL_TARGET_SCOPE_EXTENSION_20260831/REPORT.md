# 02C18 Full-Target Scope Report

## Question

Does the 02C17 combined target-overlap decision law remain exact after removing
the restriction to the frozen 26 multi-provenance targets and admitting every
parent-supported canonical N2 target in the same ten source states?

## Answer

Yes, in the stated bounded scope. The census contains 1,988 distinct
parent-supported N2 addition sets and 300,638 ordered actor-target overlap
directions. The combined decider matches the canonical child generator in all
300,638 directions.

| Branch | Count |
| --- | ---: |
| Fully supplied | 3,188 |
| Supported residual | 13,404 |
| Geometry true, compatibility false | 903 |
| Geometry false, compatibility true | 223,638 |
| Geometry false, compatibility false | 59,505 |
| Generator mismatch | 0 |
| Local/global compatibility mismatch | 0 |

The partial branches sum to 297,450. Together with 3,188 fully supplied
directions, they exhaust the 300,638-direction domain.

## Independent roles of the two gates

Neither gate alone is sufficient. A geometry-only rule overaccepts 903 partial
directions. A compatibility-only rule overaccepts 223,638 partial directions.
These are executable negative controls, not merely differences observed after
the fact.

## Oracle/decider separation

The frozen oracle uses the canonical generator once per child state (1,988
child generator calls) and global compatibility to record ground truth. The
theorem decider receives only frozen parent/action inputs and oracle bits. For
partial residuals it extracts child N2 certificates, applies the endpoint
ChainGap criterion, and reevaluates only `Delta`-incident Q2/Q3 masks.

The decider does not call child `canonical_actions`, `n2_target_index`, raw
monotone-path enumeration, or global `has_fail`. The regression replaces
`canonical_actions` and `has_fail` with raising traps during the full decider
run.

## Legacy inclusion check

Selecting targets with more than one parent certificate snapshot reproduces
the complete 02C17 slice exactly:

| 02C17 class | Count |
| --- | ---: |
| Fully supplied | 351 |
| Supported residual | 337 |
| Geometry false, compatibility true | 831 |
| Geometry false, compatibility false | 111 |
| Geometry true, compatibility false | 9 |

This guards against an accidental change in the original 26-target domain
during scope expansion.
