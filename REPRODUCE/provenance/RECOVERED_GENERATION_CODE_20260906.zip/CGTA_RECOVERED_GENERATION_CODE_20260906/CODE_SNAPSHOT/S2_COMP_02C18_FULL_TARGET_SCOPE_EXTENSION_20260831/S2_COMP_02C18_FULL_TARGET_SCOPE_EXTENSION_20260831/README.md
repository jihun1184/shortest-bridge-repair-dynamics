# S2-COMP 02C18 — Full-Target Scope Extension

Status: **BOUNDED_EXHAUSTIVE_CLOSED — no new mechanism theorem**

02C18 removes the 02C17 restriction to 26 multi-provenance targets. It
enumerates every parent-supported canonical N2 action in the same ten frozen
one-step parent states and tests every ordered target-overlap direction.

## Closed census

```text
source states                         10
parent-supported N2 actions        1,988
ordered overlap directions       300,638
fully supplied                     3,188
partial residual                 297,450

partial residual classes:
  supported residual              13,404
  geometry yes / compatibility no    903
  geometry no / compatibility yes 223,638
  geometry no / compatibility no   59,505

generator mismatch                     0
local/global compatibility mismatch    0
```

The embedded legacy slice is exactly the 02C17 census:

```text
directions 1,639 = 351 + 337 + 831 + 111 + 9
```

## Decision boundary

For parent `Y`, actor `a`, target `b`, child `X=Y union a`, residual
`R=b\a`, final state `F=Y union a union b`, and
`Delta=a\(Y union b)`:

```text
R empty  => target is fully supplied; this is not support of an empty action.

R nonempty:
R supported at X
iff ChainGap_X(R;s,t) exists
and Bad_{I(Delta)}(F) is empty.
```

The oracle builder is allowed to call parent/child `canonical_actions` and
global `has_fail`. The theorem decider is not. Its full regression installs
runtime traps for both forbidden calls.

## Reproduce

Set `S2COMP_02C9_ZIP` to canonical 02C9 with SHA-256
`4ce99f3bb724b5da3b2731d3c60c82d8103713768e715e855585ea5d7c2f7a19`,
then run:

```bash
python test_02c18_regression.py
```

This rebuilds the 300,638-direction oracle, reruns the theorem decider with
forbidden-call traps, regenerates the analysis, and requires all frozen outputs
to be byte-identical.
