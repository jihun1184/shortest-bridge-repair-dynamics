# Inherited Theorem and 02C18 Bounded Corollary

## Inherited code-semantic theorem

Let `Y` be a parent state and let `a,b` be overlapping parent-supported N2
actions. Define

```text
X = Y union a
R = b \ a
F = Y union a union b
Delta = a \ (Y union b)
```

If `R` is nonempty, the 02C15--02C17 theorem gives

```text
R is supported at X
iff
there is a child N2 certificate and minimizing endpoint pair satisfying
ChainGap_X(R;s,t)
and
Bad_{I(Delta)}(F) is empty.
```

If `R` is empty, `b` has been fully supplied by `a`; support of an empty action
is not asserted.

The geometry equivalence is inherited from 02C15. The exact incident-mask
compatibility update is inherited from 02C16. Their combined decision law is
inherited from 02C17.

## New 02C18 bounded corollary

For all 300,638 ordered overlap directions formed by every one of the 1,988
parent-supported canonical N2 actions in the ten frozen one-step parent states,
the inherited combined law exactly reconstructs the child canonical generator.

This is a bounded exhaustive closure. It does not promote the selection of ten
states, the one-step parent construction, or the N2-only restriction into a
general theorem.
