from __future__ import annotations

from dataclasses import dataclass

from s2comp02c18_env import (
    incident_mask_keys,
    mask_bad,
    monotone_segment_reachable,
    residual_chain,
)


@dataclass(frozen=True)
class EndpointRecord:
    certificate: str
    distance: int
    pairs: tuple


def compile_child_geometry(certs, cv):
    records = []
    for cert in certs:
        left, right = cert.carrier
        distance, pairs = cv.shortest_endpoint_pairs(
            frozenset(left), frozenset(right)
        )
        records.append(
            EndpointRecord(
                certificate=cert.snapshot_id,
                distance=distance,
                pairs=tuple((tuple(s), tuple(t)) for s, t in pairs),
            )
        )
    return tuple(records)


def chain_gap_exists_compiled(child, residual, endpoint_records):
    allowed = frozenset(set(child) | set(residual))
    for record in endpoint_records:
        for s, t in record.pairs:
            chain = residual_chain(residual, s, t)
            if chain is None:
                continue
            required = (s,) + tuple(chain) + (t,)
            if all(
                monotone_segment_reachable(u, v, allowed)
                for u, v in zip(required, required[1:])
            ):
                return True, {
                    "certificate": record.certificate,
                    "s": s,
                    "t": t,
                    "distance": record.distance,
                    "ordered_residual": tuple(chain),
                }
    return False, None


def local_final_compatible(parent, actor, target, fw):
    base = frozenset(set(parent) | set(target))
    final = frozenset(set(parent) | set(actor) | set(target))
    delta = frozenset(set(actor) - set(base))
    bad = tuple(
        sorted(
            (
                key
                for key in incident_mask_keys(delta, fw)
                if mask_bad(final, *key, fw)
            ),
            key=str,
        )
    )
    return not bad, delta, bad


def decide_partial(parent, actor, target, child, endpoint_records, fw):
    residual = frozenset(set(target) - set(actor))
    if not residual:
        raise ValueError("decide_partial received an empty residual")
    geometry, witness = chain_gap_exists_compiled(
        child, residual, endpoint_records
    )
    compatible, delta, bad = local_final_compatible(
        parent, actor, target, fw
    )
    supported = geometry and compatible
    if supported:
        decision = "supported_residual"
    elif not geometry and compatible:
        decision = "no_geometry"
    elif geometry and not compatible:
        decision = "local_incompatible"
    else:
        decision = "no_geometry_and_local_incompatible"
    return {
        "decision": decision,
        "geometry": geometry,
        "local_compatible": compatible,
        "supported_action": supported,
        "residual": tuple(sorted(residual)),
        "delta": tuple(sorted(delta)),
        "local_bad_masks": bad,
        "geometry_witness": witness,
    }
