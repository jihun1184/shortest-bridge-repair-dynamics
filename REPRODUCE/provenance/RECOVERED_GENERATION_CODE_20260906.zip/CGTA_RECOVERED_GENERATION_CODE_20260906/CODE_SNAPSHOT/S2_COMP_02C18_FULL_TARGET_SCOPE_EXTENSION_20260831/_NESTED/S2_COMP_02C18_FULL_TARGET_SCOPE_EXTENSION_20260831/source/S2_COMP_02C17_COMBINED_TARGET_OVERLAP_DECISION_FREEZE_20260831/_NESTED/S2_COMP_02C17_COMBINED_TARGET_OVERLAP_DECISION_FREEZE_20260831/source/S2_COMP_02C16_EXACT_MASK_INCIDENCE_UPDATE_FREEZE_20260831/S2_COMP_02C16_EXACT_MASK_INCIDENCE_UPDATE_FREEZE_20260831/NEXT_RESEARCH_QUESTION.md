# Next Research Question — 02C17

Combine the already-closed factors into one target-overlap theorem.  For
`X=Y∪a` and nonempty `R=b\a`, prove and regression-test:

```math
R\text{ supported at }X
\iff
\exists(c,s,t)\,ChainGap_X(R;s,t)
\land
Bad_{\mathcal I(\Delta)}(Y\cup a\cup b)=\varnothing,
```

where `Delta=a\(Y∪b)`.  In the current parent-supported domain,
`Bad(Y∪b)=empty`, so no nonincident baseline term is required.

The combined package should recover:

- 02C13 addition-set factorization;
- 02C14 residual factorization;
- 02C15 child geometry regeneration;
- 02C16 exact local compatibility update.

