from __future__ import annotations
import json
from collections import Counter
from pathlib import Path
from s2comp02c17_env import env02c12
from combined_decider import decide_overlap
HERE=Path(__file__).resolve().parent
fixture=json.loads((HERE/'02C17_OVERLAP_INPUT_ORACLE.json').read_text())
records=[]; C=Counter(); mism=[]
with env02c12() as (frozen_env,_,_):
  with frozen_env() as outer:
    with outer.frozen.frozen_env() as env:
      import finite_window_classification as fw
      import c07d3e_component_viability as cv
      rows=outer.domains.load_d7b_rows(env)
      parents={}
      for si in sorted({r['source_state_index'] for r in fixture['records']}):
        initial=frozenset(tuple(p) for p in rows[si]['state']); first=env.api.atomic_actions(initial)[0]
        parents[si]=frozenset(initial|{tuple(p) for p in first['additions']})
      for i,row in enumerate(fixture['records']):
        si=row['source_state_index']; actor=frozenset(tuple(p) for p in row['actor']); target=frozenset(tuple(p) for p in row['target'])
        got=decide_overlap(parents[si],actor,target,env,fw,cv); exp=row['oracle']
        ok=(got['decision']==exp['class'] and got['fulfilled']==exp['fulfilled'] and got['geometry']==exp['geometry'] and got['local_compatible']==(None if exp['class']=='fully_supplied' else exp['compatible']) and got['supported_action']==exp['supported_action'])
        if not ok:mism.append({'index':i,'input':row,'got':got})
        C[got['decision']]+=1
        C['partition_partial']+=int(bool(row['residual'])); C['partition_full']+=int(not row['residual']); C['support_or_fulfilled']+=int(got['supported_action'] or got['fulfilled'])
        records.append({'source_state_index':si,'actor':row['actor'],'target':row['target'],'decision':got['decision'],'geometry':got['geometry'],'local_compatible':got['local_compatible'],'supported_action':got['supported_action'],'fulfilled':got['fulfilled'],'delta':got.get('delta',()),'local_bad_mask_count':len(got.get('local_bad_masks',()))})
result={'checkpoint':'S2-COMP-02C17 combined target-overlap decider','scope':'1639 frozen overlap directions; no child canonical-action/raw-target/global-has_fail call in decision path','totals':dict(C),'mismatch_count':len(mism),'mismatches':mism[:5],'records':records}
(HERE/'02C17_COMBINED_DECISION_CENSUS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'totals':result['totals'],'mismatch_count':len(mism)},indent=2,sort_keys=True))
assert not mism
assert C==Counter({'partition_partial':1288,'partition_full':351,'support_or_fulfilled':688,'no_geometry':831,'supported_residual':337,'no_geometry_and_local_incompatible':111,'local_incompatible':9,'fully_supplied':351})
