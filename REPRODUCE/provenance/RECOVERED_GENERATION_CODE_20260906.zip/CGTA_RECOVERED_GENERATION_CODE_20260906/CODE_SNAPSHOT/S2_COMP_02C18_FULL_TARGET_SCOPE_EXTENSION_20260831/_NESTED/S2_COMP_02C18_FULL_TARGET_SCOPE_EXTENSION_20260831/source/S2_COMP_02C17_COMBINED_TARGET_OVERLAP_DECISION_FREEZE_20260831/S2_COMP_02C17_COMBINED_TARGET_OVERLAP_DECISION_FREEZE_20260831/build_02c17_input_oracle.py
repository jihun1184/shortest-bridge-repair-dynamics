from __future__ import annotations
import hashlib, json, tempfile, zipfile
from pathlib import Path
from s2comp02c17_env import env02c12, _P16
HERE=Path(__file__).resolve().parent
SOURCES=(1,2,4,7,40,41,112,113,114,115)
P15_NAME='S2_COMP_02C15_CHILD_GEOMETRY_REGENERATION_FREEZE_20260831.zip'
P15_SHA='3a639004e0065a4535ac06d551c3c5ec5d185ceb43540666adfb04568fdb71a0'
P15_ROOT='S2_COMP_02C15_CHILD_GEOMETRY_REGENERATION_FREEZE_20260831'
def sha256(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def norm(x):return tuple(tuple(p) for p in x)
p15zip=_P16/'source'/P15_NAME
assert sha256(p15zip)==P15_SHA
with tempfile.TemporaryDirectory(prefix='s2comp02c17_oracle_') as td:
 with zipfile.ZipFile(p15zip) as z:z.extractall(td)
 oracle15=json.loads((Path(td)/P15_ROOT/'02C15_GEOMETRY_INSTRUMENTATION.json').read_text())['records']
key15={(r['source_state_index'],norm(r['actor']),norm(r['target'])):r for r in oracle15}
out=[]
with env02c12() as (frozen_env,_,_):
  with frozen_env() as outer:
    with outer.frozen.frozen_env() as env:
      rows=outer.domains.load_d7b_rows(env)
      for si in SOURCES:
        initial=frozenset(tuple(p) for p in rows[si]['state']); first=env.api.atomic_actions(initial)[0]
        Y=frozenset(initial|{tuple(p) for p in first['additions']})
        certs=tuple(c for c in env.pred['extract_certificates'](Y,env.api) if c.predicate=='N2_facet_connectivity')
        actions=tuple(a for a in env.pred['canonical_actions'](Y,env.api,certs) if 'N2' in a.roles)
        targets=tuple(a for a in actions if len(a.certificate_snapshot_ids)>1)
        for actor in actions:
          A=frozenset(tuple(p) for p in actor.additions)
          for target_action in targets:
            B=frozenset(tuple(p) for p in target_action.additions)
            if actor.action_id==target_action.action_id or not (A&B):continue
            R=B-A
            row={'source_state_index':si,'actor':tuple(sorted(A)),'target':tuple(sorted(B)),'residual':tuple(sorted(R))}
            if not R:
              row['oracle']={'class':'fully_supplied','geometry':None,'compatible':True,'supported_action':False,'fulfilled':True}
            else:
              r=key15[(si,tuple(sorted(A)),tuple(sorted(B)))]
              if r['raw_geometry'] and r['final_compatible']:cls='supported_residual'
              elif (not r['raw_geometry']) and r['final_compatible']:cls='no_geometry'
              elif r['raw_geometry'] and (not r['final_compatible']):cls='local_incompatible'
              else:cls='no_geometry_and_local_incompatible'
              row['oracle']={'class':cls,'geometry':r['raw_geometry'],'compatible':r['final_compatible'],'supported_action':r['supported'],'fulfilled':False}
            out.append(row)
from collections import Counter
fixture={'checkpoint':'S2-COMP-02C17 input/oracle fixture','scope':'all 1639 target-overlap directions; parent canonical actions used only to enumerate frozen inputs','records':out,'totals':dict(Counter(r['oracle']['class'] for r in out))}
(HERE/'02C17_OVERLAP_INPUT_ORACLE.json').write_text(json.dumps(fixture,indent=2)+'\n')
print(json.dumps({'records':len(out),'totals':fixture['totals']},indent=2,sort_keys=True))
