from __future__ import annotations
import ast,json
from collections import Counter
from pathlib import Path
HERE=Path(__file__).resolve().parent
census=json.loads((HERE/'02C17_COMBINED_DECISION_CENSUS.json').read_text())
fixture=json.loads((HERE/'02C17_OVERLAP_INPUT_ORACLE.json').read_text())
assert census['mismatch_count']==0
classes=Counter(r['oracle']['class'] for r in fixture['records'])
assert classes==Counter({'no_geometry':831,'fully_supplied':351,'supported_residual':337,'no_geometry_and_local_incompatible':111,'local_incompatible':9})
partial=[r for r in fixture['records'] if r['residual']]
geom=sum(bool(r['oracle']['geometry']) for r in partial)
compat=sum(bool(r['oracle']['compatible']) for r in partial)
supported=sum(bool(r['oracle']['supported_action']) for r in partial)
# Negative controls: neither factor alone is sufficient.
geometry_only_false_positives=sum(r['oracle']['geometry'] and not r['oracle']['supported_action'] for r in partial)
compat_only_false_positives=sum(r['oracle']['compatible'] and not r['oracle']['supported_action'] for r in partial)
assert (geom,compat,supported)==(346,1168,337)
assert geometry_only_false_positives==9
assert compat_only_false_positives==831
# Static guard: the decision module must not invoke the frozen child action/raw/global-fail machinery.
src=(HERE/'combined_decider.py').read_text(); tree=ast.parse(src)
forbidden=('canonical_actions','n2_target_index','raw_target_realizations','has_fail')
assert not any(name in src for name in forbidden), {name:name in src for name in forbidden}
analysis={
 'checkpoint':'S2-COMP-02C17 combined decision analysis',
 'directions':{'total':len(fixture['records']),'fully_supplied':classes['fully_supplied'],'partial':len(partial)},
 'partial_two_gate':{'geometry_positive':geom,'local_compatible':compat,'supported':supported,'geometry_only_false_positives':geometry_only_false_positives,'compatibility_only_false_positives':compat_only_false_positives},
 'decision_classes':dict(classes),
 'exact_reconstruction':{'mismatch_count':census['mismatch_count'],'matched':len(fixture['records'])},
 'decision_path_forbidden_calls':{name:False for name in forbidden},
}
(HERE/'02C17_COMBINED_ANALYSIS.json').write_text(json.dumps(analysis,indent=2)+'\n')
print(json.dumps(analysis,indent=2,sort_keys=True))
