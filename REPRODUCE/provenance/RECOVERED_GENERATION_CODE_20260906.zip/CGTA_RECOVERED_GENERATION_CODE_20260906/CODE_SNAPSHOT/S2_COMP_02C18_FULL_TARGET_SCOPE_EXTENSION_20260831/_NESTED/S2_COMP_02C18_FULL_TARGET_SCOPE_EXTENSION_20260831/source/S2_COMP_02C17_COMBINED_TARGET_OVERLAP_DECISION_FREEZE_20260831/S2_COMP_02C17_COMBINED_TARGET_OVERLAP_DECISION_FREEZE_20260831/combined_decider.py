from __future__ import annotations
from collections import deque

def edge_sites_for_voxel(v):
    x,y,z=v
    return {
        (x,y,z,'x'),(x,y+1,z,'x'),(x,y,z+1,'x'),(x,y+1,z+1,'x'),
        (x,y,z,'y'),(x+1,y,z,'y'),(x,y,z+1,'y'),(x+1,y,z+1,'y'),
        (x,y,z,'z'),(x+1,y,z,'z'),(x,y+1,z,'z'),(x+1,y+1,z,'z'),
    }

def mask_bad(state, mask_type, site, fw):
    state=set(state)
    if mask_type=='Q2':
        candidates,labels=fw.edge_cands(tuple(site)); bad_table=fw.BAD_Q2
    else:
        candidates,labels=fw.vertex_cands(tuple(site)); bad_table=fw.BAD_Q3
    occ={lab for lab,v in zip(labels,candidates) if tuple(v) in state}
    return len(occ)>=2 and frozenset(occ) in bad_table

def incident_mask_keys(delta, fw):
    keys=set()
    for v in delta:
        keys.update(('Q2',tuple(s)) for s in edge_sites_for_voxel(v))
        keys.update(('Q3',tuple(s)) for s in fw.voxel_corners(tuple(v)))
    return frozenset(keys)

def oriented_coordinates(p,s,t):
    out=[]
    for i in range(3):
        d=t[i]-s[i]
        if d==0:
            if p[i]!=s[i]: return None
            out.append(0)
        elif d>0:
            q=p[i]-s[i]
            if q<0 or q>d:return None
            out.append(q)
        else:
            q=s[i]-p[i]
            if q<0 or q>-d:return None
            out.append(q)
    return tuple(out)

def residual_chain(residual,s,t):
    rows=[]
    for p in residual:
        q=oriented_coordinates(p,s,t)
        if q is None:return None
        rows.append((sum(q),q,p))
    rows.sort()
    for (_,q1,_),(_,q2,_) in zip(rows,rows[1:]):
        if not all(q1[i]<=q2[i] for i in range(3)):return None
    return tuple(p for _,_,p in rows)

def monotone_segment_reachable(start,end,allowed):
    start,end=tuple(start),tuple(end); allowed=set(allowed)
    if start not in allowed or end not in allowed:return False
    q=deque([start]); seen={start}
    while q:
        p=q.popleft()
        if p==end:return True
        for i in range(3):
            if p[i]==end[i]:continue
            n=list(p); n[i]+=1 if end[i]>p[i] else -1; n=tuple(n)
            if n in allowed and n not in seen:seen.add(n);q.append(n)
    return False

def chain_gap_exists(child,residual,certs,cv):
    allowed=frozenset(set(child)|set(residual))
    witness=None
    for cert in certs:
        left,right=cert.carrier
        distance,pairs=cv.shortest_endpoint_pairs(frozenset(left),frozenset(right))
        for s,t in pairs:
            chain=residual_chain(residual,s,t)
            if chain is None:continue
            req=(tuple(s),)+tuple(chain)+(tuple(t),)
            if all(monotone_segment_reachable(u,v,allowed) for u,v in zip(req,req[1:])):
                witness={'certificate':cert.snapshot_id,'s':tuple(s),'t':tuple(t),'distance':distance,'ordered_residual':tuple(chain)}
                return True,witness
    return False,witness

def local_final_compatible(parent,actor,target,fw):
    base=frozenset(set(parent)|set(target))
    final=frozenset(set(parent)|set(actor)|set(target))
    delta=frozenset(set(actor)-set(base))
    bad=tuple(sorted((key for key in incident_mask_keys(delta,fw) if mask_bad(final,*key,fw)),key=str))
    return not bad,delta,bad

def decide_overlap(parent,actor,target,env,fw,cv):
    parent=frozenset(parent); actor=frozenset(actor); target=frozenset(target)
    child=frozenset(parent|actor)
    residual=frozenset(target-actor)
    if not residual:
        return {'decision':'fully_supplied','fulfilled':True,'residual':(), 'geometry':None,'local_compatible':None,'supported_action':False}
    certs=tuple(c for c in env.pred['extract_certificates'](child,env.api) if c.predicate=='N2_facet_connectivity')
    geometry,witness=chain_gap_exists(child,residual,certs,cv)
    compat,delta,bad=local_final_compatible(parent,actor,target,fw)
    supported=geometry and compat
    if supported: decision='supported_residual'
    elif not geometry and compat: decision='no_geometry'
    elif geometry and not compat: decision='local_incompatible'
    else: decision='no_geometry_and_local_incompatible'
    return {'decision':decision,'fulfilled':False,'residual':tuple(sorted(residual)),'geometry':geometry,'local_compatible':compat,'supported_action':supported,'delta':tuple(sorted(delta)),'local_bad_masks':bad,'geometry_witness':witness}
