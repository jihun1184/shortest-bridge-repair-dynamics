# S2-COMP-02C16 Freeze

This checkpoint closes the compatibility-locality side of target overlap.

## Reproduce

Set `S2COMP_02C9_ZIP` to canonical 02C9 with SHA-256
`4ce99f3bb724b5da3b2731d3c60c82d8103713768e715e855585ea5d7c2f7a19`,
then run:

```bash
PYTHONDONTWRITEBYTECODE=1 python run_02c16_mask_incidence_census.py
python analyze_02c16_mask_incidence.py
PYTHONDONTWRITEBYTECODE=1 python test_02c16_regression.py
```

The package embeds canonical 02C15 with SHA-256
`3a639004e0065a4535ac06d551c3c5ec5d185ceb43540666adfb04568fdb71a0`.

## Result

Only masks whose voxel support intersects the actor-exclusive footprint
`Delta=a\(Y∪b)` can change.  Exact final compatibility is obtained by
recomputing at most `20|Delta|` radius-1 Q2/Q3 masks.

