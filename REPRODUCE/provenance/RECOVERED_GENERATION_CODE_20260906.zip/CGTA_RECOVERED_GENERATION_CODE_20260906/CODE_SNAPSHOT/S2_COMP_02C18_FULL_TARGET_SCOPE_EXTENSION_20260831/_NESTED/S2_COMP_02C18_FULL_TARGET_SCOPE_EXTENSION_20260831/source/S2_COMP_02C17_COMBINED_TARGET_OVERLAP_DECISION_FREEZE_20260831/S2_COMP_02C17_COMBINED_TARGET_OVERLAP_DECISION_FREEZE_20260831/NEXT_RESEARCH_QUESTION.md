# Next Research Question — 02C18

02C13--02C17 close the target-overlap decision structure for the frozen N2 semantics.  The next step should test **scope**, not add another equivalent factorization.

Recommended first boundary:

> Does the combined decision theorem remain valid when the parent target is not restricted to the frozen multi-provenance subset, across the full natural N2 target domain and deeper actor histories?

Suggested order:

1. Expand from the 26 multi-provenance targets to every parent-supported N2 target in the 10 source states.
2. Expand from one actor step to deeper natural-closure histories while preserving target identity as an addition set/residual literal.
3. Record the first failure, if any, by branch: full supply, ChainGap geometry, or local incidence compatibility.
4. Only after this scope audit consider non-N2 certificate predicates.
