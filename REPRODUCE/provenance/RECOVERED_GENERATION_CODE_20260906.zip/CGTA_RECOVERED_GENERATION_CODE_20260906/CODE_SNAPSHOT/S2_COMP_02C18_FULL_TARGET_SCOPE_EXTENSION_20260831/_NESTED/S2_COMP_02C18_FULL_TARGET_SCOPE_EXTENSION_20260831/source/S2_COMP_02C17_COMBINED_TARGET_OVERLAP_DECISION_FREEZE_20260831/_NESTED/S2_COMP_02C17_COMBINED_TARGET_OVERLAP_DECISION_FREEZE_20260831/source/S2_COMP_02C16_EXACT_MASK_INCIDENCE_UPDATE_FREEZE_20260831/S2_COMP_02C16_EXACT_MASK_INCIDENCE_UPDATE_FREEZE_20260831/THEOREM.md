# 02C16 — Exact Mask-Incidence Update

Let

```math
B=Y\cup b,\qquad F=Y\cup a\cup b=B\cup\Delta,
\qquad \Delta=a\setminus(Y\cup b).
```

For a Q2 or Q3 mask `m`, let `S(m)` be its voxel support and define

```math
\mathcal I(\Delta)=\{m:S(m)\cap\Delta\ne\varnothing\}.
```

## T16.1 — Unchanged-mask lemma

```math
S(m)\cap\Delta=\varnothing
\Longrightarrow
[m\in Bad(B)\iff m\in Bad(F)].
```

### Proof

The Q2/Q3 predicate for `m` depends only on the occupancy pattern on `S(m)`.
If `S(m)` is disjoint from `Delta`, then `B` and `F=B∪Delta` have identical
occupancy on `S(m)`.  The predicate therefore has the same value.

## T16.2 — Exact local update

```math
Bad(F)=
(Bad(B)\setminus\mathcal I(\Delta))
\cup Bad_{\mathcal I(\Delta)}(F).
```

Thus only masks incident to newly added voxels require recomputation.  This is
an exact identity derived from T16.1, not a bounded empirical classifier.

When `Bad(B)=empty`, as in all 346 frozen directions,

```math
Bad(F)=Bad_{\mathcal I(\Delta)}(F).
```

## T16.3 — Radius and work bound

In the frozen Q2/Q3 stencil, one voxel is incident to 12 edge masks and 8
vertex masks.  Therefore

```math
|\mathcal I(\Delta)|\le 20|\Delta|.
```

Every incident mask anchor differs from an incident voxel by at most one in
each coordinate, hence

```math
anchor(\mathcal I(\Delta))\subseteq N_\infty^1(\Delta).
```

The radius-1 statement is therefore a corollary of support incidence.

