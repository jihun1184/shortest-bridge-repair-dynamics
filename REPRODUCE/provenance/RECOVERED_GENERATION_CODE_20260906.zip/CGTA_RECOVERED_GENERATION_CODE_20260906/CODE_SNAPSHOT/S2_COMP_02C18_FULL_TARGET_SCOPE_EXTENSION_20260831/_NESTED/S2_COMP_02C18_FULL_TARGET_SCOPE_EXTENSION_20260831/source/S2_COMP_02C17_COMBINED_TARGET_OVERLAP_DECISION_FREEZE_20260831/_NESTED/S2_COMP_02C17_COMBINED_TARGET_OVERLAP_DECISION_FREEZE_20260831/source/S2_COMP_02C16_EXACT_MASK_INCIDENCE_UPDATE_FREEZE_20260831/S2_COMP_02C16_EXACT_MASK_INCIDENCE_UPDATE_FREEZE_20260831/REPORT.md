# 02C16 Report — Actor-Exclusive Local Compatibility Update

## Scope

All 346 partial-overlap directions with positive residual geometry from frozen
02C15 were reconstructed.  The actual state difference was measured using

```math
\Delta=a\setminus(Y\cup b),
```

not the whole actor action.

## Compatibility transition census

Because `b` is already a supported parent action, `B=Y∪b` is compatible in
all 346 cases.

| `Bad(B)` | `Bad(F)` | class | count |
|---|---|---|---:|
| empty | empty | stable-compatible | 337 |
| nonempty | empty | complete healing | 0 |
| empty | nonempty | pure creation | 9 |
| nonempty | nonempty | persistent/replacement | 0 |

Thus this domain does not contain 02C12-style healing.  Its 337/9 boundary is
exactly the absence/presence of newly created Delta-incident masks.

## Exact identity results

- changed nonincident masks: 0 across 346 directions;
- exact local-update reconstruction: 346/346;
- created masks: 17 total = 10 Q2 + 7 Q3;
- healed masks: 0;
- persistent bad masks: 0;
- maximum changed-mask anchor distance: `Linf = 1`;
- empty Delta: 28 directions, all stable-compatible.

The nine failures create 1, 2, or 3 bad masks:

| created masks per failure | directions |
|---:|---:|
| 1 | 2 |
| 2 | 6 |
| 3 | 1 |

## Independent stencil regression

Ternary assignments classify each support voxel as baseline-occupied,
Delta-added, or absent.

| stencil | assignments | stable good | heal | create | persistent bad |
|---|---:|---:|---:|---:|---:|
| Q2 | 81 | 67 | 6 | 6 | 2 |
| Q3 | 6,561 | 3,389 | 2,084 | 548 | 540 |

All assignments passed the unchanged-mask and incidence assertions.

