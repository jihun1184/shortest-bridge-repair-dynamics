# Claim Boundary

## Proved from frozen code semantics

- Full-supply branch: `R=empty` means target fulfilled, not an empty residual action.
- Partial-overlap combined theorem: ChainGap geometry AND Delta-incident compatibility is necessary and sufficient for residual support.
- Child decision does not require child canonical action enumeration, raw path enumeration, or global `has_fail`.
- Local compatibility requires at most `20|Delta|` Q2/Q3 mask checks by 02C16.

## Computationally confirmed in the frozen bounded domain

- 1,639/1,639 exact reconstruction.
- Decision classes: 351 / 337 / 831 / 111 / 9 as reported.
- Geometry-only negative control: 9 false positives.
- Compatibility-only negative control: 831 false positives.

## Not claimed

- A non-N2 theorem.
- A polynomial bound for certificate extraction or the ChainGap geometry search beyond previously frozen bounds.
- That the bounded-domain arithmetic shortcut `d6(s,t)+1-|R|=2` is universal.
- That parent carrier identity is preserved under overlap.
