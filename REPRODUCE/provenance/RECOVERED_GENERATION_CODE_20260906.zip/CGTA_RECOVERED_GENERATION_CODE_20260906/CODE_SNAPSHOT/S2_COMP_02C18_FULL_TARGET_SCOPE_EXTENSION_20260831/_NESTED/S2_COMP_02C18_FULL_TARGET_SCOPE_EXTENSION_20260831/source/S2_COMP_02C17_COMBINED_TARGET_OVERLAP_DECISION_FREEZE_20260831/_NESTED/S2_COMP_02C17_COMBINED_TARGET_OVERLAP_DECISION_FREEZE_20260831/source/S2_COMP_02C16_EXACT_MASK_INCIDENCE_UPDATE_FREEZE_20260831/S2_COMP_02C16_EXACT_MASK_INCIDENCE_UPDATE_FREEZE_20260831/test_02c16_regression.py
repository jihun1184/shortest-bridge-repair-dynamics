from __future__ import annotations

import itertools
import json
from collections import Counter
from pathlib import Path

from run_02c16_mask_incidence_census import env02c12, incident_mask_keys, mask_bad

HERE = Path(__file__).resolve().parent


def transition_name(before, after):
    if not before and not after:
        return "stable_good"
    if before and not after:
        return "heal"
    if not before and after:
        return "create"
    return "persistent_bad"


def exhaustive_mask(mask_type, site, fw):
    if mask_type == "Q2":
        candidates, _ = fw.edge_cands(site)
    else:
        candidates, _ = fw.vertex_cands(site)
    candidates = tuple(tuple(p) for p in candidates)
    key = (mask_type, tuple(site))
    counts = Counter()
    checked = 0
    for tags in itertools.product((0, 1, 2), repeat=len(candidates)):
        base = frozenset(p for p, tag in zip(candidates, tags) if tag == 1)
        delta = frozenset(p for p, tag in zip(candidates, tags) if tag == 2)
        final = base | delta
        before = mask_bad(base, mask_type, site, fw)
        after = mask_bad(final, mask_type, site, fw)
        counts[transition_name(before, after)] += 1
        if before != after:
            assert delta
            assert key in incident_mask_keys(delta, fw)
        # A voxel outside the stencil cannot change this mask.
        assert mask_bad(base | {(9, 9, 9)}, mask_type, site, fw) == before
        checked += 1
    return {"mask_type": mask_type, "assignments": checked, "transitions": dict(counts)}


def main():
    analysis = json.loads((HERE / "02C16_MASK_INCIDENCE_ANALYSIS.json").read_text())
    assert analysis["exact_update"]["changed_nonincident_masks"] == 0
    assert analysis["transition_table"] == {
        "stable_compatible": 337,
        "complete_healing": 0,
        "pure_creation": 9,
        "persistent_or_replacement": 0,
    }
    with env02c12() as (frozen_env, _, _):
        with frozen_env() as outer:
            with outer.frozen.frozen_env():
                import finite_window_classification as fw
                fixtures = [
                    exhaustive_mask("Q2", (0, 0, 0, "x"), fw),
                    exhaustive_mask("Q3", (0, 0, 0), fw),
                ]
    assert fixtures[0]["assignments"] == 81
    assert fixtures[1]["assignments"] == 6561
    print("PASS: 02C16 unchanged-mask lemma, exact incidence update, radius-1 bound, and local exhaustive fixtures")
    print(json.dumps({"fixtures": fixtures}, indent=2))


if __name__ == "__main__":
    main()
