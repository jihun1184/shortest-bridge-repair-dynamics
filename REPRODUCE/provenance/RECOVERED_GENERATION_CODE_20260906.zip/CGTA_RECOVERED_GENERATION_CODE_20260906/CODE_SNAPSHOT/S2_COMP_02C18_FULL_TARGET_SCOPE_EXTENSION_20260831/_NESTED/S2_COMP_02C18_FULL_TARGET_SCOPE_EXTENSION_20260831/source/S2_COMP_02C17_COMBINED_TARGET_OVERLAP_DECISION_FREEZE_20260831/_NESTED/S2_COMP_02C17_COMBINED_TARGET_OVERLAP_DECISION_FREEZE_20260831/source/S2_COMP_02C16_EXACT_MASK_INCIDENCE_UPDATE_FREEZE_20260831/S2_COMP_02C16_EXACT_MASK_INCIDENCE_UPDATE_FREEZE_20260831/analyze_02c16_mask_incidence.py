from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main():
    census = json.loads((HERE / "02C16_MASK_INCIDENCE_CENSUS.json").read_text())
    rows = census["records"]
    stable = [r for r in rows if r["transition_class"] == "stable_compatible"]
    creation = [r for r in rows if r["transition_class"] == "pure_creation"]
    assert len(rows) == 346 and len(stable) == 337 and len(creation) == 9
    assert all(not r["base_bad_Q2"] and not r["base_bad_Q3"] for r in rows)
    assert all(r["changed_mask_not_incident_count"] == 0 for r in rows)
    assert all(r["max_changed_anchor_linf_radius"] in (None, 0, 1) for r in rows)

    created_types = Counter(mask[0] for r in rows for mask in r["created"])
    assert created_types == Counter({"Q2": 10, "Q3": 7})
    output = {
        "checkpoint": "S2-COMP-02C16 mask-incidence analysis",
        "transition_table": {
            "stable_compatible": len(stable),
            "complete_healing": sum(r["transition_class"] == "complete_healing" for r in rows),
            "pure_creation": len(creation),
            "persistent_or_replacement": sum(r["transition_class"] == "persistent_or_replacement" for r in rows),
        },
        "delta": {
            "empty": sum(r["delta_size"] == 0 for r in rows),
            "nonempty": sum(r["delta_size"] > 0 for r in rows),
            "size_distribution": dict(sorted(Counter(r["delta_size"] for r in rows).items())),
        },
        "exact_update": {
            "directions_checked": 346,
            "changed_nonincident_masks": sum(r["changed_mask_not_incident_count"] for r in rows),
            "maximum_changed_anchor_linf_radius": max(
                (r["max_changed_anchor_linf_radius"] for r in rows if r["max_changed_anchor_linf_radius"] is not None),
                default=None,
            ),
            "incident_mask_count_max": max(r["incident_mask_count"] for r in rows),
            "incident_mask_count_bound": "at most 20*|delta|",
        },
        "mask_changes": {
            "healed": sum(len(r["healed"]) for r in rows),
            "created_Q2": created_types["Q2"],
            "created_Q3": created_types["Q3"],
            "created_total": sum(created_types.values()),
            "persistent_bad": sum(len(r["persistent_bad"]) for r in rows),
            "created_per_failure_distribution": dict(sorted(Counter(len(r["created"]) for r in creation).items())),
        },
        "final_support": {
            "local_pass": len(stable),
            "local_fail": len(creation),
            "supported": sum(r["final_supported"] for r in rows),
        },
        "creation_witnesses": [
            {
                "source_state_index": r["source_state_index"],
                "delta": r["delta"],
                "created": r["created"],
                "max_anchor_linf_radius": r["max_changed_anchor_linf_radius"],
            }
            for r in creation
        ],
    }
    assert output["final_support"] == {"local_pass": 337, "local_fail": 9, "supported": 337}
    target = HERE / "02C16_MASK_INCIDENCE_ANALYSIS.json"
    target.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()

