from __future__ import annotations
import json, subprocess, sys, os
from pathlib import Path
HERE=Path(__file__).resolve().parent
def run(name):
 p=subprocess.run([sys.executable,name],cwd=HERE,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True)
 if p.returncode:
  print(p.stdout); print(p.stderr,file=sys.stderr); raise SystemExit(p.returncode)
 return p.stdout
# Rebuild frozen input/oracle from predecessor and require byte identity.
old=(HERE/'02C17_OVERLAP_INPUT_ORACLE.json').read_bytes()
out=run('build_02c17_input_oracle.py')
assert (HERE/'02C17_OVERLAP_INPUT_ORACLE.json').read_bytes()==old
# Re-run generator-free child decision and analysis.
oldc=(HERE/'02C17_COMBINED_DECISION_CENSUS.json').read_bytes()
out2=run('run_02c17_combined_decider.py')
assert (HERE/'02C17_COMBINED_DECISION_CENSUS.json').read_bytes()==oldc
olda=(HERE/'02C17_COMBINED_ANALYSIS.json').read_bytes()
out3=run('analyze_02c17_combined.py')
assert (HERE/'02C17_COMBINED_ANALYSIS.json').read_bytes()==olda
analysis=json.loads((HERE/'02C17_COMBINED_ANALYSIS.json').read_text())
assert analysis['exact_reconstruction']=={'mismatch_count':0,'matched':1639}
assert analysis['partial_two_gate']['geometry_only_false_positives']==9
assert analysis['partial_two_gate']['compatibility_only_false_positives']==831
print('PASS: 02C17 combined theorem, 1639-direction exact reconstruction, generator-free child decider, and negative controls')
