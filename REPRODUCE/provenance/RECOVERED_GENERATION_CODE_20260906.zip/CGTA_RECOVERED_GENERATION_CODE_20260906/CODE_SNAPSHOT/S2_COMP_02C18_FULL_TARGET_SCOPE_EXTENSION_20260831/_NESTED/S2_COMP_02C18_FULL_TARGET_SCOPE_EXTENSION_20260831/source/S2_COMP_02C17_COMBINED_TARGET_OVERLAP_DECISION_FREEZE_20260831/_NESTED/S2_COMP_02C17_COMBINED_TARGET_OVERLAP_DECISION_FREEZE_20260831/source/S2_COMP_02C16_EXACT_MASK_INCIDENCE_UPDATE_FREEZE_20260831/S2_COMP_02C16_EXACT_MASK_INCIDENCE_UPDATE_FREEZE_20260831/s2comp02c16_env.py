from __future__ import annotations

import hashlib
import sys
import tempfile
import zipfile
from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parent
P15_NAME = "S2_COMP_02C15_CHILD_GEOMETRY_REGENERATION_FREEZE_20260831.zip"
P15_SHA256 = "3a639004e0065a4535ac06d551c3c5ec5d185ceb43540666adfb04568fdb71a0"
P15_ROOT = "S2_COMP_02C15_CHILD_GEOMETRY_REGENERATION_FREEZE_20260831"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


P15_ZIP = PACKAGE_ROOT / "source" / P15_NAME
if sha256(P15_ZIP) != P15_SHA256:
    raise AssertionError("02C15 predecessor hash mismatch")

_TEMP = tempfile.TemporaryDirectory(prefix="s2comp02c16_")
_ROOT = Path(_TEMP.name)
with zipfile.ZipFile(P15_ZIP) as archive:
    archive.extractall(_ROOT)
_P15 = _ROOT / P15_ROOT
if not _P15.is_dir():
    raise RuntimeError("02C15 extraction failed")
sys.dont_write_bytecode = True
sys.path.insert(0, str(_P15))

from s2comp02c15_env import env02c12, raw_target_realizations  # noqa: E402
