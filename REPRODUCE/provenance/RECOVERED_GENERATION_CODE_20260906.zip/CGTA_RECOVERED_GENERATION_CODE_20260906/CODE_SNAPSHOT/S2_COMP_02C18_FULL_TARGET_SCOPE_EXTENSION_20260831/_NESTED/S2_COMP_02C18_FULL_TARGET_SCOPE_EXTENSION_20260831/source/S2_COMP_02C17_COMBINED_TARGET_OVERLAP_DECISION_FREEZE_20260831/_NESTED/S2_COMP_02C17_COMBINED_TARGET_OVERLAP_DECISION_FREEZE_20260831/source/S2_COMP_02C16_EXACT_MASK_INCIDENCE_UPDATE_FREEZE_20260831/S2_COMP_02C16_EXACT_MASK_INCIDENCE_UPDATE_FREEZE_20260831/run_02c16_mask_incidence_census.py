from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent

from s2comp02c16_env import env02c12, raw_target_realizations

SOURCES = (1, 2, 4, 7, 40, 41, 112, 113, 114, 115)


def aset(action):
    return frozenset(tuple(p) for p in action.additions)


def edge_sites_for_voxel(v):
    x, y, z = v
    return {
        (x, y, z, "x"), (x, y + 1, z, "x"),
        (x, y, z + 1, "x"), (x, y + 1, z + 1, "x"),
        (x, y, z, "y"), (x + 1, y, z, "y"),
        (x, y, z + 1, "y"), (x + 1, y, z + 1, "y"),
        (x, y, z, "z"), (x + 1, y, z, "z"),
        (x, y + 1, z, "z"), (x + 1, y + 1, z, "z"),
    }


def mask_support(mask_type, site, fw):
    if mask_type == "Q2":
        candidates, _ = fw.edge_cands(tuple(site))
    else:
        candidates, _ = fw.vertex_cands(tuple(site))
    return frozenset(tuple(p) for p in candidates)


def mask_bad(state, mask_type, site, fw):
    state = set(state)
    if mask_type == "Q2":
        candidates, labels = fw.edge_cands(tuple(site))
        bad_table = fw.BAD_Q2
    else:
        candidates, labels = fw.vertex_cands(tuple(site))
        bad_table = fw.BAD_Q3
    occupied_labels = {label for label, voxel in zip(labels, candidates) if tuple(voxel) in state}
    return len(occupied_labels) >= 2 and frozenset(occupied_labels) in bad_table


def bad_mask_map(state, fw):
    state = frozenset(state)
    edge_sites = set()
    vertex_sites = set()
    for voxel in state:
        edge_sites.update(edge_sites_for_voxel(voxel))
        vertex_sites.update(tuple(v) for v in fw.voxel_corners(tuple(voxel)))
    out = {}
    for site in sorted(edge_sites, key=str):
        if mask_bad(state, "Q2", site, fw):
            support = mask_support("Q2", site, fw)
            out[("Q2", tuple(site))] = {
                "type": "Q2", "site": tuple(site),
                "support": tuple(sorted(support)),
                "occupied": tuple(sorted(support & state)),
                "empty": tuple(sorted(support - state)),
            }
    for site in sorted(vertex_sites):
        if mask_bad(state, "Q3", site, fw):
            support = mask_support("Q3", site, fw)
            out[("Q3", tuple(site))] = {
                "type": "Q3", "site": tuple(site),
                "support": tuple(sorted(support)),
                "occupied": tuple(sorted(support & state)),
                "empty": tuple(sorted(support - state)),
            }
    return out


def incident_mask_keys(delta, fw):
    keys = set()
    for voxel in delta:
        keys.update(("Q2", tuple(site)) for site in edge_sites_for_voxel(voxel))
        keys.update(("Q3", tuple(site)) for site in fw.voxel_corners(tuple(voxel)))
    # Verify the constructive enumeration is exactly support incidence.
    for key in keys:
        assert mask_support(*key, fw) & delta
    return frozenset(keys)


def anchor_linf_to_delta(key, delta):
    if not delta:
        return None
    anchor = key[1][:3]
    return min(max(abs(anchor[i] - voxel[i]) for i in range(3)) for voxel in delta)


def classify(base_bad, final_bad):
    if not base_bad and not final_bad:
        return "stable_compatible"
    if base_bad and not final_bad:
        return "complete_healing"
    if not base_bad and final_bad:
        return "pure_creation"
    return "persistent_or_replacement"


def main():
    records = []
    totals = Counter()
    with env02c12() as (frozen_env, n2_target_index, _):
        with frozen_env() as outer:
            with outer.frozen.frozen_env() as env:
                import finite_window_classification as fw
                import c07d3e_component_viability as cv
                import automaton_c06c2 as auto

                rows = outer.domains.load_d7b_rows(env)
                for source_index in SOURCES:
                    initial = frozenset(tuple(p) for p in rows[source_index]["state"])
                    first = env.api.atomic_actions(initial)[0]
                    parent = frozenset(initial | {tuple(p) for p in first["additions"]})
                    parent_certs = tuple(
                        c for c in env.pred["extract_certificates"](parent, env.api)
                        if c.predicate == "N2_facet_connectivity"
                    )
                    actions = tuple(
                        a for a in env.pred["canonical_actions"](parent, env.api, parent_certs)
                        if "N2" in a.roles
                    )
                    targets = tuple(a for a in actions if len(a.certificate_snapshot_ids) > 1)
                    for actor in actions:
                        actor_set = aset(actor)
                        child = frozenset(parent | actor_set)
                        for target_action in targets:
                            target = aset(target_action)
                            if actor.action_id == target_action.action_id or not (actor_set & target):
                                continue
                            residual = frozenset(target - actor_set)
                            if not residual:
                                continue
                            idx = n2_target_index(child, tuple(sorted(residual)), env, {})
                            raws = raw_target_realizations(child, tuple(sorted(residual)), idx, cv, auto, fw)
                            if not raws:
                                continue

                            base = frozenset(parent | target)
                            final = frozenset(parent | actor_set | target)
                            delta = frozenset(actor_set - base)
                            base_bad = bad_mask_map(base, fw)
                            final_bad = bad_mask_map(final, fw)
                            base_keys = frozenset(base_bad)
                            final_keys = frozenset(final_bad)
                            healed = base_keys - final_keys
                            created = final_keys - base_keys
                            persistent = base_keys & final_keys
                            changed = healed | created
                            incident = incident_mask_keys(delta, fw)
                            nonincident_changed = changed - incident
                            final_incident_bad = frozenset(
                                key for key in incident if mask_bad(final, *key, fw)
                            )

                            assert not nonincident_changed
                            assert final_keys == (base_keys - incident) | final_incident_bad
                            assert bool(base_keys) == fw.has_fail(base)
                            assert bool(final_keys) == fw.has_fail(final)

                            transition = classify(base_keys, final_keys)
                            changed_anchor_radii = tuple(sorted(anchor_linf_to_delta(k, delta) for k in changed))
                            assert all(radius <= 1 for radius in changed_anchor_radii)
                            record = {
                                "source_state_index": source_index,
                                "actor": tuple(sorted(actor_set)),
                                "target": tuple(sorted(target)),
                                "residual": tuple(sorted(residual)),
                                "delta": tuple(sorted(delta)),
                                "delta_size": len(delta),
                                "final_supported": bool(idx["target_supporters"]),
                                "transition_class": transition,
                                "base_bad_Q2": tuple(sorted((base_bad[k] for k in base_keys if k[0] == "Q2"), key=str)),
                                "base_bad_Q3": tuple(sorted((base_bad[k] for k in base_keys if k[0] == "Q3"), key=str)),
                                "final_bad_Q2": tuple(sorted((final_bad[k] for k in final_keys if k[0] == "Q2"), key=str)),
                                "final_bad_Q3": tuple(sorted((final_bad[k] for k in final_keys if k[0] == "Q3"), key=str)),
                                "healed": tuple(sorted(healed, key=str)),
                                "created": tuple(sorted(created, key=str)),
                                "persistent_bad": tuple(sorted(persistent, key=str)),
                                "incident_mask_count": len(incident),
                                "changed_mask_not_incident_count": len(nonincident_changed),
                                "changed_anchor_linf_radii": changed_anchor_radii,
                                "max_changed_anchor_linf_radius": max(changed_anchor_radii, default=None),
                                "raw_realization_count": len(raws),
                            }
                            records.append(record)
                            totals["geometry_positive"] += 1
                            totals["final_compatible"] += int(not final_keys)
                            totals["final_incompatible"] += int(bool(final_keys))
                            totals[transition] += 1
                            totals["delta_empty"] += int(not delta)
                            totals["healed_masks"] += len(healed)
                            totals["created_masks"] += len(created)
                            totals["persistent_bad_masks"] += len(persistent)
                    print(json.dumps({"source": source_index, "records_so_far": len(records)}), flush=True)

    assert totals["geometry_positive"] == 346
    assert totals["final_compatible"] == 337
    assert totals["final_incompatible"] == 9
    output = {
        "checkpoint": "S2-COMP-02C16 exact mask-support incidence",
        "scope": "all 346 geometry-positive partial-overlap directions from frozen 02C15",
        "totals": dict(totals),
        "records": records,
    }
    target = HERE / "02C16_MASK_INCIDENCE_CENSUS.json"
    target.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"totals": output["totals"], "records": len(records)}, indent=2))


if __name__ == "__main__":
    main()
