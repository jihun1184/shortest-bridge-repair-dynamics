# S2-COMP-02C17 Report

02C17 composes 02C13--02C16 into one target-overlap decision theorem.  No new rescue mechanism is claimed.

## Frozen-domain reconstruction

All 1,639 target-overlap directions from the 10-source / 26 multi-provenance-target domain were reconstructed.

| Decision class | Count |
|---|---:|
| fully supplied (`R=empty`) | 351 |
| residual supported | 337 |
| geometry absent, locally compatible | 831 |
| geometry absent and locally incompatible | 111 |
| geometry present but locally incompatible | 9 |

Thus the partial domain has 1,288 directions, with 346 ChainGap-positive, 1,168 locally compatible, and 337 supported.

The combined decider matched the frozen predecessor oracle on **1,639/1,639** directions.

## Why both gates are necessary

A geometry-only classifier produces exactly **9 false positives**.  A compatibility-only classifier produces exactly **831 false positives**.  The full-supply branch is separate and contains **351** directions.

## Generator-free child decision

The decision module does not call:

- `canonical_actions`;
- `n2_target_index`;
- `raw_target_realizations`;
- global `has_fail`.

Parent canonical actions are used only to regenerate the frozen input domain in the oracle-builder.  Given `(Y,a,b)`, the child decision uses certificate extraction, minimizing endpoint ChainGap, and Delta-incident mask evaluation.
