from __future__ import annotations
import hashlib, os, sys, tempfile, zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
P16_NAME='S2_COMP_02C16_EXACT_MASK_INCIDENCE_UPDATE_FREEZE_20260831.zip'
P16_SHA='8da2257f3bd451aafde337cea2d099270abf5aea8243776535e667626cbe8206'
P16_ROOT='S2_COMP_02C16_EXACT_MASK_INCIDENCE_UPDATE_FREEZE_20260831'
def sha256(p):
 h=hashlib.sha256();
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
P16=HERE/'source'/P16_NAME
assert sha256(P16)==P16_SHA, '02C16 predecessor hash mismatch'
_TMP=tempfile.TemporaryDirectory(prefix='s2comp02c17_')
_ROOT=Path(_TMP.name)
with zipfile.ZipFile(P16) as z:z.extractall(_ROOT)
_P16=_ROOT/P16_ROOT
sys.dont_write_bytecode=True
sys.path.insert(0,str(_P16))
from s2comp02c16_env import env02c12  # noqa
