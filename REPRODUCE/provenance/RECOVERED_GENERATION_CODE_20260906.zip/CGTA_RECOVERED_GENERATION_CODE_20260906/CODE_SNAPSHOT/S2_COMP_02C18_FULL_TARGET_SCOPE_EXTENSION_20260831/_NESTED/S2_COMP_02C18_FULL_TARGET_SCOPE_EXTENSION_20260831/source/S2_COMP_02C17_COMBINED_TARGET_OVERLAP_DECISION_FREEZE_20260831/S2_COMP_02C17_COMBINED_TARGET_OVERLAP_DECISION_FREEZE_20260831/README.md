# S2-COMP-02C17 Freeze

Combined target-overlap decision theorem.

Set `S2COMP_02C9_ZIP` to canonical 02C9 with SHA-256
`4ce99f3bb724b5da3b2731d3c60c82d8103713768e715e855585ea5d7c2f7a19`, then run:

```bash
PYTHONDONTWRITEBYTECODE=1 python test_02c17_regression.py
```

The package embeds canonical 02C16 with SHA-256
`8da2257f3bd451aafde337cea2d099270abf5aea8243776535e667626cbe8206`.

The regression rebuilds the 1,639-direction predecessor-derived oracle, reruns the child decider, and requires byte-identical census/analysis outputs.
