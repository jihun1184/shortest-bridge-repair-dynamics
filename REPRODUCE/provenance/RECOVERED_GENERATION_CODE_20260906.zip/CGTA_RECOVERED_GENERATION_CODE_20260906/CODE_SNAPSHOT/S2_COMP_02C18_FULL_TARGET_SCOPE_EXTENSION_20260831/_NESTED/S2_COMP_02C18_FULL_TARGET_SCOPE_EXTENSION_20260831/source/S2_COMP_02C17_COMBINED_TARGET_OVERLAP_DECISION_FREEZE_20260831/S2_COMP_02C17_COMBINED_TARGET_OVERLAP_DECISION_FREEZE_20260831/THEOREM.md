# 02C17 Combined Target-Overlap Decision Theorem

Let `Y` be a parent state, and let `a` and `b` be parent-supported canonical N2 actions with nonempty overlap. Define

```math
X=Y\cup a,\qquad R=b\setminus a,\qquad B=Y\cup b,
```

```math
F=Y\cup a\cup b=B\cup\Delta,\qquad \Delta=a\setminus(Y\cup b).
```

Because `b` is already supported at `Y`, `Bad(B)=\varnothing`.

## Full-supply branch

If `R=\varnothing`, then `b\subseteq a` and

```math
X\cup b=X.
```

The target is already fulfilled by the actor.  This is not the support of an empty residual canonical action.

## Partial-overlap branch

If `R\neq\varnothing`, then under the frozen N2 semantics

```math
\boxed{
R\text{ supported at }X
\iff
\exists(c,s,t)\,\operatorname{ChainGap}_X(R;s,t)
\land
Bad_{\mathcal I(\Delta)}(F)=\varnothing
}
```

where `c` ranges over child N2 certificates, `(s,t)` over their minimizing endpoint pairs, and

```math
\mathcal I(\Delta)=\{m:S(m)\cap\Delta\neq\varnothing\}.
```

### Proof

1. 02C15 proves `Raw(X,R) != empty` iff a child certificate/minimizing endpoint pair satisfies `ChainGap_X(R;s,t)`.
2. 02C13--02C14 prove residual support iff raw geometry exists and the final state `F` is well composed.
3. 02C16 proves exact mask incidence update.  Since `Bad(B)=empty`, all final bad masks are incident to `Delta`; hence `Bad(F)=empty` iff `Bad_{I(Delta)}(F)=empty`.
4. Combining 1--3 gives the boxed equivalence.

The child decision therefore needs neither child canonical-action enumeration, raw monotone-path enumeration, nor a global `has_fail(F)` scan.  It still requires child N2 certificate extraction and the ChainGap endpoint test.  Compatibility needs at most `20|Delta|` local Q2/Q3 mask checks.
