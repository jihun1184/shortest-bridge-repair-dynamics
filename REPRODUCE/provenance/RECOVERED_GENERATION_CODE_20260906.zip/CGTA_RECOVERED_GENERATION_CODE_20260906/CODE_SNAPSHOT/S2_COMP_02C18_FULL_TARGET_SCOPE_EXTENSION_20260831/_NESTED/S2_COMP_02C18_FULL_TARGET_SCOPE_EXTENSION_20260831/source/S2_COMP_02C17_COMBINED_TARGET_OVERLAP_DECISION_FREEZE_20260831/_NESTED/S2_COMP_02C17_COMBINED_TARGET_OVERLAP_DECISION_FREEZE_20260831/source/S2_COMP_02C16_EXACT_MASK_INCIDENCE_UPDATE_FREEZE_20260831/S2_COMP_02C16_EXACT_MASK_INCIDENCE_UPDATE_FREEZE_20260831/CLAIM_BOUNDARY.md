# Claim Boundary

## PROVED from Q2/Q3 semantics

- A mask disjoint from `Delta` cannot change status.
- Recomputing precisely the masks incident to `Delta` gives the exact final
  bad-mask set.
- `|I(Delta)| <= 20|Delta|` for the frozen 12-edge/8-vertex stencil.
- All incident anchors lie in the Chebyshev radius-1 neighborhood of `Delta`.

## COMPUTATIONALLY CONFIRMED

- Exact update on all 346 geometry-positive partial-overlap directions.
- 337 stable-compatible and 9 pure-creation directions.
- 17 created masks: 10 Q2 and 7 Q3; no healed or persistent bad masks.
- Q2 81-assignment and Q3 6,561-assignment exhaustive local regressions.

## OPEN

- Combined 02C17 theorem packaging geometry and local compatibility in one
  target-overlap decision rule.
- Whether analogous incidence/work bounds hold for non-N2 or other mask
  families.
- Deeper actor sequences beyond the current one-step overlap transition.

