from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
EXPECTED_TOTALS = {
    "history_nodes": 1988,
    "n2_actions": 57152,
    "ordered_overlap_directions": 3971598,
    "depth2_history_transitions": 57152,
    "unique_depth2_physical_states": 38365,
    "merged_history_transitions": 18787,
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    frozen = HERE / "02C19_D1_SCOPE_REGISTRY.json"
    shards = [HERE / "registry_1_113.json", HERE / "registry_114.json", HERE / "registry_115.json"]
    assert frozen.is_file() and all(p.is_file() for p in shards)
    data = json.loads(frozen.read_text())
    assert data["totals"] == EXPECTED_TOTALS
    assert data["identity_gates"] == {
        "distinct_history_keys": 1988,
        "distinct_lineage_ids": 57152,
        "lineage_records_preserved": 57152,
        "physical_state_cache_keys": 38365,
        "state_merges_without_lineage_loss": 18787,
    }
    assert data["cross_source_depth2_physical_state_collisions"] == 0
    assert all("elapsed_seconds" not in json.loads(p.read_text()) for p in shards)

    with tempfile.TemporaryDirectory(prefix="s2comp02c19_merge_") as td:
        out1 = Path(td) / "merged1.json"
        out2 = Path(td) / "merged2.json"
        cmd = [sys.executable, str(HERE / "merge_02c19_d1_shards.py"), *(str(p) for p in shards)]
        subprocess.run([*cmd, "--output", str(out1)], check=True, capture_output=True, text=True)
        subprocess.run([*cmd, "--output", str(out2)], check=True, capture_output=True, text=True)
        assert out1.read_bytes() == out2.read_bytes() == frozen.read_bytes()
    print(f"PASS deterministic shard merge: {sha256(frozen)}")


if __name__ == "__main__":
    main()
