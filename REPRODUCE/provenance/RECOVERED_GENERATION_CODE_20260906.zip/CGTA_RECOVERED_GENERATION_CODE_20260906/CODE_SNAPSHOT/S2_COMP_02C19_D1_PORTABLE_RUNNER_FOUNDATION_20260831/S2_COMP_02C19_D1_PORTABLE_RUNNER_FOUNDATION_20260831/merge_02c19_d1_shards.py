from __future__ import annotations

import argparse
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.dont_write_bytecode = True

EXPECTED_SOURCES = (1, 2, 4, 7, 40, 41, 112, 113, 114, 115)
EXPECTED_TOTALS = {
    "history_nodes": 1988,
    "n2_actions": 57152,
    "ordered_overlap_directions": 3971598,
    "depth2_history_transitions": 57152,
    "unique_depth2_physical_states": 38365,
    "merged_history_transitions": 18787,
}
EXPECTED_P18 = "623b1a639b4549001c9b0091b5d3cb0dee4401d2b3afa54706f307c0508c521b"
EXPECTED_P9 = "4ce99f3bb724b5da3b2731d3c60c82d8103713768e715e855585ea5d7c2f7a19"


def load(path: Path):
    return json.loads(path.read_text())


def main():
    ap = argparse.ArgumentParser(description="Deterministically merge 02C19-D1 source shards.")
    ap.add_argument("shards", nargs="+")
    ap.add_argument("--output", default="02C19_D1_SCOPE_REGISTRY.json")
    args = ap.parse_args()

    by_source = {}
    identity_contract = None
    for raw in args.shards:
        p = Path(raw)
        data = load(p)
        deps = data.get("dependencies", {})
        assert deps.get("02C18_sha256") == EXPECTED_P18, (p, "02C18 dependency")
        assert deps.get("02C9_sha256") == EXPECTED_P9, (p, "02C9 dependency")
        contract = data.get("identity_contract")
        if identity_contract is None:
            identity_contract = contract
        else:
            assert contract == identity_contract, (p, "identity contract mismatch")
        for src in data.get("sources", []):
            sid = int(src["source_state_index"])
            assert sid not in by_source, f"duplicate source shard: {sid}"
            by_source[sid] = src

    assert tuple(sorted(by_source)) == EXPECTED_SOURCES, (sorted(by_source), EXPECTED_SOURCES)

    totals = Counter()
    global_states = defaultdict(list)
    history_keys = set()
    lineage_ids = set()
    lineage_count = 0

    for sid in EXPECTED_SOURCES:
        src = by_source[sid]
        totals.update(src["totals"])
        for hist in src["histories"]:
            hkey = hist["history_key"]
            assert hkey not in history_keys, (sid, "duplicate history_key", hkey)
            history_keys.add(hkey)
            for target in hist["targets"]:
                lkey = target["lineage_id"]
                assert lkey not in lineage_ids, (sid, "duplicate lineage_id", lkey)
                lineage_ids.add(lkey)
                lineage_count += 1
                global_states[target["child_physical_state_key"]].append((sid, hkey, lkey))

    assert dict(totals) == EXPECTED_TOTALS, (dict(totals), EXPECTED_TOTALS)
    assert len(history_keys) == EXPECTED_TOTALS["history_nodes"]
    assert lineage_count == len(lineage_ids) == EXPECTED_TOTALS["n2_actions"]
    assert len(global_states) == EXPECTED_TOTALS["unique_depth2_physical_states"]
    assert lineage_count - len(global_states) == EXPECTED_TOTALS["merged_history_transitions"]

    cross_source = sum(1 for rows in global_states.values() if len({sid for sid, _, _ in rows}) > 1)
    assert cross_source == 0, cross_source

    result = {
        "checkpoint": "S2-COMP-02C19-D1 portable scope/history registry",
        "status": "FOUNDATION_ONLY — no theorem census claim",
        "dependencies": {"02C18_sha256": EXPECTED_P18, "02C9_sha256": EXPECTED_P9},
        "identity_contract": identity_contract,
        "sources": [by_source[sid] for sid in EXPECTED_SOURCES],
        "totals": EXPECTED_TOTALS,
        "global_unique_depth2_physical_states": len(global_states),
        "cross_source_depth2_physical_state_collisions": cross_source,
        "identity_gates": {
            "distinct_history_keys": len(history_keys),
            "distinct_lineage_ids": len(lineage_ids),
            "lineage_records_preserved": lineage_count,
            "physical_state_cache_keys": len(global_states),
            "state_merges_without_lineage_loss": lineage_count - len(global_states),
        },
    }
    out = Path(args.output)
    out.write_text(json.dumps(result, separators=(",", ":")) + "\n")
    print(json.dumps({"output": str(out), "totals": EXPECTED_TOTALS, "identity_gates": result["identity_gates"]}, indent=2))


if __name__ == "__main__":
    main()
