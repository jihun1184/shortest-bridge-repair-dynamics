# 02C19-D1 Foundation Gate Status

Status: **FOUNDATION_CLOSED — ready for theorem-census implementation, not itself a theorem freeze**

## Dependencies

- canonical 02C18 SHA-256: `623b1a639b4549001c9b0091b5d3cb0dee4401d2b3afa54706f307c0508c521b`
- canonical 02C9 SHA-256: `4ce99f3bb724b5da3b2731d3c60c82d8103713768e715e855585ea5d7c2f7a19`
- wrong 02C18 hash: hard fail — PASS
- wrong 02C9 hash: hard fail — PASS

## Identity gates

- history key uses source index + ordered actor-addition sequence — PASS
- physical-state key is cache-only and may merge histories — PASS
- immutable lineage ID uses source + origin history + root target — PASS
- residual-dependent lineage snapshot key is separate — PASS
- transport preserves lineage ID while changing residual snapshot — PASS
- equal residuals from distinct roots do not merge lineage IDs — PASS
- `action_id` / certificate snapshot ID not used as cross-state identity — PASS

## Live merge hazard

Source 1 regenerated through the exact dependency chain:

- histories: 64
- N2 lineage records: 927
- depth-2 physical-state keys: 579
- merges without lineage loss: 348
- maximum histories to one state: 5

All 927 lineage IDs remain distinct despite only 579 state cache keys.

## Full source-sharded registry

Fresh generated shards:

- sources 1,2,4,7,40,41,112,113: 1,036 histories / 26,202 lineages / 1,232,832 ordered overlap directions / 17,497 states / 8,705 merges
- source 114: 444 / 13,393 / 1,302,162 / 8,782 / 4,611
- source 115: 508 / 17,557 / 1,436,604 / 12,086 / 5,471

Merged totals:

- histories: **1,988**
- distinct immutable lineage IDs: **57,152**
- ordered overlap directions: **3,971,598**
- physical-state cache keys: **38,365**
- state merges without lineage loss: **18,787**
- cross-source depth-2 state collisions: **0**

Frozen registry SHA-256:

`ef3a60d9f1cce0d5bddcaa6fe8c74e84bb5347c0edfd9c28afb3d51d429f4b92`

Two independent deterministic shard merges were byte-identical to that frozen registry.

## Hygiene

- machine-specific `/mnt/data` path leak: none
- machine-specific `/home` path leak: none
- `.pyc` / `__pycache__`: none

## Boundary

No child-support theorem decision is claimed here. The next 02C19 checkpoint must
add an oracle builder, oracle-free theorem decider, forbidden-call traps, analysis,
and fresh byte-identical regression over the 3,971,598 directions.
