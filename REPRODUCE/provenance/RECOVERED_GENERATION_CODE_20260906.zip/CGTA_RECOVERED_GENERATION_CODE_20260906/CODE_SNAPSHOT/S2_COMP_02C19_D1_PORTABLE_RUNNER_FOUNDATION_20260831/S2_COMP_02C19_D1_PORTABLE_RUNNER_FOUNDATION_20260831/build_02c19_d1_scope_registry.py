from __future__ import annotations

import argparse
import json
import time
from collections import Counter, defaultdict
from pathlib import Path

from lineage_identity import ResidualLineage, canonical_additions, history_key, physical_state_key
from s2comp02c19_env import P18_SHA256, P9_SHA256, env02c19


def action_additions(action):
    return canonical_additions(action.additions)


def main():
    parser = argparse.ArgumentParser(description="Build the portable 02C19-D1 history/state registry.")
    parser.add_argument("--02c18", dest="p18", help="canonical 02C18 zip (or set S2COMP_02C18_ZIP)")
    parser.add_argument("--02c9", dest="p9", help="canonical 02C9 zip (or set S2COMP_02C9_ZIP)")
    parser.add_argument("--output", default="02C19_D1_SCOPE_REGISTRY.json")
    parser.add_argument("--sources", default="", help="comma-separated source-state indices; default all 10")
    args = parser.parse_args()
    requested = {int(x) for x in args.sources.split(",") if x.strip()} or None

    t0 = time.time()
    result = {
        "checkpoint": "S2-COMP-02C19-D1 portable scope/history registry",
        "status": "FOUNDATION_ONLY — no theorem census claim",
        "dependencies": {"02C18_sha256": P18_SHA256, "02C9_sha256": P9_SHA256},
        "identity_contract": {
            "history": "(source_state_index, ordered actor-addition sequence)",
            "physical_state": "canonical voxel set; generator-cache key only",
            "target": "root addition-set plus transported residual lineage; never action_id/certificate snapshot id",
        },
        "sources": [],
    }
    totals = Counter()
    global_child_states = defaultdict(list)

    with env02c19(args.p18, args.p9) as e19:
        fixture = json.loads((e19["p18_root"] / "02C18_FULL_SCOPE_INPUT_ORACLE.json").read_text())
        with e19["env02c12"]() as (frozen_env, _, _):
            with frozen_env() as outer:
                with outer.frozen.frozen_env() as env:
                    for src in fixture["sources"]:
                        sid = int(src["source_state_index"])
                        if requested is not None and sid not in requested:
                            continue
                        parent = frozenset(tuple(p) for p in src["parent"])
                        root_actors = tuple(canonical_additions(a) for a in src["actions"])
                        source_counts = Counter()
                        history_records = []
                        source_child_states = defaultdict(list)

                        for root_actor in root_actors:
                            hkey = history_key(sid, [root_actor])
                            node = frozenset(parent | set(root_actor))
                            node_state_key = physical_state_key(node)
                            certs = tuple(
                                c for c in env.pred["extract_certificates"](node, env.api)
                                if c.predicate == "N2_facet_connectivity"
                            )
                            acts = tuple(
                                a for a in env.pred["canonical_actions"](node, env.api, certs)
                                if "N2" in a.roles
                            )
                            action_sets = tuple(action_additions(a) for a in acts)
                            if len(action_sets) != len(set(action_sets)):
                                raise AssertionError((sid, hkey, "duplicate canonical N2 addition sets"))

                            overlap_count = sum(
                                1
                                for i, a in enumerate(action_sets)
                                for j, b in enumerate(action_sets)
                                if i != j and set(a).intersection(b)
                            )
                            targets = []
                            for target in action_sets:
                                lineage = ResidualLineage.root(sid, hkey, target)
                                child_state = frozenset(node | set(target))
                                child_key = physical_state_key(child_state)
                                source_child_states[child_key].append((hkey, lineage.lineage_id))
                                global_child_states[child_key].append((sid, hkey, lineage.lineage_id))
                                targets.append(
                                    {
                                        "lineage_id": lineage.lineage_id,
                                        "lineage_state_key": lineage.lineage_state_key,
                                        "additions": target,
                                        "child_physical_state_key": child_key,
                                    }
                                )

                            history_records.append(
                                {
                                    "history_key": hkey,
                                    "actor_sequence": [root_actor],
                                    "physical_state_key": node_state_key,
                                    "n2_certificate_count": len(certs),
                                    "n2_target_count": len(action_sets),
                                    "ordered_overlap_directions": overlap_count,
                                    "targets": targets,
                                }
                            )
                            source_counts["history_nodes"] += 1
                            source_counts["n2_actions"] += len(action_sets)
                            source_counts["ordered_overlap_directions"] += overlap_count
                            source_counts["depth2_history_transitions"] += len(action_sets)

                        mult_hist = Counter(len(v) for v in source_child_states.values())
                        source_counts["unique_depth2_physical_states"] = len(source_child_states)
                        source_counts["merged_history_transitions"] = (
                            source_counts["depth2_history_transitions"] - len(source_child_states)
                        )
                        record = {
                            "source_state_index": sid,
                            "parent": tuple(sorted(parent)),
                            "totals": dict(source_counts),
                            "max_histories_to_same_depth2_state": max(mult_hist, default=0),
                            "depth2_state_multiplicity_histogram": {str(k): v for k, v in sorted(mult_hist.items())},
                            "histories": history_records,
                        }
                        result["sources"].append(record)
                        totals.update(source_counts)
                        print(json.dumps({"source": sid, "totals": dict(source_counts)}, sort_keys=True), flush=True)

    result["totals"] = dict(totals)
    result["global_unique_depth2_physical_states"] = len(global_child_states)
    cross_source = 0
    for rows in global_child_states.values():
        if len({sid for sid, _, _ in rows}) > 1:
            cross_source += 1
    result["cross_source_depth2_physical_state_collisions"] = cross_source
    elapsed_seconds = time.time() - t0

    output = Path(args.output)
    output.write_text(json.dumps(result, separators=(",", ":")) + "\n")
    print(json.dumps({"output": str(output), "totals": result["totals"], "global_unique_depth2_physical_states": result["global_unique_depth2_physical_states"], "cross_source_collisions": cross_source, "elapsed_seconds": round(elapsed_seconds, 6)}, indent=2))


if __name__ == "__main__":
    main()
