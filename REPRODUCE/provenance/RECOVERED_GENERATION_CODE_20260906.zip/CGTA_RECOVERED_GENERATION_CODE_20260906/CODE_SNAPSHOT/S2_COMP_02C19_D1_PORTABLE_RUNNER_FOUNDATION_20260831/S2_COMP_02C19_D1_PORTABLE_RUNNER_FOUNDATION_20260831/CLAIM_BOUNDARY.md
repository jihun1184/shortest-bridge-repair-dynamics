# Claim boundary

Status: **FOUNDATION_CLOSED — no 02C19 theorem census claim**

This artifact establishes the following foundation claims under the exact-hash
02C18 and 02C9 dependencies:

- portable dependency resolution with wrong-hash hard failure;
- history identity is distinct from physical-state cache identity;
- immutable target `lineage_id` is distinct from residual-dependent snapshot identity;
- lineage transport preserves `lineage_id` while residual snapshots may change;
- physical-state cache merging does not delete history/lineage records;
- source-1 live hazard: 927 lineage records over 579 physical-state keys;
- full registry: 1,988 histories, 57,152 lineages, 38,365 state keys, 18,787 merges;
- deterministic source-shard merge reproduces the frozen registry byte-for-byte.

It must **not** be cited as closing the 02C19 3,971,598-direction support theorem
census. That requires a separate oracle/decider/analysis checkpoint with
forbidden-call traps and a fresh byte-identical full regression.
