from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

sys.dont_write_bytecode = True

from lineage_identity import ResidualLineage, history_key, physical_state_key
from s2comp02c19_env import P18_SHA256, P9_SHA256, resolve_dependencies

HERE = Path(__file__).resolve().parent


def expect_failure(fn, exc_type, contains):
    try:
        fn()
    except exc_type as exc:
        assert contains in str(exc), (contains, str(exc))
    else:
        raise AssertionError(f"expected {exc_type.__name__}: {contains}")


def identity_unit_tests():
    # Same physical state, distinct histories: history identity must survive.
    h1 = history_key(1, [[(0, 0, 0)], [(1, 0, 0)]])
    h2 = history_key(1, [[(1, 0, 0)], [(0, 0, 0)]])
    state = {(0, 0, 0), (1, 0, 0)}
    assert h1 != h2
    assert physical_state_key(state) == physical_state_key(reversed(tuple(state)))
    registry = {physical_state_key(state): [h1, h2]}
    assert len(registry) == 1 and len(registry[next(iter(registry))]) == 2

    # Equal residuals do not imply equal lineage identity.
    origin = history_key(40, [[(9, 9, 9)]])
    l1 = ResidualLineage.root(40, origin, [(0, 0, 0), (1, 0, 0)]).transport([(0, 0, 0)])
    l2 = ResidualLineage.root(40, origin, [(2, 0, 0), (1, 0, 0)]).transport([(2, 0, 0)])
    assert l1.residual == l2.residual == ((1, 0, 0),)
    assert l1.lineage_id != l2.lineage_id
    assert l1.lineage_state_key != l2.lineage_state_key

    # Transport changes the residual snapshot but preserves immutable lineage identity.
    l3 = ResidualLineage.root(7, history_key(7, [[(8, 8, 8)]]), [(0, 0, 0), (1, 0, 0)])
    l3_next = l3.transport([(0, 0, 0)])
    assert l3.lineage_id == l3_next.lineage_id
    assert l3.lineage_state_key != l3_next.lineage_state_key


def wrong_dependency_controls():
    with tempfile.TemporaryDirectory(prefix="s2comp02c19_baddep_") as td:
        bad = Path(td) / "wrong.zip"
        bad.write_bytes(b"not a canonical dependency")
        expect_failure(lambda: resolve_dependencies(p18=bad, p9=os.environ.get("S2COMP_02C9_ZIP")), AssertionError, "02C18")
        expect_failure(lambda: resolve_dependencies(p18=os.environ.get("S2COMP_02C18_ZIP"), p9=bad), AssertionError, "02C9")


def live_source1_gate(p18=None, p9=None):
    with tempfile.TemporaryDirectory(prefix="s2comp02c19_live_") as td:
        out = Path(td) / "source1.json"
        env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
        if p18:
            env["S2COMP_02C18_ZIP"] = str(Path(p18).resolve())
        if p9:
            env["S2COMP_02C9_ZIP"] = str(Path(p9).resolve())
        proc = subprocess.run(
            [sys.executable, str(HERE / "build_02c19_d1_scope_registry.py"), "--sources", "1", "--output", str(out)],
            cwd=HERE,
            env=env,
            capture_output=True,
            text=True,
        )
        if proc.returncode:
            print(proc.stdout)
            print(proc.stderr, file=sys.stderr)
            raise SystemExit(proc.returncode)
        data = json.loads(out.read_text())
        assert data["totals"]["history_nodes"] == 64
        assert data["totals"]["n2_actions"] == 927
        assert data["totals"]["ordered_overlap_directions"] == 12596
        assert data["totals"]["unique_depth2_physical_states"] == 579
        assert data["totals"]["merged_history_transitions"] == 348
        src = data["sources"][0]
        assert src["max_histories_to_same_depth2_state"] == 5
        lineage_keys = [t["lineage_id"] for h in src["histories"] for t in h["targets"]]
        child_keys = [t["child_physical_state_key"] for h in src["histories"] for t in h["targets"]]
        assert len(lineage_keys) == len(set(lineage_keys)) == 927
        assert len(set(child_keys)) == 579
        assert len(lineage_keys) > len(set(child_keys))
        frozen_shard = HERE / "registry_1_113.json"
        if frozen_shard.is_file():
            frozen = json.loads(frozen_shard.read_text())
            frozen_src = next(x for x in frozen["sources"] if int(x["source_state_index"]) == 1)
            assert src == frozen_src, "live source-1 record differs from frozen foundation shard"
        print("PASS live source-1: 927 distinct lineages retained across 579 physical-state cache keys")


def hygiene_gate():
    source = "\n".join(p.read_text() for p in HERE.glob("*.py") if p.name != Path(__file__).name)
    forbidden_paths = ("/mnt" + "/data/", "/ho" + "me/")
    for token in forbidden_paths:
        assert token not in source, f"forbidden portability token: {token}"
    forbidden_identity_uses = (".action_id", "[\"action_id\"]", ".certificate_snapshot_id", "[\"certificate_snapshot_id\"]")
    for token in forbidden_identity_uses:
        assert token not in source, f"forbidden identity-field use: {token}"
    assert not list(HERE.rglob("*.pyc"))
    assert not list(HERE.rglob("__pycache__"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--02c18", dest="p18")
    parser.add_argument("--02c9", dest="p9")
    parser.add_argument("--skip-live", action="store_true")
    args = parser.parse_args()

    if args.p18:
        os.environ["S2COMP_02C18_ZIP"] = str(Path(args.p18).resolve())
    if args.p9:
        os.environ["S2COMP_02C9_ZIP"] = str(Path(args.p9).resolve())

    deps = resolve_dependencies()
    assert P18_SHA256 == "623b1a639b4549001c9b0091b5d3cb0dee4401d2b3afa54706f307c0508c521b"
    assert P9_SHA256 == "4ce99f3bb724b5da3b2731d3c60c82d8103713768e715e855585ea5d7c2f7a19"
    identity_unit_tests()
    wrong_dependency_controls()
    if not args.skip_live:
        live_source1_gate(deps["02C18"], deps["02C9"])
    hygiene_gate()
    print("PASS: dependency hashes, wrong-hash hard failures, history/state split, residual-lineage split, live merge hazard, hygiene")


if __name__ == "__main__":
    main()
