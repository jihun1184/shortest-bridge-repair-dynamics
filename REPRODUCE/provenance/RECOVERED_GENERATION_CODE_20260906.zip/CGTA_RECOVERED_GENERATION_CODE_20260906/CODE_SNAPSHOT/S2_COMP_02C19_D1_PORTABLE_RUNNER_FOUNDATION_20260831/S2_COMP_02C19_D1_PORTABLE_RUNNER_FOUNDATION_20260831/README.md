# S2-COMP 02C19-D1 Portable Runner Foundation

Status: **FOUNDATION_CLOSED — not a canonical 02C19 theorem freeze**

This package closes the execution and identity foundation required before the
3,971,598-direction depth-1 theorem census. It is deliberately separate from a
future oracle/decider/analysis theorem freeze.

## Exact external dependencies

- 02C18: `623b1a639b4549001c9b0091b5d3cb0dee4401d2b3afa54706f307c0508c521b`
- 02C9: `4ce99f3bb724b5da3b2731d3c60c82d8103713768e715e855585ea5d7c2f7a19`

Set the two environment variables to those exact ZIPs:

```bash
export S2COMP_02C18_ZIP=/path/to/S2_COMP_02C18_FULL_TARGET_SCOPE_EXTENSION_20260831.zip
export S2COMP_02C9_ZIP=/path/to/S2_COMP_02C9_SOURCE24_SOURCE21_RANK26_30_EXHAUSTION_20260830.zip
```

Explicit paths and environment-variable paths are strict contracts: a missing
file or wrong SHA-256 hard-fails. No machine-specific absolute path is embedded
in the runner.

## Identity contract

1. **History identity** = `(source_state_index, ordered actor-addition sequence)`.
2. **Physical-state identity** = canonical voxel set; it is a generator-cache key only.
3. **Target lineage identity** = immutable `lineage_id(source, origin_history, root_addition_set)`.
4. **Residual snapshot identity** = `lineage_state_key(lineage_id, current_residual)`; this may change under transport while `lineage_id` must not.
5. `action_id` and certificate snapshot IDs are forbidden as cross-state target identity.
6. Equal physical states may share generator cache entries but must not collapse history or lineage records.
7. Equal current residuals from distinct roots must not collapse lineages.

The live source-1 gate realizes the hazard rather than only testing a synthetic
fixture: **927 distinct target lineages map to 579 depth-2 physical-state cache
keys**, while all 927 lineage records are retained.

## Reproduced full scope registry

The recommended build is source-sharded, then deterministically merged:

```bash
python build_02c19_d1_scope_registry.py --sources 1,2,4,7,40,41,112,113 --output registry_1_113.json
python build_02c19_d1_scope_registry.py --sources 114 --output registry_114.json
python build_02c19_d1_scope_registry.py --sources 115 --output registry_115.json
python merge_02c19_d1_shards.py registry_1_113.json registry_114.json registry_115.json --output 02C19_D1_SCOPE_REGISTRY.json
```

The deterministic merge gate closes at:

- depth-1 history nodes: **1,988**
- canonical N2 actions / lineage records: **57,152**
- ordered overlap directions: **3,971,598**
- unique depth-2 physical-state cache keys: **38,365**
- state merges without lineage loss: **18,787**
- cross-source depth-2 state collisions: **0**

`02C19_D1_SCOPE_REGISTRY.json` contains 1,988 distinct history keys and 57,152
distinct immutable lineage IDs. The three shard files and deterministic merge
test are retained as reproducibility evidence.

## Gates

Quick contract + live source-1 gate:

```bash
python test_02c19_d1_contracts.py
```

Frozen-registry deterministic merge gate:

```bash
python test_02c19_d1_frozen_registry.py
```

Full foundation rebuild:

```bash
./run_02c19_d1_foundation.sh
```

## Claim boundary

This foundation **does not** run or close the 3,971,598-direction child-support
theorem decider. The next checkpoint must build a separate oracle/decider/analysis
freeze with oracle-separation traps, numeric gates, and byte-identical fresh rebuild.
