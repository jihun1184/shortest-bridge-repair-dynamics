#!/usr/bin/env bash
set -euo pipefail

: "${S2COMP_02C18_ZIP:?Set S2COMP_02C18_ZIP to canonical 02C18 zip}"
: "${S2COMP_02C9_ZIP:?Set S2COMP_02C9_ZIP to canonical 02C9 zip}"
export PYTHONDONTWRITEBYTECODE=1

HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"

python test_02c19_d1_contracts.py
python build_02c19_d1_scope_registry.py --sources 1,2,4,7,40,41,112,113 --output registry_1_113.json
python build_02c19_d1_scope_registry.py --sources 114 --output registry_114.json
python build_02c19_d1_scope_registry.py --sources 115 --output registry_115.json
python merge_02c19_d1_shards.py registry_1_113.json registry_114.json registry_115.json --output 02C19_D1_SCOPE_REGISTRY.json
python test_02c19_d1_frozen_registry.py
