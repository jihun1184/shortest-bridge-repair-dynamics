from pathlib import Path
import argparse,subprocess,tempfile,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser()
ap.add_argument('--02c20b',required=True); ap.add_argument('--02c20a',required=True); ap.add_argument('--02c19',required=True); ap.add_argument('--02c18',required=True); ap.add_argument('--02c9',required=True)
a=ap.parse_args()
with tempfile.TemporaryDirectory() as td:
 out=Path(td)/'source1.json'
 cmd=[sys.executable,str(ROOT/'analyze_02c20c_source.py'),'--02c20b',a.__dict__['02c20b'],'--02c20a',a.__dict__['02c20a'],'--02c19',a.__dict__['02c19'],'--02c18',a.__dict__['02c18'],'--02c9',a.__dict__['02c9'],'--source','1','--output',str(out)]
 subprocess.run(cmd,check=True)
 assert out.read_bytes()==(ROOT/'02C20C_SOURCE_1.json').read_bytes()
print('PASS: live source-1 02C20C census byte-identical')
