from pathlib import Path
import hashlib,json,subprocess,tempfile,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()
expected=json.loads((ROOT/'FROZEN_HASHES.json').read_text())
for name,h in expected.items():
 got=sha(ROOT/name)
 assert got==h,(name,h,got)
d=json.loads((ROOT/'02C20C_COMMON_CRITICAL_MASK_CENSUS.json').read_text())
t=d['totals']
assert t['incompatible_multi_incidence_classes']==37058
assert t['parent_literal_badset_stable_classes']==37058
assert t['parent_literal_badset_variable_classes']==0
assert t['common_incidence_contains_badset_failures']==0
assert t['common_incidence_badset_exact_failures']==0
assert t['tight_exact_classes']==0 and t['loose_classes']==37058
assert d['badset_type_histogram']=={'Q2-only':30895,'Q3-only':43,'mixed':6120}
with tempfile.TemporaryDirectory() as td:
 out=Path(td)/'agg.json'
 subprocess.run([sys.executable,str(ROOT/'merge_02c20c_census.py'),'--input-dir',str(ROOT),'--output',str(out)],check=True,stdout=subprocess.DEVNULL)
 assert out.read_bytes()==(ROOT/'02C20C_COMMON_CRITICAL_MASK_CENSUS.json').read_bytes()
subprocess.run([sys.executable,str(ROOT/'check_hygiene.py')],check=True)
print('PASS: frozen hashes, 37,058-class gates, Q2/Q3 distribution, deterministic merge, and hygiene')
