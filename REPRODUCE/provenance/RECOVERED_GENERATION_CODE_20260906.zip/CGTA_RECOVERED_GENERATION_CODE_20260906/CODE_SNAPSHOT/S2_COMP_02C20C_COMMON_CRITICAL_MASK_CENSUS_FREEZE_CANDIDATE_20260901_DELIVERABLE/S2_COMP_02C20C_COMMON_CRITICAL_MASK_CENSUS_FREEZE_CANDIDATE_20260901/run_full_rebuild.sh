#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
if [ "$#" -lt 5 ]; then
  echo "usage: $0 02C20B.zip 02C20A.zip 02C19.zip 02C18.zip 02C9.zip [outdir]" >&2
  exit 2
fi
P20B="$1"; P20A="$2"; P19="$3"; P18="$4"; P9="$5"; OUT="${6:-$(mktemp -d)}"
ROOT="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$OUT"
for s in 1 2 4 7 40 41 112 113 114 115; do
  python "$ROOT/analyze_02c20c_source.py" --02c20b "$P20B" --02c20a "$P20A" --02c19 "$P19" --02c18 "$P18" --02c9 "$P9" --source "$s" --output "$OUT/02C20C_SOURCE_${s}.json"
done
python "$ROOT/merge_02c20c_census.py" --input-dir "$OUT" --output "$OUT/02C20C_COMMON_CRITICAL_MASK_CENSUS.json"
for s in 1 2 4 7 40 41 112 113 114 115; do cmp "$OUT/02C20C_SOURCE_${s}.json" "$ROOT/02C20C_SOURCE_${s}.json"; done
cmp "$OUT/02C20C_COMMON_CRITICAL_MASK_CENSUS.json" "$ROOT/02C20C_COMMON_CRITICAL_MASK_CENSUS.json"
echo "PASS: full 02C20C common-critical-mask census rebuild byte-identical to frozen source shards and aggregate"
