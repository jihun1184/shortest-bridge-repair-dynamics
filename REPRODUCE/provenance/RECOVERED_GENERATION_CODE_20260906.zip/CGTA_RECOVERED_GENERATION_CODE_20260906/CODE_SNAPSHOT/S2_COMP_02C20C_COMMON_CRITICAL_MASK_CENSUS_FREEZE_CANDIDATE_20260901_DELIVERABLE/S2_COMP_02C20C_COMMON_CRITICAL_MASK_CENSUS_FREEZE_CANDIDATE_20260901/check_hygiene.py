from pathlib import Path
import sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
bad=[]
for p in ROOT.rglob('*'):
    if p.is_dir():
        if p.name=='__pycache__': bad.append(str(p.relative_to(ROOT)))
        continue
    if p.suffix=='.pyc': bad.append(str(p.relative_to(ROOT)))
BANNED=('/'+'mnt/data/','/'+'home/')
for p in ROOT.rglob('*'):
    if not p.is_file() or p.name=='SHA256SUMS.txt' or p.suffix.lower() not in {'.py','.md','.sh','.json','.txt'}: continue
    try: txt=p.read_text(errors='strict')
    except Exception: continue
    for needle in BANNED:
        if needle in txt: bad.append(f'{p.relative_to(ROOT)}: absolute-path leak')
if bad:
    raise SystemExit('HYGIENE FAIL\n'+'\n'.join(sorted(set(bad))))
print('PASS: no pycache/pyc or machine-specific absolute-path leaks')
