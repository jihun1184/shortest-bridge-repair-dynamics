# S2-COMP-02C20C — Common Critical Mask Census

This package extends canonical 02C20B with a full 10-source census of the common-incidence locality structure for all 37,058 incompatible multi-incidence `(Y,R)` classes.

## Core definitions

For one `(Y,R)` class `g`:

- `F = Y union R`
- `I(Delta) = exact frozenset(incident_mask_keys(Delta, fw))`
- `C_g = intersection over every distinct observed I(Delta)`
- `B_g = literal frozenset of bad masks in I(Delta)`

02C20B established that `B_g` is invariant over observed provenance in the frozen D1 scope. Hence `B_g subset C_g` and `Bad(F) intersection C_g = B_g` are corollaries; 02C20C recomputes them as hard regressions and measures the locality gap.

## New census outputs

The package records exact literal-set histograms for:

- `|C_g|`
- `|B_g|`
- `|C_g|-|B_g|`
- `|B_g|/|C_g|`
- bad-set type: Q2-only / Q3-only / mixed

Full obstruction-type result: Q2-only 30,895; Q3-only 43; mixed 6,120.

## Rebuild

`run_full_rebuild.sh` accepts the five exact parent ZIPs in order: 02C20B, 02C20A, 02C19-D1, 02C18, 02C9. It regenerates all ten source shards, merges the aggregate, and byte-compares every generated JSON against the frozen package copies.

`test_02c20c_regression.py` checks frozen hashes, numeric gates, deterministic merge, and hygiene. `test_02c20c_live_source1.py` rebuilds source 1 from the exact dependency chain and requires byte identity.
