from __future__ import annotations
import argparse, json, sys
sys.dont_write_bytecode = True
from collections import Counter
from pathlib import Path
import orjson

SOURCES=(1,2,4,7,40,41,112,113,114,115)
ADD_KEYS={
'incompatible_multi_incidence_classes','parent_literal_badset_stable_classes','parent_literal_badset_variable_classes',
'common_incidence_contains_badset_classes','common_incidence_contains_badset_failures',
'common_incidence_badset_exact_classes','common_incidence_badset_exact_failures',
'sum_common_incidence_size','sum_badset_size','sum_common_minus_badset','sum_badset_over_common_ratio',
'tight_exact_classes','loose_classes'
}
MIN_KEYS={'min_common_incidence_size','min_badset_size','min_common_minus_badset','min_badset_over_common_ratio'}
MAX_KEYS={'max_common_incidence_size','max_badset_size','max_common_minus_badset','max_badset_over_common_ratio'}
HISTS=('common_incidence_size_histogram','badset_size_histogram','common_minus_badset_size_histogram','badset_over_common_ratio_histogram','badset_type_histogram')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input-dir',required=True)
    ap.add_argument('--output',required=True)
    a=ap.parse_args()
    root=Path(a.input_dir)
    rows=[]
    totals={k:0 for k in ADD_KEYS}
    mins={}; maxs={}
    hists={h:Counter() for h in HISTS}
    source_summary=[]
    tight=[]; loose=[]; failures=[]
    for s in SOURCES:
        p=root/f'02C20C_SOURCE_{s}.json'
        d=orjson.loads(p.read_bytes())
        assert int(d['source_state_index'])==s
        rows.append(d)
        t=d['totals']
        for k in ADD_KEYS:
            totals[k]+=t.get(k,0)
        for k in MIN_KEYS:
            if k in t: mins[k]=t[k] if k not in mins else min(mins[k],t[k])
        for k in MAX_KEYS:
            if k in t: maxs[k]=t[k] if k not in maxs else max(maxs[k],t[k])
        for h in HISTS:
            hists[h].update(d[h])
        source_summary.append({
            'source_state_index':s,
            'incompatible_multi_incidence_classes':t['incompatible_multi_incidence_classes'],
            'mean_common_incidence_size':t['mean_common_incidence_size'],
            'mean_badset_size':t['mean_badset_size'],
            'mean_common_minus_badset':t['mean_common_minus_badset'],
            'badset_type_histogram':d['badset_type_histogram'],
        })
        tight.extend(d['witnesses']['tightest_common_incidence'])
        loose.extend(d['witnesses']['loosest_common_incidence'])
        failures.extend(d['witnesses']['regression_failures'])
    n=totals['parent_literal_badset_stable_classes']
    totals.update(mins); totals.update(maxs)
    if n:
        totals['mean_common_incidence_size']=totals['sum_common_incidence_size']/n
        totals['mean_badset_size']=totals['sum_badset_size']/n
        totals['mean_common_minus_badset']=totals['sum_common_minus_badset']/n
        totals['mean_badset_over_common_ratio']=totals['sum_badset_over_common_ratio']/n

    # Deterministic global representatives.
    tight.sort(key=lambda r:(r['common_minus_badset_size'],r['common_incidence_size'],r['badset_size'],r['source_state_index'],str(r['Y']),str(r['R'])))
    loose.sort(key=lambda r:(-r['common_minus_badset_size'],-r['common_incidence_size'],r['source_state_index'],str(r['Y']),str(r['R'])))
    out={
        'checkpoint':'S2-COMP-02C20C common critical mask census',
        'status':'FREEZE_CANDIDATE — full 10-source census computed; bounded D1 scope only',
        'scope':{
            'sources':list(SOURCES),
            'parent_incompatible_multi_incidence_classes':37058,
            'meaning':'All incompatible multi-incidence (Y,R) classes from frozen 02C20B / 02C19-D1 scope.'
        },
        'theorem_boundary':(
            'The common-incidence contain/exact equations are set-theoretic corollaries of 02C20B literal bad-set stability. '
            'New empirical content is the locality-gap and Q2/Q3 obstruction-type distribution; no D2/general-state/minimality claim.'
        ),
        'totals':totals,
        'common_incidence_size_histogram':{k:hists['common_incidence_size_histogram'][k] for k in sorted(hists['common_incidence_size_histogram'],key=lambda x:int(x))},
        'badset_size_histogram':{k:hists['badset_size_histogram'][k] for k in sorted(hists['badset_size_histogram'],key=lambda x:int(x))},
        'common_minus_badset_size_histogram':{k:hists['common_minus_badset_size_histogram'][k] for k in sorted(hists['common_minus_badset_size_histogram'],key=lambda x:int(x))},
        'badset_over_common_ratio_histogram':{k:hists['badset_over_common_ratio_histogram'][k] for k in sorted(hists['badset_over_common_ratio_histogram'])},
        'badset_type_histogram':{k:hists['badset_type_histogram'][k] for k in ('Q2-only','Q3-only','mixed')},
        'source_summary':source_summary,
        'witnesses':{
            'global_tightest':tight[:5],
            'global_loosest':loose[:5],
            'regression_failures':failures[:10],
        },
    }
    # Hard gates.
    assert totals['incompatible_multi_incidence_classes']==37058
    assert totals['parent_literal_badset_stable_classes']==37058
    assert totals['parent_literal_badset_variable_classes']==0
    assert totals['common_incidence_contains_badset_failures']==0
    assert totals['common_incidence_badset_exact_failures']==0
    assert sum(out['badset_type_histogram'].values())==37058
    Path(a.output).write_bytes(orjson.dumps(out,option=orjson.OPT_SORT_KEYS|orjson.OPT_INDENT_2)+b'\n')
    print(json.dumps({'output':a.output,'totals':totals,'badset_type_histogram':out['badset_type_histogram']},indent=2,sort_keys=True))
if __name__=='__main__': main()
