from __future__ import annotations
import sys
sys.dont_write_bytecode=True
import argparse, json
from pathlib import Path
import orjson
from common_mask_core import analyze_source_data
from s2comp02c20c_env import env02c20c

SOURCES={1,2,4,7,40,41,112,113,114,115}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--02c20b',required=True)
    ap.add_argument('--02c20a',required=True)
    ap.add_argument('--02c19',required=True)
    ap.add_argument('--02c18',required=True)
    ap.add_argument('--02c9',required=True)
    ap.add_argument('--source',required=True,type=int,choices=sorted(SOURCES))
    ap.add_argument('--output',required=True)
    ap.add_argument('--max-witness',type=int,default=3)
    a=ap.parse_args()

    with env02c20c(a.__dict__['02c20b'],a.__dict__['02c20a'],a.__dict__['02c19'],a.__dict__['02c18'],a.__dict__['02c9']) as C:
        B=C['parent_env']
        with B.env02c20b(C['p20a'],C['p19'],C['p18'],C['p9']) as P20B:
            P20A=P20B['parent_env']
            with P20A.env02c20a(P20B['p19'],P20B['p18'],P20B['p9']) as E:
                name='02C19_D1_ORACLE_1_113.json' if a.source in {1,2,4,7,40,41,112,113} else f'02C19_D1_ORACLE_{a.source}.json'
                d=orjson.loads((E['root']/name).read_bytes())
                matches=[s for s in d['sources'] if int(s['source_state_index'])==a.source]
                if len(matches)!=1:
                    raise AssertionError('exactly one source required')
                with E['parent_env'].env02c19_d1(E['p18'],E['p9']) as pe:
                    with pe['env02c12']() as (frozen_env,_,_):
                        with frozen_env() as outer:
                            with outer.frozen.frozen_env() as env:
                                import finite_window_classification as fw
                                r=analyze_source_data(matches[0],pe['decider'],fw,max_witness=a.max_witness)

    Path(a.output).write_bytes(orjson.dumps(r,option=orjson.OPT_SORT_KEYS|orjson.OPT_INDENT_2)+b'\n')
    print(json.dumps({'output':a.output,'source':a.source,'totals':r['totals']},indent=2,sort_keys=True))

if __name__=='__main__':
    main()
