# 02C20C result summary

Full frozen D1 census:

- incompatible multi-incidence classes: **37,058**
- common-incidence contains-badset failures: **0**
- common-incidence exact-badset failures: **0**
- exact-tight classes (`|C_g|=|B_g|`): **0**
- loose classes: **37,058**

Locality:

- mean `|C_g|`: **58.81882454530736**
- mean `|B_g|`: **1.280290355658697**
- mean excess `|C_g|-|B_g|`: **57.53853418964866**
- min/max `|C_g|`: **20 / 84**
- min/max `|B_g|`: **1 / 6**
- min/max excess: **18 / 83**

Literal invariant bad-set type distribution over all 37,058 classes:

- **Q2-only: 30,895**
- **Q3-only: 43**
- **mixed Q2+Q3: 6,120**

The earlier tight/loose witness preview was directionally correct that Q2 dominates, but the full census shows a small nonzero Q3-only population.
