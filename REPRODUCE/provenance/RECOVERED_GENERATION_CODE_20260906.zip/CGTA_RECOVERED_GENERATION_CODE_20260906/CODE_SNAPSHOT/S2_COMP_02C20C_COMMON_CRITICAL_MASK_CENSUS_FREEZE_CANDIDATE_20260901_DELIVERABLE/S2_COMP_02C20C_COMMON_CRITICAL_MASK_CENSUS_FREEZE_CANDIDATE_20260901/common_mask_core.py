from __future__ import annotations
import sys
sys.dont_write_bytecode = True
from collections import Counter


def ser_points(s):
    return [list(p) for p in sorted(s)]


def ser_masks(s):
    return [[k[0], list(k[1])] for k in sorted(s, key=str)]


def _ratio_bucket(num: int, den: int) -> str:
    if den <= 0:
        return 'undefined'
    r = num / den
    if r == 1:
        return '1'
    if r >= .75:
        return '[0.75,1)'
    if r >= .50:
        return '[0.50,0.75)'
    if r >= .25:
        return '[0.25,0.50)'
    if r >= .10:
        return '[0.10,0.25)'
    return '[0,0.10)'


def _badset_type(B):
    kinds = {m[0] for m in B}
    if kinds == {'Q2'}:
        return 'Q2-only'
    if kinds == {'Q3'}:
        return 'Q3-only'
    if kinds == {'Q2', 'Q3'}:
        return 'mixed'
    raise AssertionError(f'unexpected bad-set mask types: {kinds}')


def analyze_source_data(src, decider, fw, max_witness=3):
    """02C20C common-critical-mask census for one source.

    For each incompatible multi-incidence (Y,R) class g:
      C_g = intersection_{Delta in g} I(Delta)
      B_g(Delta) = Bad(F) intersection I(Delta), F=Y union R

    Literal incidence sets and literal bad-mask sets are compared as frozensets.
    The 02C20B literal-stability result implies the two common-incidence gates
    set-theoretically; this analyzer recomputes them as regressions and measures
    the nontrivial locality gap between C_g and the invariant B_g.
    """
    sid = int(src['source_state_index'])

    pts = set()
    for h in src['histories']:
        pts.update(map(tuple, h['node']))
        for a in h['actions']:
            pts.update(map(tuple, a))
    ordered = sorted(pts)
    idx = {p: i for i, p in enumerate(ordered)}

    def bm(seq):
        x = 0
        for p in seq:
            x |= 1 << idx[tuple(p)]
        return x

    def points(x):
        out = []
        while x:
            low = x & -x
            i = low.bit_length() - 1
            out.append(ordered[i])
            x ^= low
        return frozenset(out)

    prepared = []
    groups = {}
    for h in src['histories']:
        n = bm(h['node'])
        aa = [bm(a) for a in h['actions']]
        yy = [n | a for a in aa]
        prepared.append((h, n, aa, yy))
        for ai, ti, code in h['directions']:
            r = aa[ti] & ~aa[ai]
            if not r:
                continue
            k = (yy[ai], r)
            v = groups.get(k, 0)
            occ = min(2, (v & 3) + 1)
            v = (v & ~3) | occ
            # Same oracle-compatible encoding used by 02C20A/B.
            v |= 1 << (2 + ((code >> 2) & 1))
            groups[k] = v

    collisions = {k for k, v in groups.items() if (v & 3) > 1}
    incompatible_collisions = {k for k in collisions if (groups[k] & 12) == 4}

    delta_map = {}
    delta_points = {}
    for h, n, aa, yy in prepared:
        for ai, ti, code in h['directions']:
            r = aa[ti] & ~aa[ai]
            k = (yy[ai], r)
            if not r or k not in incompatible_collisions:
                continue
            d = aa[ai] & ~(n | aa[ti])
            delta_map.setdefault(k, set()).add(d)
            delta_points.setdefault(d, points(d))

    # Exact literal mask-key frozensets, never cardinality keys.
    incidence = {
        d: frozenset(decider.incident_mask_keys(ds, fw))
        for d, ds in delta_points.items()
    }

    st = Counter()
    common_hist = Counter()
    bad_hist = Counter()
    excess_hist = Counter()
    ratio_hist = Counter()
    badset_type_hist = Counter()
    representative_candidates = []
    failure_witnesses = []

    for k, dset in delta_map.items():
        incs = {incidence[d] for d in dset}
        if len(incs) <= 1:
            continue

        st['incompatible_multi_incidence_classes'] += 1
        F = points(k[0] | k[1])

        badsets = {
            inc: frozenset(m for m in inc if decider.mask_bad(F, m[0], m[1], fw))
            for inc in incs
        }
        if any(not b for b in badsets.values()):
            raise AssertionError(f'incompatible class has empty bad-set: source={sid}')

        distinct_badsets = set(badsets.values())
        stable = len(distinct_badsets) == 1
        st['parent_literal_badset_stable_classes'] += int(stable)
        st['parent_literal_badset_variable_classes'] += int(not stable)

        # Literal intersection across ALL distinct observed incidence sets.
        common = frozenset.intersection(*incs)
        bad_on_common = frozenset(
            m for m in common if decider.mask_bad(F, m[0], m[1], fw)
        )

        contains_all = all(b <= common for b in distinct_badsets)
        exact_all = all(bad_on_common == b for b in distinct_badsets)
        st['common_incidence_contains_badset_classes'] += int(contains_all)
        st['common_incidence_contains_badset_failures'] += int(not contains_all)
        st['common_incidence_badset_exact_classes'] += int(exact_all)
        st['common_incidence_badset_exact_failures'] += int(not exact_all)

        if stable:
            B = next(iter(distinct_badsets))
            csz, bsz = len(common), len(B)
            excess = csz - bsz
            ratio = bsz / csz if csz else None
            common_hist[csz] += 1
            bad_hist[bsz] += 1
            excess_hist[excess] += 1
            ratio_hist[_ratio_bucket(bsz, csz)] += 1
            badset_type_hist[_badset_type(B)] += 1
            st['sum_common_incidence_size'] += csz
            st['sum_badset_size'] += bsz
            st['sum_common_minus_badset'] += excess
            st['sum_badset_over_common_ratio'] += ratio
            st['min_common_incidence_size'] = csz if not st.get('_seen_common') else min(st['min_common_incidence_size'], csz)
            st['max_common_incidence_size'] = max(st['max_common_incidence_size'], csz)
            st['min_badset_size'] = bsz if not st.get('_seen_bad') else min(st['min_badset_size'], bsz)
            st['max_badset_size'] = max(st['max_badset_size'], bsz)
            st['min_common_minus_badset'] = excess if not st.get('_seen_excess') else min(st['min_common_minus_badset'], excess)
            st['max_common_minus_badset'] = max(st['max_common_minus_badset'], excess)
            st['min_badset_over_common_ratio'] = ratio if not st.get('_seen_ratio') else min(st['min_badset_over_common_ratio'], ratio)
            st['max_badset_over_common_ratio'] = max(st['max_badset_over_common_ratio'], ratio)
            st['_seen_common'] = st['_seen_bad'] = st['_seen_excess'] = st['_seen_ratio'] = 1
            st['tight_exact_classes'] += int(excess == 0)
            st['loose_classes'] += int(excess > 0)

            rec = {
                'source_state_index': sid,
                'Y': ser_points(points(k[0])),
                'R': ser_points(points(k[1])),
                'F': ser_points(F),
                'distinct_delta_count': len(dset),
                'distinct_incidence_count': len(incs),
                'common_incidence_size': csz,
                'badset_size': bsz,
                'common_minus_badset_size': excess,
                'badset_over_common_ratio': ratio,
                'badset_type': _badset_type(B),
                'common_incidence': ser_masks(common),
                'bad_set': ser_masks(B),
                'bad_on_common': ser_masks(bad_on_common),
            }
            representative_candidates.append(rec)

        if (not contains_all or not exact_all or not stable) and len(failure_witnesses) < max_witness:
            failure_witnesses.append({
                'source_state_index': sid,
                'Y': ser_points(points(k[0])),
                'R': ser_points(points(k[1])),
                'F': ser_points(F),
                'incidences': [ser_masks(x) for x in sorted(incs, key=lambda z: (len(z), str(sorted(z, key=str))))],
                'badsets': [ser_masks(x) for x in sorted(distinct_badsets, key=lambda z: (len(z), str(sorted(z, key=str))))],
                'common_incidence': ser_masks(common),
                'bad_on_common': ser_masks(bad_on_common),
                'parent_literal_badset_stable': stable,
                'contains_all_badsets': contains_all,
                'bad_on_common_equals_all_badsets': exact_all,
            })

    for k in ('_seen_common','_seen_bad','_seen_excess','_seen_ratio'):
        st.pop(k, None)
    nstable = st['parent_literal_badset_stable_classes']
    if nstable:
        st['mean_common_incidence_size'] = st['sum_common_incidence_size'] / nstable
        st['mean_badset_size'] = st['sum_badset_size'] / nstable
        st['mean_common_minus_badset'] = st['sum_common_minus_badset'] / nstable
        st['mean_badset_over_common_ratio'] = st['sum_badset_over_common_ratio'] / nstable

    representative_candidates.sort(key=lambda r: (r['common_minus_badset_size'], r['common_incidence_size'], r['badset_size'], str(r['Y']), str(r['R'])))
    tightest = representative_candidates[:max_witness]
    loosest = sorted(representative_candidates, key=lambda r: (-r['common_minus_badset_size'], -r['common_incidence_size'], str(r['Y']), str(r['R'])))[:max_witness]

    return {
        'checkpoint': 'S2-COMP-02C20C common critical mask source census',
        'source_state_index': sid,
        'definitions': {
            'Y': 'node union actor',
            'R': 'target minus actor',
            'F': 'Y union R',
            'incidence': 'exact frozenset(incident_mask_keys(delta, fw))',
            'B_g_delta': 'literal frozenset of masks m in incidence with mask_bad(F,m)',
            'common_incidence': 'literal intersection over ALL distinct observed incidence sets in one (Y,R) class',
            'badset_type': 'Q2-only, Q3-only, or mixed according to the literal invariant B_g mask types',
        },
        'logic_note': (
            'The two common-incidence equations are set-theoretic corollaries of the '
            '02C20B literal bad-set stability result and are recomputed as regressions. '
            'The nontrivial outputs are locality-gap distributions and obstruction-type stratification.'
        ),
        'totals': dict(st),
        'common_incidence_size_histogram': {str(k): common_hist[k] for k in sorted(common_hist)},
        'badset_size_histogram': {str(k): bad_hist[k] for k in sorted(bad_hist)},
        'common_minus_badset_size_histogram': {str(k): excess_hist[k] for k in sorted(excess_hist)},
        'badset_over_common_ratio_histogram': {k: ratio_hist[k] for k in sorted(ratio_hist)},
        'badset_type_histogram': {k: badset_type_hist[k] for k in ('Q2-only','Q3-only','mixed')},
        'witnesses': {
            'tightest_common_incidence': tightest,
            'loosest_common_incidence': loosest,
            'regression_failures': failure_witnesses,
        },
    }
