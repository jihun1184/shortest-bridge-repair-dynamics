from __future__ import annotations
import hashlib, importlib.util, sys, tempfile, zipfile
from contextlib import contextmanager
from pathlib import Path

P20B_SHA256='d2c988914b278e1099516b3a072a43b85b9203e240d7f7479ab41bba6a171caa'
P20B_ROOT='S2_COMP_02C20B_BAD_MASK_STABILITY_STRATIFICATION_FREEZE_CANDIDATE_20260901'
P20A_SHA256='38e8fda72f99bdd43e99b6191a3381f789ed29e0b95cd45d140ce9d1bc17c3e2'
P19_SHA256='47a3cabdeb2300de96906415c7cee21b8a731da3d3cdb7bf7fee78e38804f20b'
P18_SHA256='623b1a639b4549001c9b0091b5d3cb0dee4401d2b3afa54706f307c0508c521b'
P9_SHA256='4ce99f3bb724b5da3b2731d3c60c82d8103713768e715e855585ea5d7c2f7a19'
P20B_AGG_SHA256='e3ccbc276f5ae4f0cd2c7a51cad331fe1ced56a2e635b20410edb2c8fab7f525'

def sha256(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):
            h.update(b)
    return h.hexdigest()

def checked(p,h,label):
    p=Path(p).expanduser().resolve()
    if not p.is_file():
        raise FileNotFoundError(f'{label} not found: {p}')
    got=sha256(p)
    if got!=h:
        raise AssertionError(f'{label} hash mismatch: expected {h}, got {got}')
    return p

@contextmanager
def env02c20c(p20b,p20a,p19,p18,p9):
    p20b=checked(p20b,P20B_SHA256,'02C20B')
    p20a=checked(p20a,P20A_SHA256,'02C20A')
    p19=checked(p19,P19_SHA256,'02C19')
    p18=checked(p18,P18_SHA256,'02C18')
    p9=checked(p9,P9_SHA256,'02C9')
    old=sys.dont_write_bytecode
    sys.dont_write_bytecode=True
    with tempfile.TemporaryDirectory(prefix='s2comp02c20c_') as td:
        td=Path(td)
        with zipfile.ZipFile(p20b) as z:
            z.extractall(td/'p20b')
        root=td/'p20b'/P20B_ROOT
        if not root.is_dir():
            raise RuntimeError('02C20B extraction root missing')
        agg=root/'02C20B_BAD_MASK_STABILITY_STRATIFICATION.json'
        if sha256(agg)!=P20B_AGG_SHA256:
            raise AssertionError('02C20B aggregate hash mismatch')
        # Load the exact 02C20B parent environment contract.
        spec=importlib.util.spec_from_file_location('_s2comp02c20b_env_20c',root/'s2comp02c20b_env.py')
        mod=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        yield {'p20b_root':root,'parent_env':mod,'p20a':p20a,'p19':p19,'p18':p18,'p9':p9}
    sys.dont_write_bytecode=old
