# Claim boundary — S2-COMP-02C20C

Status: **FREEZE_CANDIDATE**.

Frozen scope only: the 37,058 incompatible multi-incidence `(Y,R)` classes inherited from canonical 02C20B / 02C19-D1.

For each class `g`, define

- `C_g = intersection over all distinct observed I(Delta)`;
- `B_g = Bad(Y union R) intersection I(Delta)`, which canonical 02C20B established to be literal-set invariant over observed `Delta` in `g`.

The identities `B_g subset C_g` and `Bad(Y union R) intersection C_g = B_g` are set-theoretic corollaries of 02C20B literal bad-set stability. They are recomputed here as regression gates, not presented as an independent theorem.

The new empirical content of 02C20C is the **locality-gap census** and **Q2/Q3 obstruction-type stratification** of the invariant bad mask set relative to common incidence.

No D2/general-state claim and no minimal-sufficient-statistic claim is made.
