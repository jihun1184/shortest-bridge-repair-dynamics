# S0 — Stabilization finite certificates

This directory records the bounded finite objects used by the structural proof
of Main Theorem A (exact stabilization along the ray family). The theorem's
all-parameter step is proved in the manuscript; these files certify the finite
base objects and finite `k=9` anchor and are **not** an extrapolation argument
for unbounded `k`.

## Canonical source

The files in `source_results/` are copied byte-for-byte from the canonical
research checkpoint:

- archive: `D7D2_A4L3_FINAL_HANDOFF_checkpoint(3).zip`
- SHA-256: `33f551d1f7384ee90cda61db212c92909d0088f20c573784608298a9e78849ec`
- top-level manifest: 96/96 PASS
- nested `d7d1_rank_classification_freeze/SHA256SUMS.txt`: 47/47 PASS

No result JSON in this directory was reconstructed from manuscript prose.

## Files and manuscript roles

- `a4_l1a_signature_table_results.json` — exact `k=6,7,8` closure sizes,
  common 53-class quotient, 53 representative rows, and 18 witnessed templates.
- `a4_l1b_formal_geometry_results.json` — 53-family formal geometry,
  corridor-law split `30 + 22 + 1`, and symbolic-regression checks through
  `k=100` (consistency checks only, not the proof of the all-k theorem).
- `a4_l2a_connected_inert_tail_results.json` — finite hypotheses for the
  31 connected-satellite persistence families: 2,869 descendant states and
  4,035 action edges at the lifting base.
- `a4_l2a_t12_bridge_quotient_results.json` — isolated-satellite finite
  certificate: 22 formal classes, 737 isolated backgrounds, and the complete
  `k=9` union closure with 87,517 states / 148,722 action edges.
- `a4_l2b_parametric_reachability_results.json` — the 54-node / 53-edge
  reachability witness tree and its 16/12/24/1 edge-type decomposition.
- `a4_l3_exhaustiveness_assembly_results.json` — finite `k=9` proof assembly:
  53 observed behavioral keys, stable refinement, exact root-closure counts,
  and all 14 assembly checks true.

`verification/verify_s0_summary.py` is a standalone consistency checker for
these copied result files. It does not re-enumerate the raw closures; its role
is to verify that the publication-facing certificate set is internally
consistent and matches the exact finite quantities quoted in the manuscript.

## Scope boundary

The finite files certify bounded objects. Main Theorem A for every `k >= 6`
uses the manuscript's locality, parametric geometry, connected/isolated
persistence, reachability, and history-dependent normalization arguments.
The `k=6,...,100` regression ranges appearing in source results are consistency
checks and are not used to infer the theorem beyond that range.
