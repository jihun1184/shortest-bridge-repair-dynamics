# Source provenance

Canonical upstream archive:

`D7D2_A4L3_FINAL_HANDOFF_checkpoint(3).zip`

SHA-256:

`33f551d1f7384ee90cda61db212c92909d0088f20c573784608298a9e78849ec`

Before extraction for this Supplement, the archive was independently checked:

- top-level `SHA256SUMS.txt`: 96/96 entries matched;
- nested `d7d1_rank_classification_freeze/SHA256SUMS.txt`: 47/47 entries matched.

The six JSON files under `source_results/` are the original bytes from that
archive. Their hashes are listed in `SOURCE_SHA256SUMS.txt`.
