#!/usr/bin/env python3
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "source_results"

def load(name):
    return json.loads((SRC / name).read_text(encoding="utf-8"))

def empty_failures(value):
    if isinstance(value, list):
        return len(value) == 0
    if isinstance(value, dict):
        return all(empty_failures(v) for v in value.values())
    return not value

l1a = load("a4_l1a_signature_table_results.json")
l1b = load("a4_l1b_formal_geometry_results.json")
conn = load("a4_l2a_connected_inert_tail_results.json")
t12 = load("a4_l2a_t12_bridge_quotient_results.json")
reach = load("a4_l2b_parametric_reachability_results.json")
l3 = load("a4_l3_exhaustiveness_assembly_results.json")

checks = {
    "base_closure_sizes": l1a["closure_sizes"] == {"6": 9524, "7": 21963, "8": 45939},
    "base_classes_53": l1a["common_behavioral_classes"] == 53 and len(l1a["classes"]) == 53,
    "templates_18": l1a["witnessed_template_count"] == 18 and len(l1a["templates"]) == 18,
    "l1a_no_failures": not l1a["fixed_remainder_failures"] and not l1a["component_reconstruction_failures"],
    "corridor_laws_30_22_1": l1b["corridor_law_counts"] == {"0": 22, "k-4": 30, "k-6": 1},
    "formal_geometry_53": l1b["class_count"] == 53 and l1b["template_count"] == 18,
    "formal_geometry_no_failures": empty_failures(l1b["failures"]),
    "connected_31": conn["connected_class_count"] == 31,
    "connected_base_2869_4035": conn["descendant_states_audited"] == 2869 and conn["action_edges_audited"] == 4035,
    "connected_no_failures": empty_failures(conn["failures"]),
    "isolated_22_and_737": t12["t12_formal_classes"] == 22 and t12["isolated_states"] == 737,
    "k9_union_87517_148722": t12["union_descendant_states"] == 87517 and t12["union_action_edges"] == 148722,
    "isolated_no_failures": empty_failures(t12["failures"]),
    "tree_54_53": reach["tree_node_count"] == 54 and reach["tree_edge_count"] == 53 and len(reach["edges"]) == 53,
    "tree_edge_types": reach["edge_kind_counts"] == {"aux_fixed": 1, "nonroot_fixed": 24, "root_fixed": 16, "root_satellite": 12},
    "reachability_all_53": reach["k6_reachable_formal_classes"] == 53 and reach["k9_reachable_formal_classes"] == 53,
    "reachability_no_failures": empty_failures(reach["failures"]),
    "l3_k9_counts": l3["root_closure_state_count"] == 87517 and l3["root_closure_edge_count"] == 148722,
    "l3_53_keys": l3["c3_class_count"] == 53 and l3["c4_class_count"] == 53 and l3["observed_behavioral_key_count"] == 53,
    "l3_31_plus_22": l3["observed_connected_key_count"] == 31 and l3["observed_isolated_key_count"] == 22,
    "l3_all_checks_true": all(l3["checks"].values()),
    "l3_no_failures": empty_failures(l3["failures"]),
}

summary = {
    "pass": all(checks.values()),
    "checks": checks,
    "finite_objects": {
        "closures_k6_k8": l1a["closure_sizes"],
        "behavioral_classes": l1a["common_behavioral_classes"],
        "templates": l1a["witnessed_template_count"],
        "corridor_law_counts": l1b["corridor_law_counts"],
        "connected_classes": conn["connected_class_count"],
        "connected_descendant_states": conn["descendant_states_audited"],
        "connected_action_edges": conn["action_edges_audited"],
        "isolated_classes": t12["t12_formal_classes"],
        "isolated_backgrounds": t12["isolated_states"],
        "k9_states": l3["root_closure_state_count"],
        "k9_edges": l3["root_closure_edge_count"],
        "reachability_tree_nodes": reach["tree_node_count"],
        "reachability_tree_edges": reach["tree_edge_count"],
    },
}
print(json.dumps(summary, indent=2, sort_keys=True))
raise SystemExit(0 if summary["pass"] else 1)
