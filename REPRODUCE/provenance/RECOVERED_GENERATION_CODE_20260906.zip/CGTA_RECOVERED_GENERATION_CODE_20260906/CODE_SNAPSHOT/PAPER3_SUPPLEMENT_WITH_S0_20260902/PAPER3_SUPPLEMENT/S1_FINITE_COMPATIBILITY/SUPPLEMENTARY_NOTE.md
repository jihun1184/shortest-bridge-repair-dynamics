# S1 — Finite Compatibility in Short Chain Families (Supplementary Note)

This note collects the finite discovery-precursor material referenced by
Appendix B of the main paper. It is derived from the DAM manuscript
*"Bounded Compatibility Depth in Local Repairs of P-Well-Composed Voxel
Sets"* (submitted to the SIAM Journal on Imaging Sciences; source:
`DAM_revised.zip`, `DAM_submission/manuscript.tex`) and independently
re-verified against that manuscript's own reproducibility package
(GitHub `jihun1184/bounded-compatibility-depth-voxel-repair`, release
`v1.0.1`). As stated in the main paper, this material is a finite
discovery precursor, not a third principal theorem block, and is not used
to transfer ray-family compatibility into the frozen-D1 registry.

## 1. Setting

For a chain family `chain_L` of length `L`, a **legitimate exceptional
pair** `(a,b)` induces a local repair `q` whose compatibility with a
baseline minimum-cardinality repair `B in M0(chain_L)` may in principle
depend on all of `B`. The results below bound and classify that
dependence.

## 2. Walk structure and minimal-repair counts (Table 1 / Proposition 2)

| `L` | `\|U_L\|` | `m0` | `\|M0\|` | verification method |
|---|---|---|---|---|
| 3 | 20 | 3 | 36  | fresh exhaustive enumeration |
| 4 | 24 | 4 | 108 | exhaustive exclusion of sizes < 4, then walk generation |
| 5 | —  | 5 | 324 | walk generation, exact equality with frozen reference |

(See `TABLES_FROM_MANUSCRIPT/table1_walk_counts.csv`.) For `L=3`,
minimality and the complete `M0` family are independently recovered by
exhaustive search. For `L=4`, exhaustive rejection of all smaller repairs
establishes `m0=4`, while completeness of the 108-member size-4 family
uses the manuscript's walk characterization together with exact equality
against the frozen `M0`. For `L=5`, minimality and completeness likewise
rely on that characterization and the frozen reference; all 324 members
were independently checked against the P-well-composedness oracle, but the
smaller- and size-5 candidate spaces were not independently
re-enumerated. **The verification strength therefore differs by `L`**:
`L=3` is a fully independent reconstruction, `L=4` is partially
independent, and `L=5` relies on the frozen reference for completeness
while independently re-checking validity.

## 3. Compatibility-depth histogram (Table 2 / Corollary — Sharpness)

Exhaustive classification of `chain_5`, `76` classes (orbits) covering
`528` legitimate exceptional pairs:

| depth `d` | class count | pair count | mechanism(s) |
|---|---|---|---|
| 0 | 64 | 468 | trivial (no cross-dependence) |
| 1 | 6  | 40  | inclusion (4), exclusion (2) |
| 2 | 2  | 8   | inclusion (1), exclusion/OR (1) |
| 3 | 4  | 12  | inclusion (2), exclusion/OR (2) |
| **total** | **76** | **528** | — |

(See `TABLES_FROM_MANUSCRIPT/table2_depth_histogram.csv`.) No class
exhibits depth four or higher, so the bound of three proved in the main
Bounded Compatibility Depth theorem is attained but not exceeded in this
exhaustive classification.

### Two distinct depth-three mechanisms

- **Inclusion mechanism**: compatibility holds exactly when every column
  in the decision window equals `(-1,-1)`, giving a compatible count of
  `3^{L-k}`.
- **Exclusion/OR mechanism**: incompatibility holds exactly when the
  column `(-1,0)` occurs in *any* position of the window — a logical OR
  of per-layer exclusions rather than a conjunction of inclusions —
  giving a compatible count of `3^L - |union_j{c_j=(-1,0)}|` via
  inclusion–exclusion, not a power of three.

Both mechanisms realize the same depth bound through genuinely different
combinatorial logic; this is the intended contrast between the two
depth-three branches.

## 4. Decision-support disjointness (Table 3)

| chain length `L` | instances checked | leaks found |
|---|---|---|
| 3 | 3  | 0 |
| 4 | 6  | 0 |
| 5 | 12 | 0 |
| **total** | **21** | **0** |

(See `TABLES_FROM_MANUSCRIPT/table3_disjointness.csv`.) This establishes
the disjointness hypothesis for every depth-nonzero instance in the
investigated `L in {3,4,5}` families. It does **not** establish automatic
disjointness for arbitrary chain length; that remains open and is not
claimed here or in the main paper.

## 5. Representative witness

A concrete depth-one instance at `L=3` is recorded in
`REPRESENTATIVE_WITNESSES/L3_depth1_witness.json`:
`a=(-3,-2,-2)`, `b=(-2,-3,-2)`, `q=(-2,-2,-2)`. Grouping the 36 baseline
repairs of `chain_3` by their restriction `B ∩ L(q)` yields exactly two
classes — 27 baselines with empty restriction (uniformly incompatible)
and 9 baselines with restriction `{(-1,-1,-1)}` (uniformly compatible) —
so the compatibility depth of `q` is exactly 1, and the full and
restricted verdicts agree exactly.

## 6. Scope boundary

- These results concern `chain_L` families for `L in {3,4,5}` only.
- The 76-orbit classification and its 12 nontrivial instances are frozen,
  previously audited inputs, not freshly regenerated in this note; the
  reproduction package re-aggregates and re-checks them (see
  `S3_REPRODUCTION/finite_compatibility/`).
- No claim here is used as a premise of either Main Theorem A or Main
  Theorem B in the main paper. The relation is
  `finite evidence -> structural questions`, not a logical implication.

## Provenance

- Manuscript: `DAM_revised.zip → DAM_submission/manuscript.tex`.
- Reproducibility package: `https://github.com/jihun1184/bounded-compatibility-depth-voxel-repair`,
  release `v1.0.1`, fetched directly from `codeload.github.com` and
  verified against its own `MANIFEST.json` (25/25 files match).
- All six of that package's claim-oriented scripts
  (`depth_histogram.py`, `bridge_lemma.py`, `disjointness_L3_L5.py`,
  `disjointness_L4.py`, `section6_1_split.py`, `walk_counts.py`) were
  executed in this environment; every printed result matches the
  manuscript's stated numbers exactly. Raw run outputs are archived in
  `S3_REPRODUCTION/finite_compatibility/`.
