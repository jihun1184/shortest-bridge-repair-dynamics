# S1 — Finite Compatibility in Short Chain Families

Publication-facing supplementary material for Appendix B of the main
paper. See `SUPPLEMENTARY_NOTE.md` for the full mathematical note.

## Contents

- `SUPPLEMENTARY_NOTE.md` — the note itself (walk structure, depth
  histogram, disjointness verification, scope boundary).
- `TABLES_FROM_MANUSCRIPT/` — machine-readable CSV versions of the three
  tables (walk counts, depth histogram, disjointness), extracted from
  verified reproduction-script output, not retyped by hand.
- `REPRESENTATIVE_WITNESSES/` — the concrete `L=3` depth-one witness used
  in the main paper's Appendix B illustration.

## What this is and is not

This is a **publication-facing mathematical supplement**, derived from the
DAM manuscript and independently checked against its own reproducibility
package. It is not a raw research archive: internal stage names, census
tooling internals, and B-series-style provenance language have been kept
out, consistent with the main paper's tone.

The underlying raw reproduction code and reference JSON — which this note
was checked against — are archived separately in
`../S3_REPRODUCTION/finite_compatibility/`.
