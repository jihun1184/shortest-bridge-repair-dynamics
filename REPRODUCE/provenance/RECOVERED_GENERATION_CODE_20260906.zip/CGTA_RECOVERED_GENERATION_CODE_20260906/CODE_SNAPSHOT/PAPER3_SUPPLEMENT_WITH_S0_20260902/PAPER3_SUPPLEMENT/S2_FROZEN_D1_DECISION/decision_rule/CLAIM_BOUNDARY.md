# Claim boundary

**Closed:** exact recovery of frozen D1 `ChainGap` geometry for all 37,058
incompatible classes by a 117-bucket dispatch table: 113 constant-false
buckets plus 4 adjacency-saturation buckets.  The same rule recovers the B4
diagnostic labels; support remains constantly false.

**General theorem used:** adjacency saturation of the oriented boundary sequence
implies all required monotone segments are reachable, because each segment is a
single 6-neighbor edge in `Y union R`.

**Not generalized:** the frozen 117-bucket vocabulary, the four dynamic bucket
identities, chainability alone, or the empirical q-only collapse.  No claim is
made outside frozen D1.
