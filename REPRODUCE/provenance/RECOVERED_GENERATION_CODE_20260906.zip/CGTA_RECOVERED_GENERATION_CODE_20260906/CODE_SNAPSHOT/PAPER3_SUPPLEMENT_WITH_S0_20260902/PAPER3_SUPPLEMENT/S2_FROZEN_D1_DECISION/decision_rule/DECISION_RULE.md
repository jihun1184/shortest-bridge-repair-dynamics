# 02C20D-B7 — frozen D1 integrated geometry decision rule

Let `K(Y,R)` be the class-level multiset of residual-attribution signatures
`rho_R=(sigma_F,occ_R)`.  Let `M` be the four `K`-values that were mixed for
`ChainGap` in the exhaustive B4 census.

For a shortest certificate endpoint pair `(s,t)`, suppose `residual_chain`
returns `(p_1,...,p_k)`.  In the frozen oriented coordinates set

```math
q_0=0,\qquad q_i=q(p_i;s,t),\qquad q_{k+1}=\operatorname{span}(s,t).
```

Call the frame **adjacency-saturated** when

```math
\|q_{i+1}-q_i\|_1=1\qquad(0\le i\le k).
```

The exact frozen-D1 rule is

```math
\boxed{
G(Y,R)=
\begin{cases}
0, & K(Y,R)\notin M,\\[2mm]
\mathbf 1[\exists\text{ shortest endpoint pair with an adjacency-saturated residual chain}],
& K(Y,R)\in M.
\end{cases}}
```

On the 37,058 incompatible classes this gives exactly 37,018 false and 40 true.
The diagnostic label is `local_incompatible` iff `G=1`; otherwise it is
`no_geometry_and_local_incompatible`.  The support bit is false on all 37,058
classes.

## Why this closes the frozen scope

B4 exhaustively established that 113 of the 117 `rho_R` multiset buckets are
pure false.  They contain 36,765 classes, so no endpoint geometry is needed for
99.21% of the scope.  The remaining four buckets contain exactly 293 classes.
B5 exhaustively reconstructed their endpoint geometry, and B6 proved that every
adjacency-saturated residual chain automatically satisfies all required
monotone-segment reachability checks.  Re-evaluating all 293 B5 rows with the
adjacency-saturation predicate gives 253 false and 40 true with zero mismatch.
Combining the two branches therefore covers all 37,058 classes.

## Boundary

This is an exact integrated rule for the frozen D1 incompatible-class scope.
The adjacency-saturation implication is general, but the 117-bucket vocabulary,
the identity of the four dynamic buckets, and saturation of all B5 chainable
frames are frozen-scope facts.  Chainability alone is not promoted to a general
theorem, and endpoint span remains theorem-relevant for checking the final gap.
