# S2 — Certified Finite Registry Exact Decision Structure

Full certification data for Main Theorem B (exact conditional decision
rule on the certified finite registry $\mathfrak D_1$). The directory name
`S2_FROZEN_D1_DECISION` is retained as a historical provenance identifier; it
is not the publication-facing name of the domain. All content here is
extracted directly from `S2_COMP_02C20D_B7_FULL_DECISION_RULE_INTEGRATION_FREEZE_20260901.zip`
(from `S2_COMP_PAPER3_MANUSCRIPT_HANDOFF_20260902.zip`), whose internal
manifest (27 files) was recomputed and matched before use.

## Contents

- `rule_table/rule_table_117_keys.csv` — the complete 117-row class-key
  dispatch table: every `rho_R` multiset key, its rule (`constant_false`
  or `adjacency_saturation`), class count, and B4 geometry-false/true
  counts. This is the full table main-text Figure 4 compresses.
- `exception_geometry/four_exception_keys.csv` — the four
  `adjacency_saturation` (mixed) keys only, matching main-text Table 1
  exactly (`104/99/5`, `88/83/5`, `57/42/15`, `44/29/15`; total
  `293/253/40`).
- `decision_rule/DECISION_RULE.md`, `decision_rule/CLAIM_BOUNDARY.md` —
  the formal statement of the rule `G(Y,R)` and its explicit scope
  boundary, copied verbatim from the canonical B7 freeze.
- `verification/coverage_and_totals.json` — the scope, coverage, and
  predicted-totals fields from the canonical B7 JSON, confirming
  `36,765 + 293 = 37,058` and `37,018` false / `40` true / `0` mismatch.

## Consistency check

Every number in this directory was cross-checked against the compiled
main-text manuscript (`PAPER3_DCG_MASTER_A_PLUS_20260902.tex`, Section 6)
during construction: the 117/113/4 split, the 36,765/293 class split, the
four exception-key row values, and the 37,018/40/0 final totals all agree
exactly.
