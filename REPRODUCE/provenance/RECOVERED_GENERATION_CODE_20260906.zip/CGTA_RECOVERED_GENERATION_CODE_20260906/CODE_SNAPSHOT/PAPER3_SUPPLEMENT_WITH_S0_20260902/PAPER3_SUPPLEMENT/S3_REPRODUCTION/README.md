# S3 — Reproduction

Two independent reproduction packages, one per main theorem's supporting
material.

- `frozen_d1/` — Main Theorem B (certified finite-registry exact decision rule; historical folder name retained). Fully
  self-contained: the canonical rule-table JSON plus a standalone regression
  test that independently re-derives every scope/coverage number. See
  `frozen_d1/README.md` for exactly what is and is not runnable without
  the full pre-B0 research archive.
- `finite_compatibility/` — Appendix B precursor (DAM manuscript). The
  manuscript's own GitHub reproducibility package (release `v1.0.1`),
  fetched, hash-verified, and re-executed in this session. See
  `finite_compatibility/README.md` for the full provenance chain and
  run logs.

Both packages were independently exercised (not merely cited) before this
Supplement was assembled: `frozen_d1/test_b7_regression.py` was run here,
and all six `finite_compatibility/scripts/*.py` were run here, with raw
console and JSON output archived alongside the code.
