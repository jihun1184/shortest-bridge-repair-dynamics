# Artifact map: main paper ↔ Supplement

Main-paper labels refer to `PAPER3_DCG_MASTER_A_PLUS_20260902.tex`.

## Main Theorem A block (Sections 2–5) ↔ `S0_STABILIZATION_CERTIFICATION/`

Theorem `thm:stabilization` and its supporting structural lemmas are proved
self-containedly in the main text. `S0_STABILIZATION_CERTIFICATION/` supplies
the bounded finite certificates used by that proof; it is not a replacement
for the all-parameter locality, persistence, reachability, or normalization
arguments.

| Main-text item | Supplement artifact |
|---|---|
| `prop:finite-base` (k=6,7,8 closures; 53 classes; 18 templates) | `S0_STABILIZATION_CERTIFICATION/source_results/a4_l1a_signature_table_results.json` |
| `lem:geometry` (18 templates; corridor laws 30/22/1) | `S0_STABILIZATION_CERTIFICATION/source_results/a4_l1a_signature_table_results.json`, `S0_STABILIZATION_CERTIFICATION/source_results/a4_l1b_formal_geometry_results.json` |
| `lem:connected-persistence` (31 connected families; 2,869 states / 4,035 edges at the lifting base) | `S0_STABILIZATION_CERTIFICATION/source_results/a4_l2a_connected_inert_tail_results.json` |
| `lem:isolated-persistence` (22 isolated families; 737 backgrounds; k=9 union counts) | `S0_STABILIZATION_CERTIFICATION/source_results/a4_l2a_t12_bridge_quotient_results.json` |
| `lem:reachability` (54-node / 53-edge witness tree) | `S0_STABILIZATION_CERTIFICATION/source_results/a4_l2b_parametric_reachability_results.json` |
| `thm:stabilization` finite k=9 anchor and assembly checks | `S0_STABILIZATION_CERTIFICATION/source_results/a4_l3_exhaustiveness_assembly_results.json` plus the preceding S0 result files |
| Publication-facing cross-file consistency | `S0_STABILIZATION_CERTIFICATION/verification/verify_s0_summary.py` and `summary.json` |

The symbolic `k=6,...,100` checks recorded in the source results are regression
checks only; the theorem for every `k>=6` is established by the main-text
structural proof, not by extrapolation.

## Main Theorem B block (Section 6) ↔ `S2_FROZEN_D1_DECISION/` and `S3_REPRODUCTION/frozen_d1/`

| Main-text item | Supplement artifact |
|---|---|
| `lem:residual-incidence`, `lem:adjacency-saturation` (general lemmas) | Proved in main text; no data dependency |
| `rem:chainability-counterexample` ("[1,5]" witness) / Figure 3 | `S3_REPRODUCTION/frozen_d1/probe_natural_1_5_counterexample.py` (provenance only, not independently runnable — see that directory's README); values quoted from the original B6 `THEOREM.md`/`RESULT_SUMMARY.md` |
| `prop:frozen-vocabulary` (47,445 → 51 → 71) | `S2_FROZEN_D1_DECISION/verification/coverage_and_totals.json` |
| `prop:frozen-localization` (117 keys, 113/4 split, 36,765/293) | `S2_FROZEN_D1_DECISION/rule_table/rule_table_117_keys.csv` |
| Table 1 (four exception keys) | `S2_FROZEN_D1_DECISION/exception_geometry/four_exception_keys.csv` |
| `prop:frozen-saturation` (50 pairs, gap profiles) | `S1_FINITE_COMPATIBILITY` gap-profile discussion is a distinct (chain-family) result; the certified-registry 50-pair saturation count itself is recorded in `S2_FROZEN_D1_DECISION/decision_rule/DECISION_RULE.md` |
| `thm:frozen-d1-decision` (37,018/40/0) | `S2_FROZEN_D1_DECISION/decision_rule/DECISION_RULE.md`, `verification/coverage_and_totals.json`, independently re-derived by `S3_REPRODUCTION/frozen_d1/test_b7_regression.py` |
| Figure 4 (compression funnel) | Same data as `rule_table_117_keys.csv` and `coverage_and_totals.json`, rendered as a diagram in the main text |

## Appendix B (finite compatibility precursor) ↔ `S1_FINITE_COMPATIBILITY/` and `S3_REPRODUCTION/finite_compatibility/`

| Main-text item | Supplement artifact |
|---|---|
| `prop:finite-walk-precursor` (walk representation, `L=3,4,5` counts) | `S1_FINITE_COMPATIBILITY/TABLES_FROM_MANUSCRIPT/table1_walk_counts.csv` |
| `lem:finite-precursor-localization` (support-separation locality) | Proved in main text; underlying finite checks in `S1_FINITE_COMPATIBILITY/TABLES_FROM_MANUSCRIPT/table3_disjointness.csv` |
| `prop:finite-precursor-sharpness` (depth-3 attainment, two mechanisms) | `S1_FINITE_COMPATIBILITY/TABLES_FROM_MANUSCRIPT/table2_depth_histogram.csv`, `SUPPLEMENTARY_NOTE.md` §3 |
| Representative depth-1 witness discussed in Appendix B | `S1_FINITE_COMPATIBILITY/REPRESENTATIVE_WITNESSES/L3_depth1_witness.json` |
| Full DAM manuscript (source of the above) | `DAM_revised.zip / DAM_submission/manuscript.tex` (user-supplied; not redistributed in this Supplement) |
| Raw reproduction code/data for the above | `S3_REPRODUCTION/finite_compatibility/` (DAM manuscript's own GitHub release `v1.0.1`, fetched and re-executed here) |

## Not included in this Supplement

- The pre-B0 research-lineage archive (`S2_COMP_CANONICAL_CHAIN`, ~170 MB)
  needed to independently re-run `run_b7_integration.py` from raw B4/B5/B6
  aggregates. Only the frozen output and its hash-verified consistency
  checks are included.
- Full B0–B7 stage-by-stage internal artifacts (available in the original
  `S2_COMP_PAPER3_MANUSCRIPT_HANDOFF_20260902.zip` lineage folder, not
  duplicated here to keep this Supplement publication-facing rather than
  a raw research archive).
